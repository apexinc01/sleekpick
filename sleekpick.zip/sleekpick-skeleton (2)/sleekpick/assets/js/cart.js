/* ============================================================
   SLEEKPICK — cart.js
   Product detail page interactions: gallery thumbnails, size/color
   selection, quantity stepper, tabs, add-to-cart feedback.

   NOTE: UI state only for now. Real cart persistence (session/DB)
   arrives in Phase 4/5 via actions/add-to-cart.php + api/cart/.
   ============================================================ */

   document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Gallery: thumbnail swaps main image ---------- */
    const mainImage = document.querySelector('.gallery-main img');
    document.querySelectorAll('.gallery-thumb').forEach(function (thumb) {
      thumb.addEventListener('click', function () {
        const newSrc = thumb.querySelector('img').getAttribute('src');
        if (mainImage && newSrc) {
          mainImage.style.opacity = '0';
          setTimeout(function () {
            mainImage.setAttribute('src', newSrc);
            mainImage.style.opacity = '1';
          }, 150);
        }
        document.querySelectorAll('.gallery-thumb').forEach(function (t) { t.classList.remove('active'); });
        thumb.classList.add('active');
      });
    });
  
    /* ---------- Size selection (single-select, shows chosen size) ---------- */
    const sizeButtons = document.querySelectorAll('.detail-size-options .size-btn');
    const sizeValueLabel = document.querySelector('[data-selected="size"]');
  
    sizeButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        sizeButtons.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        if (sizeValueLabel) sizeValueLabel.textContent = btn.textContent.trim();
      });
    });
  
    /* ---------- Color selection (single-select, shows chosen color) ---------- */
    const colorSwatches = document.querySelectorAll('.detail-color-options .color-swatch');
    const colorValueLabel = document.querySelector('[data-selected="color"]');
  
    colorSwatches.forEach(function (swatch) {
      swatch.addEventListener('click', function () {
        colorSwatches.forEach(function (s) { s.classList.remove('active'); });
        swatch.classList.add('active');
        if (colorValueLabel) colorValueLabel.textContent = swatch.dataset.label || '';
      });
    });
  
    /* ---------- Quantity stepper ---------- */
    const qtyInput = document.querySelector('.qty-stepper input');
    const qtyDecrease = document.querySelector('.qty-stepper .qty-decrease');
    const qtyIncrease = document.querySelector('.qty-stepper .qty-increase');
    const MAX_QTY = 10;
  
    if (qtyInput && qtyDecrease && qtyIncrease) {
      qtyDecrease.addEventListener('click', function () {
        const current = parseInt(qtyInput.value, 10) || 1;
        qtyInput.value = String(Math.max(1, current - 1));
      });
  
      qtyIncrease.addEventListener('click', function () {
        const current = parseInt(qtyInput.value, 10) || 1;
        qtyInput.value = String(Math.min(MAX_QTY, current + 1));
      });
  
      qtyInput.addEventListener('change', function () {
        let value = parseInt(qtyInput.value, 10);
        if (isNaN(value) || value < 1) value = 1;
        if (value > MAX_QTY) value = MAX_QTY;
        qtyInput.value = String(value);
      });
    }
  
    /* ---------- Tabs ---------- */
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanels = document.querySelectorAll('.tab-panel');
  
    tabButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        const target = btn.dataset.tab;
  
        tabButtons.forEach(function (b) { b.classList.remove('active'); });
        tabPanels.forEach(function (p) { p.classList.remove('active'); });
  
        btn.classList.add('active');
        const panel = document.querySelector('.tab-panel[data-tab="' + target + '"]');
        if (panel) panel.classList.add('active');
      });
    });
  
    /* ---------- Add to cart feedback + header cart count bump ---------- */
    const addToCartBtn = document.querySelector('.product-info-panel .add-to-cart-btn');
    const cartCountBadge = document.querySelector('.cart-count');
  
    if (addToCartBtn) {
      addToCartBtn.addEventListener('click', function () {
        const qty = qtyInput ? (parseInt(qtyInput.value, 10) || 1) : 1;
  
        if (cartCountBadge) {
          const current = parseInt(cartCountBadge.textContent, 10) || 0;
          cartCountBadge.textContent = String(current + qty);
        }
  
        const originalText = addToCartBtn.innerHTML;
        addToCartBtn.innerHTML = '<i class="bi bi-check-lg"></i> Added';
        addToCartBtn.disabled = true;
  
        setTimeout(function () {
          addToCartBtn.innerHTML = originalText;
          addToCartBtn.disabled = false;
        }, 1500);
      });
    }
  
    /* ---------- Wishlist toggle on detail page ---------- */
    const detailWishlistBtn = document.querySelector('.detail-wishlist-btn');
    if (detailWishlistBtn) {
      detailWishlistBtn.addEventListener('click', function () {
        const active = detailWishlistBtn.classList.toggle('active');
        const icon = detailWishlistBtn.querySelector('i');
        if (icon) icon.className = active ? 'bi bi-heart-fill' : 'bi bi-heart';
        detailWishlistBtn.setAttribute('aria-pressed', String(active));
      });
    }
  

/* ============================================================
     CART PAGE (cart.php) — only runs if .cart-items exists on page
     ============================================================ */
     const cartItemsWrap = document.querySelector('.cart-items');

     if (cartItemsWrap) {
       const FREE_SHIPPING_THRESHOLD = 80;
       const SHIPPING_COST = 8;
       const MAX_ITEM_QTY = 10;
   
       function readCartTotals() {
         let subtotal = 0;
         cartItemsWrap.querySelectorAll('.cart-item').forEach(function (item) {
           const unitPrice = parseFloat(item.dataset.price || '0');
           const qtyInputEl = item.querySelector('.qty-stepper input');
           const qty = qtyInputEl ? (parseInt(qtyInputEl.value, 10) || 1) : 1;
           subtotal += unitPrice * qty;
   
           const lineTotalEl = item.querySelector('.line-total');
           if (lineTotalEl) lineTotalEl.textContent = '$' + (unitPrice * qty).toFixed(2);
         });
         return subtotal;
       }
   
       function updateSummary() {
         const subtotal = readCartTotals();
         const shipping = subtotal >= FREE_SHIPPING_THRESHOLD || subtotal === 0 ? 0 : SHIPPING_COST;
         const total = subtotal + shipping;
   
         const subtotalEl = document.querySelector('.summary-subtotal');
         const shippingEl = document.querySelector('.summary-shipping');
         const totalEl = document.querySelector('.summary-total');
   
         if (subtotalEl) subtotalEl.textContent = '$' + subtotal.toFixed(2);
         if (shippingEl) shippingEl.textContent = shipping === 0 ? 'Free' : '$' + shipping.toFixed(2);
         if (totalEl) totalEl.textContent = '$' + total.toFixed(2);
   
         const emptyState = document.querySelector('.empty-cart');
         const cartLayout = document.querySelector('.cart-layout');
         const hasItems = cartItemsWrap.querySelectorAll('.cart-item').length > 0;
   
         if (emptyState && cartLayout) {
           emptyState.style.display = hasItems ? 'none' : 'block';
           cartLayout.style.display = hasItems ? 'grid' : 'none';
         }
       }
   
       /* Per-item quantity steppers */
       cartItemsWrap.querySelectorAll('.cart-item').forEach(function (item) {
         const input = item.querySelector('.qty-stepper input');
         const decreaseBtn = item.querySelector('.qty-decrease');
         const increaseBtn = item.querySelector('.qty-increase');
   
         if (decreaseBtn && input) {
           decreaseBtn.addEventListener('click', function () {
             const current = parseInt(input.value, 10) || 1;
             input.value = String(Math.max(1, current - 1));
             updateSummary();
           });
         }
   
         if (increaseBtn && input) {
           increaseBtn.addEventListener('click', function () {
             const current = parseInt(input.value, 10) || 1;
             input.value = String(Math.min(MAX_ITEM_QTY, current + 1));
             updateSummary();
           });
         }
   
         if (input) {
           input.addEventListener('change', function () {
             let value = parseInt(input.value, 10);
             if (isNaN(value) || value < 1) value = 1;
             if (value > MAX_ITEM_QTY) value = MAX_ITEM_QTY;
             input.value = String(value);
             updateSummary();
           });
         }
   
         const removeBtn = item.querySelector('.remove-item-btn');
         if (removeBtn) {
           removeBtn.addEventListener('click', function () {
             item.classList.add('removing');
             setTimeout(function () {
               item.remove();
               updateSummary();
             }, 250);
           });
         }
       });
   
       /* Promo code (visual placeholder — real validation in Phase 4/5) */
       const promoForm = document.querySelector('.promo-form');
       if (promoForm) {
         promoForm.addEventListener('submit', function (e) {
           e.preventDefault();
           const input = promoForm.querySelector('input');
           if (input && input.value.trim()) {
             input.value = '';
             input.placeholder = 'Code applied at checkout';
           }
         });
       }
   
       updateSummary();
     }
   
   
/* ============================================================
     CHECKOUT PAGE (checkout.php) — only runs if .checkout-layout exists
     ============================================================ */
  const checkoutLayout = document.querySelector('.checkout-layout');

  if (checkoutLayout) {
    const SHIPPING_RATES = { standard: 0, express: 15, overnight: 25 };

    /* Toggle new-address form when "Add a new address" is clicked */
    const newAddressToggle = document.querySelector('.new-address-toggle');
    const newAddressForm = document.querySelector('.new-address-form');
    if (newAddressToggle && newAddressForm) {
      newAddressToggle.addEventListener('click', function () {
        newAddressForm.classList.toggle('open');
        const isOpen = newAddressForm.classList.contains('open');
        newAddressToggle.innerHTML = isOpen
          ? '<i class="bi bi-dash-circle"></i> Cancel new address'
          : '<i class="bi bi-plus-circle"></i> Add a new address';
      });
    }

    /* Shipping method affects the summary total */
    const shippingRadios = document.querySelectorAll('input[name="shipping_method"]');
    const checkoutShippingEl = document.querySelector('.checkout-summary-shipping');
    const checkoutTotalEl = document.querySelector('.checkout-summary-total');
    const checkoutSubtotalEl = document.querySelector('.checkout-summary-subtotal');

    function updateCheckoutTotals() {
      if (!checkoutSubtotalEl) return;
      const subtotal = parseFloat(checkoutSubtotalEl.dataset.subtotal || '0');
      const selected = document.querySelector('input[name="shipping_method"]:checked');
      const method = selected ? selected.value : 'standard';
      const shippingCost = SHIPPING_RATES[method] !== undefined ? SHIPPING_RATES[method] : 0;
      const total = subtotal + shippingCost;

      if (checkoutShippingEl) checkoutShippingEl.textContent = shippingCost === 0 ? 'Free' : '$' + shippingCost.toFixed(2);
      if (checkoutTotalEl) checkoutTotalEl.textContent = '$' + total.toFixed(2);
    }

    shippingRadios.forEach(function (radio) {
      radio.addEventListener('change', updateCheckoutTotals);
    });

    updateCheckoutTotals();

    /* Basic required-field validation on submit (placeholder — real
       validation + payment processing happens server-side in Phase 4/5) */
    const checkoutForm = document.querySelector('.checkout-form');
    if (checkoutForm) {
      checkoutForm.addEventListener('submit', function (e) {
        e.preventDefault();
        let isValid = true;

        checkoutForm.querySelectorAll('input[required]:not([type="radio"])').forEach(function (input) {
          // Skip validating hidden new-address fields if that section is closed
          if (newAddressForm && newAddressForm.contains(input) && !newAddressForm.classList.contains('open')) {
            return;
          }
          if (!input.value.trim()) {
            input.style.borderColor = 'var(--color-primary)';
            isValid = false;
          } else {
            input.style.borderColor = '';
          }
        });

        if (isValid) {
          const submitBtn = checkoutForm.querySelector('.place-order-btn');
          if (submitBtn) {
            submitBtn.innerHTML = '<i class="bi bi-check-lg"></i> Placing order…';
            submitBtn.disabled = true;
          }
          // Phase 5: submit to actions/place-order.php once payment provider is selected.
        }
      });
    }
  }


  });
  /* ---------- Quantity stepper (product detail page only) ---------- */
  const qtyInput = document.querySelector('.product-info-panel .qty-stepper input');
  const qtyDecrease = document.querySelector('.product-info-panel .qty-stepper .qty-decrease');
  const qtyIncrease = document.querySelector('.product-info-panel .qty-stepper .qty-increase');
  