/* ============================================================
   SLEEKPICK — main.js
   Global site behavior: preloader, sticky header, mobile nav,
   newsletter form (client-side only for now — Phase 4 wires
   this to actions/ + api/ once the PHP backend exists).
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Preloader ---------- */
  const preloader = document.getElementById('preloader');
  if (preloader) {
    // Falling icon backdrop
    const iconPool = ['bi-lightning-charge', 'bi-gem', 'bi-bag', 'bi-stars', 'bi-hexagon'];
    const iconLayer = preloader.querySelector('.preloader-icons');
    if (iconLayer) {
      const iconCount = 18;
      for (let i = 0; i < iconCount; i++) {
        const icon = document.createElement('i');
        const name = iconPool[Math.floor(Math.random() * iconPool.length)];
        icon.className = 'bi ' + name;
        icon.style.left = Math.random() * 100 + '%';
        icon.style.fontSize = (0.8 + Math.random() * 1.6) + 'rem';
        icon.style.animationDuration = (5 + Math.random() * 6) + 's';
        icon.style.animationDelay = (Math.random() * 4) + 's';
        iconLayer.appendChild(icon);
      }
    }

    window.addEventListener('load', function () {
      setTimeout(function () {
        preloader.classList.add('loaded');
      }, 400);
    });
  }

  /* ---------- Sticky header shadow on scroll ---------- */
  const header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('scrolled', window.scrollY > 12);
    }, { passive: true });
  }

  /* ---------- Mobile nav toggle ---------- */
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function () {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      const icon = navToggle.querySelector('i');
      if (icon) {
        icon.className = isOpen ? 'bi bi-x-lg' : 'bi bi-list';
      }
    });

    // Close menu when a nav link is tapped (mobile)
    mainNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        mainNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        const icon = navToggle.querySelector('i');
        if (icon) icon.className = 'bi bi-list';
      });
    });
  }

  /* ---------- Wishlist toggle (visual only until Phase 4/5) ---------- */
  document.querySelectorAll('.wishlist-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const icon = btn.querySelector('i');
      const active = btn.classList.toggle('active');
      if (icon) {
        icon.className = active ? 'bi bi-heart-fill' : 'bi bi-heart';
      }
      btn.setAttribute('aria-pressed', String(active));
    });
  });

  /* ---------- Newsletter form (placeholder validation) ----------
     Real submission wires to actions/ + api/ in Phase 4.        */
  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const input = newsletterForm.querySelector('input[type="email"]');
      const message = newsletterForm.querySelector('.form-message');
      const email = input ? input.value.trim() : '';
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!email || !emailPattern.test(email)) {
        if (message) {
          message.textContent = 'Enter a valid email address.';
          message.className = 'form-message error';
        }
        return;
      }

      if (message) {
        message.textContent = 'Thanks — you are on the list.';
        message.className = 'form-message success';
      }
      newsletterForm.reset();
    });
  }

});
/* ============================================================
     ACCOUNT PAGE (account.php) — sidebar panel switching
     Only runs if .account-nav exists on the page.
     ============================================================ */
  const accountNav = document.querySelector('.account-nav');
  if (accountNav) {
    const navItems = accountNav.querySelectorAll('.account-nav-item[data-panel]');
    const panels = document.querySelectorAll('.account-panel');

    navItems.forEach(function (item) {
      item.addEventListener('click', function () {
        const target = item.dataset.panel;

        navItems.forEach(function (i) { i.classList.remove('active'); });
        panels.forEach(function (p) { p.classList.remove('active'); });

        item.classList.add('active');
        const panel = document.querySelector('.account-panel[data-panel="' + target + '"]');
        if (panel) panel.classList.add('active');

        // Move focus to the panel heading for keyboard/screen-reader users
        const heading = panel ? panel.querySelector('.panel-heading') : null;
        if (heading) {
          heading.setAttribute('tabindex', '-1');
          heading.focus();
        }
      });
    });

    // "View all orders" quick link from the Overview panel jumps to the Orders tab
    document.querySelectorAll('[data-goto-panel]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        const target = link.dataset.gotoPanel;
        const navItem = accountNav.querySelector('.account-nav-item[data-panel="' + target + '"]');
        if (navItem) navItem.click();
      });
    });
  }

  /* ---------- Settings form (placeholder — real save in Phase 4) ---------- */
  const settingsForm = document.querySelector('.settings-form');
  if (settingsForm) {
    settingsForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const message = settingsForm.querySelector('.form-message');
      if (message) {
        message.textContent = 'Changes saved.';
        message.className = 'form-message success';
      }
    });
  }

/* ============================================================
     REGISTER PAGE (register.php) — password toggles, strength
     meter, client-side validation.
     Real account creation happens server-side in Phase 4 via
     actions/register.php.
     ============================================================ */
  const registerForm = document.querySelector('.register-form');

  /* Password show/hide toggle — works on any page that has it */
  document.querySelectorAll('.password-toggle-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const input = btn.previousElementSibling;
      if (!input) return;
      const icon = btn.querySelector('i');
      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');
      if (icon) icon.className = isPassword ? 'bi bi-eye-slash' : 'bi bi-eye';
    });
  });

  if (registerForm) {
    const passwordInput = registerForm.querySelector('#password');
    const confirmInput = registerForm.querySelector('#confirm-password');
    const strengthFill = registerForm.querySelector('.strength-bar-fill');
    const strengthLabel = registerForm.querySelector('.strength-label');

    function scorePassword(value) {
      let score = 0;
      if (value.length >= 8) score++;
      if (value.length >= 12) score++;
      if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score++;
      if (/[0-9]/.test(value)) score++;
      if (/[^A-Za-z0-9]/.test(value)) score++;
      return Math.min(score, 4);
    }

    if (passwordInput && strengthFill && strengthLabel) {
      passwordInput.addEventListener('input', function () {
        const value = passwordInput.value;
        const score = value ? scorePassword(value) : 0;
        const levels = [
          { width: '0%',   label: '',        color: 'var(--color-border)' },
          { width: '25%',  label: 'Weak',    color: 'var(--color-primary)' },
          { width: '50%',  label: 'Fair',    color: 'var(--color-primary)' },
          { width: '75%',  label: 'Good',    color: 'var(--color-secondary)' },
          { width: '100%', label: 'Strong',  color: 'var(--color-accent-dark)' }
        ];
        const level = levels[score];
        strengthFill.style.width = level.width;
        strengthFill.style.background = level.color;
        strengthLabel.textContent = level.label;
      });
    }

    registerForm.addEventListener('submit', function (e) {
      e.preventDefault();
      let isValid = true;

      registerForm.querySelectorAll('.form-group').forEach(function (group) {
        const input = group.querySelector('input');
        const errorEl = group.querySelector('.field-error');
        if (!input || !errorEl) return;

        let message = '';

        if (input.hasAttribute('required') && !input.value.trim()) {
          message = 'This field is required.';
        } else if (input.type === 'email' && input.value.trim()) {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(input.value.trim())) message = 'Enter a valid email address.';
        } else if (input.id === 'password' && input.value && input.value.length < 8) {
          message = 'Password must be at least 8 characters.';
        } else if (input.id === 'confirm-password' && passwordInput && input.value !== passwordInput.value) {
          message = 'Passwords do not match.';
        }

        errorEl.textContent = message;
        group.classList.toggle('has-error', Boolean(message));
        if (message) isValid = false;
      });

      const termsCheckbox = registerForm.querySelector('#agree-terms');
      const termsError = registerForm.querySelector('.terms-error');
      if (termsCheckbox && !termsCheckbox.checked) {
        if (termsError) termsError.textContent = 'You must agree to the Terms and Privacy Policy.';
        isValid = false;
      } else if (termsError) {
        termsError.textContent = '';
      }

      if (isValid) {
        // Phase 4: submit to actions/register.php instead of this placeholder.
        const submitBtn = registerForm.querySelector('.auth-submit-btn');
        if (submitBtn) {
          submitBtn.textContent = 'Account created — redirecting…';
          submitBtn.disabled = true;
        }
      }
    });
  }
  /* ============================================================
     LOGIN PAGE (login.php) — client-side validation only.
     Real authentication happens server-side in Phase 4 via
     actions/login.php (session creation, password_verify()).
     ============================================================ */
  const loginForm = document.querySelector('.login-form');

  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      let isValid = true;

      loginForm.querySelectorAll('.form-group').forEach(function (group) {
        const input = group.querySelector('input');
        const errorEl = group.querySelector('.field-error');
        if (!input || !errorEl) return;

        let message = '';

        if (!input.value.trim()) {
          message = 'This field is required.';
        } else if (input.type === 'email') {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(input.value.trim())) message = 'Enter a valid email address.';
        }

        errorEl.textContent = message;
        group.classList.toggle('has-error', Boolean(message));
        if (message) isValid = false;
      });

      if (isValid) {
        // Phase 4: submit to actions/login.php instead of this placeholder.
        const submitBtn = loginForm.querySelector('.auth-submit-btn');
        if (submitBtn) {
          submitBtn.textContent = 'Signing in…';
          submitBtn.disabled = true;
        }
      }
    });
  }

  


