/* ============================================================
   SLEEKPICK ADMIN — admin.js
   Admin panel interactions. Starting with the login page;
   dashboard/products/orders behavior gets added here as those
   pages are built.

   NOTE: Client-side validation only. Real authentication (role
   check for admin/editor/support, session creation, password_verify())
   happens server-side in Phase 4 via admin auth logic — never trust
   this layer alone for access control.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Password visibility toggle ---------- */
  document.querySelectorAll('.admin-password-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const wrap = btn.closest('.admin-input-wrap');
      const input = wrap ? wrap.querySelector('input') : null;
      if (!input) return;
      const icon = btn.querySelector('i');
      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');
      if (icon) icon.className = isPassword ? 'bi bi-eye-slash' : 'bi bi-eye';
    });
  });

  /* ---------- Admin login form validation ---------- */
  const adminLoginForm = document.querySelector('.admin-login-form');

  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      let isValid = true;

      adminLoginForm.querySelectorAll('.admin-form-group').forEach(function (group) {
        const input = group.querySelector('input');
        const errorEl = group.querySelector('.admin-field-error');
        if (!input || !errorEl) return;

        let message = '';

        if (!input.value.trim()) {
          message = 'This field is required.';
        } else if (input.type === 'email') {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(input.value.trim())) message = 'Enter a valid email address.';
        }

        errorEl.textContent = message;
        if (message) isValid = false;
      });

      if (isValid) {
        // Phase 4: submit to a dedicated admin auth endpoint instead of this placeholder.
        const submitBtn = adminLoginForm.querySelector('.admin-login-submit');
        if (submitBtn) {
          submitBtn.innerHTML = '<i class="bi bi-arrow-repeat"></i> Signing in…';
          submitBtn.disabled = true;
          window.setTimeout(function () {
            submitBtn.innerHTML = '<i class="bi bi-box-arrow-in-right"></i> Sign In';
            submitBtn.disabled = false;
            const message = adminLoginForm.querySelector('.admin-login-message');
            if (message) message.textContent = 'Demo mode: connect the staff authentication endpoint before production use.';
          }, 650);
        }
      }
    });
  }
/* ============================================================
   /* ============================================================
     ADMIN SHELL — sidebar toggle (mobile), shared across every
     interior admin page (dashboard, products, orders, customers).
     ============================================================ */
  const adminSidebar = document.querySelector('.admin-sidebar');
  const adminSidebarToggle = document.querySelector('.admin-sidebar-toggle');
  const adminSidebarBackdrop = document.querySelector('.admin-sidebar-backdrop');

  function closeAdminSidebar() {
    if (adminSidebar) adminSidebar.classList.remove('open');
    if (adminSidebarBackdrop) adminSidebarBackdrop.classList.remove('open');
  }

  if (adminSidebar && adminSidebarToggle) {
    adminSidebarToggle.addEventListener('click', function () {
      const isOpen = adminSidebar.classList.toggle('open');
      if (adminSidebarBackdrop) adminSidebarBackdrop.classList.toggle('open', isOpen);
    });

    // Close sidebar when a nav link is tapped on mobile
    adminSidebar.querySelectorAll('.admin-nav-link').forEach(function (link) {
      link.addEventListener('click', closeAdminSidebar);
    });

    // Close sidebar when the backdrop is tapped
    if (adminSidebarBackdrop) {
      adminSidebarBackdrop.addEventListener('click', closeAdminSidebar);
    }
  }
  /* ============================================================
     ADMIN ORDERS PAGE (admin/orders.php) — only runs if the
     orders table exists on the page.
     ============================================================ */
  const ordersTable = document.querySelector('.admin-orders-table');

  if (ordersTable) {
    /* Inline status update — visual only. Real persistence happens
       server-side in Phase 6 via an admin order-status endpoint. */
    ordersTable.querySelectorAll('.status-update-select').forEach(function (select) {
      select.addEventListener('change', function () {
        const row = select.closest('tr');
        const badge = row ? row.querySelector('.admin-status-badge') : null;
        if (badge) {
          const newStatus = select.value;
          badge.className = 'admin-status-badge admin-status-' + newStatus;
          badge.textContent = newStatus;
        }
      });
    });

    /* Filter bar — visual/client-side only for this static dataset.
       Real filtering becomes a server-side query in Phase 6. */
    const statusFilter = document.querySelector('.admin-filter-status');
    const searchFilter = document.querySelector('.admin-filter-search input');

    function applyOrderFilters() {
      const statusValue = statusFilter ? statusFilter.value : 'all';
      const searchValue = searchFilter ? searchFilter.value.trim().toLowerCase() : '';

      ordersTable.querySelectorAll('tbody tr').forEach(function (row) {
        const rowStatus = row.dataset.status || '';
        const rowText = row.textContent.toLowerCase();

        const matchesStatus = statusValue === 'all' || rowStatus === statusValue;
        const matchesSearch = !searchValue || rowText.indexOf(searchValue) !== -1;

        row.style.display = (matchesStatus && matchesSearch) ? '' : 'none';
      });
    }

    if (statusFilter) statusFilter.addEventListener('change', applyOrderFilters);
    if (searchFilter) searchFilter.addEventListener('input', applyOrderFilters);
  }


/* ============================================================
     ADMIN PRODUCTS PAGE (admin/products.php) — only runs if the
     products table exists on the page.
     ============================================================ */
  const productsTable = document.querySelector('.admin-products-table');

  if (productsTable) {
    /* Select-all checkbox */
    const selectAllCheckbox = productsTable.querySelector('thead .admin-checkbox');
    const rowCheckboxes = productsTable.querySelectorAll('tbody .admin-checkbox');

    if (selectAllCheckbox) {
      selectAllCheckbox.addEventListener('change', function () {
        rowCheckboxes.forEach(function (cb) { cb.checked = selectAllCheckbox.checked; });
      });
    }

    rowCheckboxes.forEach(function (cb) {
      cb.addEventListener('change', function () {
        if (!cb.checked && selectAllCheckbox) selectAllCheckbox.checked = false;
      });
    });

    /* Delete confirmation — visual only. Real deletion is a Phase 6
       server-side action (with a proper confirm dialog, not a native
       browser confirm()) against the products table. */
    productsTable.querySelectorAll('.delete-btn').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        const row = btn.closest('tr');
        const name = row ? row.querySelector('.product-cell-info strong') : null;
        const label = name ? name.textContent : 'this product';
        const confirmed = window.confirm('Delete "' + label + '"? This cannot be undone.');
        if (confirmed && row) {
          row.style.opacity = '0';
          setTimeout(function () { row.remove(); }, 200);
        }
      });
    });

    /* Filter bar — same client-side pattern as the orders page,
       becomes a server-side query in Phase 6. */
    const productSearch = document.querySelector('.admin-product-search input');
    const categoryFilter = document.querySelector('.admin-filter-category');
    const productStatusFilter = document.querySelector('.admin-filter-product-status');

    function applyProductFilters() {
      const searchValue = productSearch ? productSearch.value.trim().toLowerCase() : '';
      const categoryValue = categoryFilter ? categoryFilter.value : 'all';
      const statusValue = productStatusFilter ? productStatusFilter.value : 'all';

      productsTable.querySelectorAll('tbody tr').forEach(function (row) {
        const rowCategory = row.dataset.category || '';
        const rowStatus = row.dataset.status || '';
        const rowText = row.textContent.toLowerCase();

        const matchesSearch = !searchValue || rowText.indexOf(searchValue) !== -1;
        const matchesCategory = categoryValue === 'all' || rowCategory === categoryValue;
        const matchesStatus = statusValue === 'all' || rowStatus === statusValue;

        row.style.display = (matchesSearch && matchesCategory && matchesStatus) ? '' : 'none';
      });
    }

    if (productSearch) productSearch.addEventListener('input', applyProductFilters);
    if (categoryFilter) categoryFilter.addEventListener('change', applyProductFilters);
    if (productStatusFilter) productStatusFilter.addEventListener('change', applyProductFilters);
  }

});

/* ============================================================
   SLEEKPICK ADMIN — shared polish and demo interactions
   These interactions keep the uploaded design prototype usable while
   server-side persistence is connected. No secrets or credentials are
   stored in the browser.
   ============================================================ */
(function () {
  'use strict';

  function toast(message, tone) {
    const region = document.querySelector('[data-admin-toast-region]');
    if (!region) return;
    const item = document.createElement('div');
    item.className = 'admin-toast admin-toast-' + (tone || 'info');
    item.innerHTML = '<i class="bi bi-' + (tone === 'success' ? 'check-circle' : tone === 'danger' ? 'exclamation-triangle' : 'info-circle') + '"></i><span></span><button type="button" aria-label="Dismiss notification"><i class="bi bi-x"></i></button>';
    item.querySelector('span').textContent = message;
    item.querySelector('button').addEventListener('click', function () { item.remove(); });
    region.appendChild(item);
    window.setTimeout(function () { item.classList.add('is-leaving'); window.setTimeout(function () { item.remove(); }, 220); }, 3600);
  }

  function readStorage(key, fallback) {
    try {
      const value = window.localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      toast('Browser demo storage is unavailable.', 'danger');
    }
  }

  function csvDownload(filename, rows) {
    const csv = rows.map(function (row) {
      return row.map(function (cell) {
        return '"' + String(cell ?? '').replace(/"/g, '""') + '"';
      }).join(',');
    }).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(link.href);
  }

  function closePopover(popover) {
    if (!popover) return;
    popover.hidden = true;
    const trigger = popover.previousElementSibling;
    if (trigger) trigger.setAttribute('aria-expanded', 'false');
  }

  function validateForm(form) {
    let valid = true;
    form.querySelectorAll('.admin-form-group').forEach(function (group) {
      const input = group.querySelector('input, select, textarea');
      const error = group.querySelector('.admin-field-error');
      if (!input || !error) return;
      let message = '';
      if (input.required && !String(input.value).trim()) message = 'This field is required.';
      if (!message && input.type === 'number' && Number(input.value) < 0) message = 'Enter a value of zero or more.';
      if (!message && input.type === 'email' && input.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) message = 'Enter a valid email address.';
      error.textContent = message;
      group.classList.toggle('has-error', Boolean(message));
      if (message) valid = false;
    });
    return valid;
  }

  function updateCharacterCount(input) {
    const group = input.closest('.admin-form-group');
    const counter = group ? group.querySelector('[data-character-count]') : null;
    if (counter) counter.textContent = String(input.value.length);
  }

  document.addEventListener('DOMContentLoaded', function () {
    /* ---------- Shared popovers ---------- */
    document.querySelectorAll('[data-admin-profile], [data-admin-notifications]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        const menu = trigger.matches('[data-admin-profile]')
          ? document.querySelector('[data-admin-profile-menu]')
          : document.querySelector('[data-admin-notifications-menu]');
        const other = trigger.matches('[data-admin-profile]')
          ? document.querySelector('[data-admin-notifications-menu]')
          : document.querySelector('[data-admin-profile-menu]');
        closePopover(other);
        if (!menu) return;
        menu.hidden = !menu.hidden;
        trigger.setAttribute('aria-expanded', String(!menu.hidden));
      });
    });

    document.addEventListener('click', function (event) {
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (!target.closest('[data-admin-profile], [data-admin-notifications], [data-admin-profile-menu], [data-admin-notifications-menu]')) {
        closePopover(document.querySelector('[data-admin-profile-menu]'));
        closePopover(document.querySelector('[data-admin-notifications-menu]'));
      }
    });

    document.querySelectorAll('[data-admin-notifications-menu] a').forEach(function (link) {
      link.addEventListener('click', function () { closePopover(link.closest('[data-admin-notifications-menu]')); });
    });

    /* ---------- Global admin search ---------- */
    const globalSearch = document.querySelector('[data-admin-global-search]');
    if (globalSearch) {
      globalSearch.addEventListener('input', function () {
        const value = globalSearch.value.trim();
        const localTarget = document.querySelector('[data-product-search], [data-order-search], [data-customer-search], [data-category-search]');
        if (!localTarget) return;
        localTarget.value = value;
        localTarget.dispatchEvent(new Event('input', { bubbles: true }));
      });
    }

    /* ---------- Modal dialog ---------- */
    function closeModal(modal) {
      if (!modal) return;
      modal.hidden = true;
      document.body.classList.remove('modal-is-open');
    }

    document.querySelectorAll('[data-open-modal]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        const modal = document.querySelector('[data-modal="' + trigger.dataset.openModal + '"]');
        if (!modal) return;
        modal.hidden = false;
        document.body.classList.add('modal-is-open');
        const firstInput = modal.querySelector('input, select, textarea');
        if (firstInput) window.setTimeout(function () { firstInput.focus(); }, 50);
      });
    });
    document.querySelectorAll('[data-close-modal]').forEach(function (trigger) {
      trigger.addEventListener('click', function () { closeModal(trigger.closest('.admin-modal-backdrop')); });
    });
    document.querySelectorAll('.admin-modal-backdrop').forEach(function (backdrop) {
      backdrop.addEventListener('click', function (event) {
        if (event.target === backdrop) closeModal(backdrop);
      });
    });
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      closeModal(document.querySelector('.admin-modal-backdrop:not([hidden])'));
    });

    /* ---------- Character counters and image preview ---------- */
    document.querySelectorAll('[maxlength]').forEach(function (input) {
      if (input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement) {
        updateCharacterCount(input);
        input.addEventListener('input', function () { updateCharacterCount(input); });
      }
    });
    document.querySelectorAll('[data-color-input]').forEach(function (input) {
      const value = input.closest('.admin-color-picker')?.querySelector('[data-color-value]');
      const update = function () { if (value) value.textContent = input.value.toUpperCase(); };
      input.addEventListener('input', update);
      update();
    });
    document.querySelectorAll('[data-image-input]').forEach(function (input) {
      input.addEventListener('change', function () {
        const file = input.files && input.files[0];
        const preview = input.closest('.admin-card')?.querySelector('[data-image-preview]');
        const image = preview?.querySelector('img');
        if (!file || !preview || !image) return;
        if (!/^image\/(png|jpe?g|webp)$/.test(file.type) || file.size > 5 * 1024 * 1024) {
          input.value = '';
          toast('Choose a PNG, JPG, or WebP image under 5MB.', 'danger');
          return;
        }
        image.src = URL.createObjectURL(file);
        preview.hidden = false;
      });
    });
    document.querySelectorAll('[data-clear-image]').forEach(function (button) {
      button.addEventListener('click', function () {
        const card = button.closest('.admin-card');
        const input = card?.querySelector('[data-image-input]');
        const preview = card?.querySelector('[data-image-preview]');
        if (input) input.value = '';
        if (preview) preview.hidden = true;
      });
    });

    /* ---------- Categories ---------- */
    const categorySearch = document.querySelector('[data-category-search]');
    const categoryStatus = document.querySelector('[data-category-status]');
    const categoryRows = document.querySelectorAll('[data-category-row]');
    const categoryEmpty = document.querySelector('[data-category-empty]');
    function applyCategoryFilters() {
      if (!categoryRows.length) return;
      const search = categorySearch?.value.trim().toLowerCase() || '';
      const status = categoryStatus?.value || 'all';
      let visible = 0;
      categoryRows.forEach(function (row) {
        const matchesSearch = !search || row.textContent.toLowerCase().includes(search);
        const matchesStatus = status === 'all' || row.dataset.status === status;
        row.hidden = !(matchesSearch && matchesStatus);
        if (!row.hidden) visible += 1;
      });
      if (categoryEmpty) categoryEmpty.hidden = visible !== 0;
    }
    categorySearch?.addEventListener('input', applyCategoryFilters);
    categoryStatus?.addEventListener('change', applyCategoryFilters);
    document.querySelectorAll('[data-category-toggle]').forEach(function (button) {
      button.addEventListener('click', function () {
        const row = button.closest('[data-category-row]');
        const badge = row?.querySelector('.admin-status-badge');
        const icon = row?.querySelector('[data-category-toggle] i');
        if (!row || !badge || !icon) return;
        const active = row.dataset.status !== 'active';
        row.dataset.status = active ? 'active' : 'hidden';
        badge.className = 'admin-status-badge admin-status-' + row.dataset.status;
        badge.textContent = active ? 'Active' : 'Hidden';
        icon.className = 'bi bi-' + (active ? 'eye-slash' : 'eye');
        toast('Category visibility updated.', 'success');
        applyCategoryFilters();
      });
    });
    document.querySelectorAll('[data-category-delete]').forEach(function (button) {
      button.addEventListener('click', function () {
        const row = button.closest('[data-category-row]');
        const name = row?.querySelector('h2')?.textContent || 'this category';
        if (!row || !window.confirm('Remove "' + name + '" from this demo catalog?')) return;
        row.remove();
        toast('Category removed from the demo view.', 'success');
        applyCategoryFilters();
      });
    });
    const categoryForm = document.querySelector('[data-category-form]');
    categoryForm?.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!validateForm(categoryForm)) return;
      const values = Object.fromEntries(new FormData(categoryForm).entries());
      const grid = document.querySelector('[data-category-grid]');
      if (grid) {
        const card = document.createElement('article');
        card.className = 'admin-category-card';
        card.dataset.categoryRow = '';
        card.dataset.status = String(values.status || 'active');
        card.innerHTML = '<div class="admin-category-card-top"><span class="admin-category-icon"><i class="bi bi-layers"></i></span><div class="admin-row-actions"><button type="button" data-category-toggle aria-label="Toggle category visibility"><i class="bi bi-eye-slash"></i></button><button type="button" data-category-delete aria-label="Delete category"><i class="bi bi-trash3"></i></button></div></div><h2></h2><p></p><div class="admin-category-card-footer"><span><strong>0</strong> products</span><span class="admin-status-badge admin-status-active">Active</span></div><small>Added just now</small>';
        card.querySelector('h2').textContent = String(values.name || '');
        card.querySelector('p').textContent = String(values.description || 'New SLEEKPICK collection.');
        grid.prepend(card);
        card.querySelector('[data-category-toggle]')?.addEventListener('click', function () {
          const active = card.dataset.status !== 'active';
          card.dataset.status = active ? 'active' : 'hidden';
          const badge = card.querySelector('.admin-status-badge');
          const icon = card.querySelector('[data-category-toggle] i');
          if (badge) {
            badge.className = 'admin-status-badge admin-status-' + card.dataset.status;
            badge.textContent = active ? 'Active' : 'Hidden';
          }
          if (icon) icon.className = 'bi bi-' + (active ? 'eye-slash' : 'eye');
          toast('Category visibility updated.', 'success');
          applyCategoryFilters();
        });
        card.querySelector('[data-category-delete]')?.addEventListener('click', function () {
          card.remove();
          toast('Category removed from the demo view.', 'success');
          applyCategoryFilters();
        });
      }
      categoryForm.reset();
      categoryForm.closest('.admin-modal-backdrop').hidden = true;
      document.body.classList.remove('modal-is-open');
      toast('Category added to the demo catalog.', 'success');
      applyCategoryFilters();
    });

    /* ---------- Customers ---------- */
    const customerSearch = document.querySelector('[data-customer-search]');
    const customerStatus = document.querySelector('[data-customer-status]');
    const customerRows = document.querySelectorAll('[data-customer-row]');
    const customerEmpty = document.querySelector('[data-customer-empty]');
    const customerResults = document.querySelector('[data-customer-results]');
    function applyCustomerFilters() {
      if (!customerRows.length) return;
      const search = customerSearch?.value.trim().toLowerCase() || '';
      const status = customerStatus?.value || 'all';
      let visible = 0;
      customerRows.forEach(function (row) {
        const matchesSearch = !search || row.textContent.toLowerCase().includes(search);
        const matchesStatus = status === 'all' || row.dataset.status === status;
        row.hidden = !(matchesSearch && matchesStatus);
        if (!row.hidden) visible += 1;
      });
      if (customerResults) customerResults.textContent = 'Showing ' + visible + ' customer' + (visible === 1 ? '' : 's');
      if (customerEmpty) customerEmpty.hidden = visible !== 0;
    }
    customerSearch?.addEventListener('input', applyCustomerFilters);
    customerStatus?.addEventListener('change', applyCustomerFilters);
    document.querySelectorAll('[data-customer-view]').forEach(function (button) {
      button.addEventListener('click', function () {
        const row = button.closest('tr');
        const name = row?.querySelector('strong')?.textContent || 'Customer';
        toast('Customer profile for ' + name + ' is ready for the detail endpoint.', 'info');
      });
    });
    document.querySelector('[data-export-customers]')?.addEventListener('click', function () {
      const rows = [['Name', 'Email', 'Location', 'Orders', 'Total spent', 'Joined', 'Status']];
      document.querySelectorAll('[data-customer-row]:not([hidden])').forEach(function (row) {
        const cells = row.querySelectorAll('td');
        rows.push([cells[0]?.innerText.replace(/\n/g, ' '), cells[1]?.innerText, cells[2]?.innerText, cells[3]?.innerText, cells[4]?.innerText, cells[5]?.innerText]);
      });
      csvDownload('sleekpick-customers.csv', rows);
      toast('Customer CSV downloaded.', 'success');
    });

    document.querySelector('[data-export-orders]')?.addEventListener('click', function () {
      const rows = [['Order', 'Customer', 'Date', 'Items', 'Total', 'Status']];
      document.querySelectorAll('.admin-orders-table tbody tr:not([hidden])').forEach(function (row) {
        const cells = row.querySelectorAll('td');
        rows.push([cells[0]?.innerText, cells[1]?.innerText.replace(/\n/g, ' '), cells[2]?.innerText, cells[3]?.innerText, cells[4]?.innerText, cells[5]?.innerText]);
      });
      csvDownload('sleekpick-orders.csv', rows);
      toast('Orders CSV downloaded.', 'success');
    });

    /* ---------- Product create/edit demo persistence ---------- */
    const productForm = document.querySelector('[data-product-form]');
    productForm?.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!validateForm(productForm)) return;
      const formValues = Object.fromEntries(new FormData(productForm).entries());
      const stored = readStorage('sleekpick_admin_products', []);
      const id = productForm.dataset.mode === 'edit' ? String(productForm.dataset.productId) : 'demo-' + Date.now();
      const product = {
        id: id,
        name: String(formValues.name || ''),
        sku: String(formValues.sku || ''),
        category: String(formValues.category || ''),
        price: Number(formValues.price || 0),
        stock: Number(formValues.stock || 0),
        status: String(formValues.status || 'draft'),
        color: (productForm.querySelector('[data-color-input]')?.value || '#1B1F1F').replace('#', ''),
      };
      const next = stored.filter(function (item) { return String(item.id) !== id; });
      next.push(product);
      writeStorage('sleekpick_admin_products', next);
      toast(productForm.dataset.mode === 'edit' ? 'Product changes saved in the demo catalog.' : 'Product added to the demo catalog.', 'success');
      window.setTimeout(function () { window.location.href = 'products.php'; }, 650);
    });

    /* ---------- Product table demo rows and deletes ---------- */
    const productsTable = document.querySelector('.admin-products-table');
    if (productsTable) {
      const deleted = readStorage('sleekpick_admin_deleted_products', []);
      productsTable.querySelectorAll('tbody tr[data-product-id]').forEach(function (row) {
        if (deleted.includes(String(row.dataset.productId))) row.remove();
      });
      const stored = readStorage('sleekpick_admin_products', []);
      const categories = { outerwear: 'Outerwear', essentials: 'Essentials', bottoms: 'Bottoms', accessories: 'Accessories' };
      const tbody = productsTable.querySelector('tbody');
      stored.forEach(function (product) {
        if (!tbody || tbody.querySelector('[data-product-id="' + CSS.escape(String(product.id)) + '"]')) return;
        const row = document.createElement('tr');
        row.dataset.productId = String(product.id);
        row.dataset.category = product.category;
        row.dataset.status = product.status;
        const color = String(product.color || '1B1F1F').replace('#', '');
        row.innerHTML = '<td><input type="checkbox" class="admin-checkbox" aria-label="Select ' + product.name.replace(/"/g, '&quot;') + '"></td><td><div class="product-cell"><div class="product-thumb"><img src="https://placehold.co/100x130/' + color + '/FFFFFF?text=' + encodeURIComponent(product.name.slice(0, 1)) + '" alt=""></div><div class="product-cell-info"><strong></strong><span></span></div></div></td><td class="cell-muted"></td><td class="cell-strong">$' + Number(product.price).toFixed(2) + '</td><td><span class="stock-indicator ' + (product.stock === 0 ? 'out-of-stock' : product.stock <= 5 ? 'low-stock' : 'in-stock') + '">' + (product.stock === 0 ? 'Out of stock' : product.stock + ' in stock') + '</span></td><td><span class="admin-status-badge admin-status-' + product.status + '">' + product.status + '</span></td><td><div class="admin-row-actions"><a href="edit-product.php?id=' + encodeURIComponent(product.id) + '" aria-label="Edit product"><i class="bi bi-pencil"></i></a><button type="button" class="delete-btn" data-delete-product aria-label="Delete product"><i class="bi bi-trash3"></i></button></div></td>';
        row.querySelector('.product-cell-info strong').textContent = product.name;
        row.querySelector('.product-cell-info span').textContent = product.sku;
        row.querySelector('td:nth-child(3)').textContent = categories[product.category] || product.category;
        tbody.appendChild(row);
      });
      document.addEventListener('click', function (event) {
        const target = event.target;
        if (!(target instanceof Element)) return;
        const button = target.closest('[data-delete-product]');
        if (!button) return;
        const row = button.closest('tr[data-product-id]');
        if (!row) return;
        const ids = readStorage('sleekpick_admin_deleted_products', []);
        ids.push(String(row.dataset.productId));
        writeStorage('sleekpick_admin_deleted_products', Array.from(new Set(ids)));
      });
    }

    /* ---------- Settings ---------- */
    document.querySelectorAll('[data-settings-tab]').forEach(function (tab) {
      tab.addEventListener('click', function () {
        const key = tab.dataset.settingsTab;
        document.querySelectorAll('[data-settings-tab]').forEach(function (item) { item.classList.toggle('active', item === tab); });
        document.querySelectorAll('[data-settings-panel]').forEach(function (panel) {
          const active = panel.dataset.settingsPanel === key;
          panel.hidden = !active;
          panel.classList.toggle('active', active);
        });
      });
    });
    document.querySelectorAll('[data-save-settings]').forEach(function (button) {
      button.addEventListener('click', function () { toast('Settings saved in this demo session.', 'success'); });
    });
    document.querySelectorAll('[data-demo-action]').forEach(function (button) {
      button.addEventListener('click', function () { toast(button.dataset.demoAction + ' will be available when staff auth is connected.', 'info'); });
    });
    document.querySelectorAll('[data-demo-page]').forEach(function (link) {
      link.addEventListener('click', function (event) { event.preventDefault(); toast('Pagination is ready for the server-side query.', 'info'); });
    });
  });
}());