<?php
declare(strict_types=1);

/**
 * Shared SLEEKPICK admin presentation helpers.
 *
 * The uploaded project is currently in its design/prototype phase. These
 * helpers keep the dark admin shell, navigation, and accessibility markup
 * consistent while the database endpoints are wired in later.
 */

function adminEsc(string|int|float|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function adminNavItems(): array
{
    return [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'href' => 'dashboard.php', 'icon' => 'bi-grid'],
        ['key' => 'products', 'label' => 'Products', 'href' => 'products.php', 'icon' => 'bi-box-seam'],
        ['key' => 'categories', 'label' => 'Categories', 'href' => 'categories.php', 'icon' => 'bi-tags'],
        ['key' => 'orders', 'label' => 'Orders', 'href' => 'orders.php', 'icon' => 'bi-bag-check'],
        ['key' => 'customers', 'label' => 'Customers', 'href' => 'customers.php', 'icon' => 'bi-people'],
        ['key' => 'settings', 'label' => 'Settings', 'href' => 'settings.php', 'icon' => 'bi-sliders'],
    ];
}

function adminRenderHead(string $pageTitle, string $bodyClass = ''): void
{
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo adminEsc($pageTitle); ?></title>
        <meta name="robots" content="noindex, nofollow">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="../assets/css/admin.css">
    </head>
    <body class="<?php echo adminEsc($bodyClass); ?>">
    <?php
}

function adminRenderShellStart(string $activePage): void
{
    ?>
    <div class="admin-shell">
        <aside class="admin-sidebar" aria-label="Admin navigation">
            <div class="admin-sidebar-logo">SLEEK<span>PICK</span></div>

            <nav class="admin-sidebar-nav">
                <?php foreach (adminNavItems() as $item): ?>
                    <a href="<?php echo adminEsc($item['href']); ?>"
                       class="admin-nav-link<?php echo $activePage === $item['key'] ? ' active' : ''; ?>"
                       <?php echo $activePage === $item['key'] ? 'aria-current="page"' : ''; ?>>
                        <i class="bi <?php echo adminEsc($item['icon']); ?>" aria-hidden="true"></i>
                        <span><?php echo adminEsc($item['label']); ?></span>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="admin-sidebar-footer">
                <a href="login.php" class="admin-nav-link logout">
                    <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                    <span>Log Out</span>
                </a>
            </div>
        </aside>

        <div class="admin-sidebar-backdrop" data-admin-sidebar-backdrop></div>

        <div class="admin-main">
            <header class="admin-topbar">
                <div class="admin-topbar-left">
                    <button type="button" class="admin-sidebar-toggle" aria-label="Toggle sidebar" aria-expanded="false" data-admin-sidebar-toggle>
                        <i class="bi bi-list" aria-hidden="true"></i>
                    </button>
                    <a href="dashboard.php" class="admin-topbar-logo">SLEEK<span>PICK</span></a>
                    <label class="admin-topbar-search">
                        <i class="bi bi-search" aria-hidden="true"></i>
                        <span class="sr-only">Search the admin area</span>
                        <input type="search" placeholder="Search orders, products, customers…" data-admin-global-search>
                    </label>
                </div>

                <div class="admin-topbar-actions">
                    <a href="../public/index.php" class="admin-view-store-link" target="_blank" rel="noopener">
                        <i class="bi bi-box-arrow-up-right" aria-hidden="true"></i>
                        <span>View Store</span>
                    </a>
                    <button type="button" class="admin-notification-btn" aria-label="Show notifications" aria-expanded="false" data-admin-notifications>
                        <i class="bi bi-bell" aria-hidden="true"></i>
                        <span class="admin-notification-dot"></span>
                    </button>
                    <button type="button" class="admin-profile-btn" aria-expanded="false" data-admin-profile>
                        <span class="admin-profile-avatar">A</span>
                        <span class="admin-profile-copy">
                            Amara Okoye
                            <span class="role-tag">Admin</span>
                        </span>
                        <i class="bi bi-chevron-down profile-chevron" aria-hidden="true"></i>
                    </button>
                    <div class="admin-popover admin-profile-menu" data-admin-profile-menu hidden>
                        <span class="popover-kicker">Signed in as</span>
                        <strong>Amara Okoye</strong>
                        <span class="popover-email">amara.okoye@example.com</span>
                        <a href="settings.php"><i class="bi bi-person-gear" aria-hidden="true"></i> Account settings</a>
                        <a href="login.php" class="popover-danger"><i class="bi bi-box-arrow-right" aria-hidden="true"></i> Sign out</a>
                    </div>
                    <div class="admin-popover admin-notifications-menu" data-admin-notifications-menu hidden>
                        <div class="popover-heading"><strong>Notifications</strong><span class="admin-status-badge admin-status-processing">3 new</span></div>
                        <a href="products.php?stock=low"><i class="bi bi-exclamation-triangle" aria-hidden="true"></i><span><strong>3 products</strong><small>need a stock review</small></span></a>
                        <a href="orders.php?status=pending"><i class="bi bi-hourglass-split" aria-hidden="true"></i><span><strong>2 orders</strong><small>are waiting for action</small></span></a>
                        <a href="customers.php"><i class="bi bi-person-plus" aria-hidden="true"></i><span><strong>8 customers</strong><small>joined this week</small></span></a>
                    </div>
                </div>
            </header>

            <main class="admin-content">
    <?php
}

function adminRenderShellEnd(): void
{
    ?>
            </main>
        </div>
    </div>
    <div class="admin-toast-region" aria-live="polite" aria-atomic="true" data-admin-toast-region></div>
    <script src="../assets/js/admin.js"></script>
    </body>
    </html>
    <?php
}

function adminStatusBadge(string $status): string
{
    $safeStatus = strtolower(trim($status));
    return '<span class="admin-status-badge admin-status-' . adminEsc($safeStatus) . '">' . adminEsc(ucfirst($safeStatus)) . '</span>';
}