<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Shared Functions
 *
 * Reusable helpers used across actions/, api/, and pages. Starting
 * with session-cart helpers (needed by add-to-cart.php); more get
 * added here as later actions/ files are built, rather than each
 * action reimplementing its own version.
 */

/**
 * Send a JSON response and stop execution. Every actions/*.php
 * endpoint should exit through this so responses stay consistent.
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Build the unique key for a cart line item. Same product can appear
 * multiple times in the cart if size/color differ — this is what
 * cart_items.variant_id will represent once Phase 5 moves this to
 * product_variants in the database.
 */
function cartItemKey(int $productId, string $size, string $color): string
{
    return $productId . ':' . strtolower($size) . ':' . strtolower($color);
}

/**
 * Get the current session cart. Always an array of:
 * key => ['productId', 'name', 'price', 'size', 'color', 'quantity', 'image']
 */
function getCart(): array
{
    return $_SESSION['cart'] ?? [];
}

function saveCart(array $cart): void
{
    $_SESSION['cart'] = $cart;
}

/**
 * Add an item to the session cart, or increase its quantity if that
 * exact product+size+color combination is already in the cart.
 *
 * $maxQuantityPerLine guards against a single line item being pushed
 * to an unreasonable quantity via repeated/scripted requests.
 */
function addCartItem(
    int $productId,
    string $name,
    float $price,
    string $size,
    string $color,
    int $quantity,
    string $image,
    int $maxQuantityPerLine = 10
): array {
    $cart = getCart();
    $key = cartItemKey($productId, $size, $color);

    if (isset($cart[$key])) {
        $cart[$key]['quantity'] = min($maxQuantityPerLine, $cart[$key]['quantity'] + $quantity);
    } else {
        $cart[$key] = [
            'productId' => $productId,
            'name'      => $name,
            'price'     => $price,
            'size'      => $size,
            'color'     => $color,
            'quantity'  => min($maxQuantityPerLine, $quantity),
            'image'     => $image,
        ];
    }

    saveCart($cart);
    return $cart;
}

function getCartCount(array $cart): int
{
    $count = 0;
    foreach ($cart as $item) {
        $count += (int) $item['quantity'];
    }
    return $count;
}

function getCartSubtotal(array $cart): float
{
    $subtotal = 0.0;
    foreach ($cart as $item) {
        $subtotal += (float) $item['price'] * (int) $item['quantity'];
    }
    return $subtotal;
}

// ============================================================
// CSRF protection
//
// Every state-changing request (forms and fetch() calls alike) must
// carry the session token. HTML forms send it as a hidden `csrf_token`
// field; JSON fetch() calls send it either in the body or in the
// `X-CSRF-Token` header. verifyCsrf() accepts all three so no call
// site needs a special case.
// ============================================================

/** The session's CSRF token, generated once per session. */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Hidden input to drop inside every <form method="post">. */
function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

/** True when the request carries a valid token. */
function csrfTokenValid(?string $token): bool
{
    return is_string($token)
        && $token !== ''
        && !empty($_SESSION['csrf_token'])
        && hash_equals((string) $_SESSION['csrf_token'], $token);
}

/**
 * Guard for action endpoints: reject the request unless a valid token
 * is present. $json controls whether the failure is a JSON response
 * (fetch() endpoints) or a plain 403 page (classic form posts).
 */
function verifyCsrf(bool $json = true): void
{
    $token = $_POST['csrf_token']
        ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);

    if ($token === null) {
        // JSON body fallback — the raw input may already have been read,
        // so callers can also pass it through $GLOBALS['__json_input'].
        $input = $GLOBALS['__json_input'] ?? null;
        if (is_array($input)) {
            $token = $input['csrf_token'] ?? null;
        }
    }

    if (!csrfTokenValid(is_string($token) ? $token : null)) {
        if ($json) {
            jsonResponse(['success' => false, 'message' => 'Your session expired. Please refresh the page and try again.'], 403);
        }
        http_response_code(403);
        exit('Invalid or expired security token. Please go back, refresh the page and try again.');
    }
}

// ============================================================
// Output & input helpers
// ============================================================

/** Escape any value for safe HTML output (XSS defence). */
function e(string|int|float|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/** Read and decode a JSON request body, falling back to $_POST. */
function jsonInput(): array
{
    if (isset($GLOBALS['__json_input']) && is_array($GLOBALS['__json_input'])) {
        return $GLOBALS['__json_input'];
    }

    $decoded = json_decode((string) file_get_contents('php://input'), true);
    $input = is_array($decoded) ? $decoded : $_POST;

    $GLOBALS['__json_input'] = $input;
    return $input;
}

/** Format a money amount using the store currency symbol. */
function formatPrice(float $amount, string $symbol = '$'): string
{
    return $symbol . number_format($amount, 2);
}

/** URL-safe slug from a name (products, categories). */
function slugify(string $text): string
{
    $slug = strtolower(trim($text));
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug) ?? '';
    return trim($slug, '-');
}

// ============================================================
// Flash messages (one-shot notices across a redirect)
// ============================================================

function setFlash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function takeFlashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

/** Remove one line from the session cart. */
function removeCartItem(string $key): array
{
    $cart = getCart();
    unset($cart[$key]);
    saveCart($cart);
    return $cart;
}

/** Set an explicit quantity on one cart line (0 removes it). */
function updateCartItemQuantity(string $key, int $quantity, int $maxQuantityPerLine = 10): array
{
    $cart = getCart();

    if (!isset($cart[$key])) {
        return $cart;
    }

    if ($quantity < 1) {
        unset($cart[$key]);
    } else {
        $cart[$key]['quantity'] = min($maxQuantityPerLine, $quantity);
    }

    saveCart($cart);
    return $cart;
}
