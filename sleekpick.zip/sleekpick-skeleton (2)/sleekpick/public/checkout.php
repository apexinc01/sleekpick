<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Checkout Page
 *
 * Phase 2 (Design) prototype. Layout and client-side interactions only.
 *
 * IMPORTANT: Payment fields below are VISUAL PLACEHOLDERS ONLY. Per project
 * rules (Section 5: E-commerce, Section 12: Resource Research), a payment
 * provider must be researched from official documentation and explicitly
 * approved before any real payment integration is built — this page does
 * not invent a payment API/gateway/credentials. Real order placement,
 * address persistence, and payment processing are Phase 4/5 work.
 */

$pageTitle = 'Checkout — SLEEKPICK';

// Same hard-coded cart used on cart.php — in Phase 4 this comes from the session/DB cart.
$cartItems = [
    ['name' => 'Chrome Jacket',   'size' => 'M', 'color' => 'Black', 'price' => 128, 'qty' => 1, 'colorHex' => '1B1F1F'],
    ['name' => 'Voltage Tee',     'size' => 'L', 'color' => 'Teal',  'price' => 42,  'qty' => 2, 'colorHex' => '54BAC1'],
    ['name' => 'Vector Backpack', 'size' => 'One Size', 'color' => 'Black', 'price' => 120, 'qty' => 1, 'colorHex' => '1B1F1F'],
];

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['qty'];
}

// Saved addresses reused from the account page dataset, for the "choose a saved address" step.
$savedAddresses = [
    ['id' => 'home',   'label' => 'Home',   'default' => true,  'name' => 'Amara Okoye', 'line1' => '14 Aggrey Road', 'city' => 'Port Harcourt', 'state' => 'Rivers State', 'country' => 'Nigeria'],
    ['id' => 'office', 'label' => 'Office', 'default' => false, 'name' => 'Amara Okoye', 'line1' => '22 Trans Amadi Industrial Layout', 'city' => 'Port Harcourt', 'state' => 'Rivers State', 'country' => 'Nigeria'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="Complete your SLEEKPICK order.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>

    <!-- ================= PRELOADER ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>

    <!-- ================= HEADER (simplified for checkout) ================= -->
    <header id="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">SLEEK<span>PICK</span></a>
            <nav class="main-nav" aria-label="Primary">
                <a href="cart.php"><i class="bi bi-arrow-left"></i> Back to Cart</a>
            </nav>
            <div class="header-actions">
                <span style="font-size:0.8rem; color: var(--color-gray); display:flex; align-items:center; gap:0.4rem;">
                    <i class="bi bi-shield-lock"></i> Secure Checkout
                </span>
            </div>
        </div>
    </header>

    <main>
        <!-- ================= PAGE HEADER ================= -->
        <section class="page-header">
            <div class="container">
                <nav class="breadcrumb" aria-label="Breadcrumb">
                    <a href="index.php">Home</a>
                    <i class="bi bi-chevron-right"></i>
                    <a href="cart.php">Cart</a>
                    <i class="bi bi-chevron-right"></i>
                    <span class="current">Checkout</span>
                </nav>
                <h1>Checkout</h1>
            </div>
        </section>

        <!-- ================= CHECKOUT ================= -->
        <section class="checkout-section">
            <div class="container">
                <form class="checkout-form" novalidate>
                    <div class="checkout-layout">

                        <!-- ---------- Left: steps ---------- -->
                        <div>

                            <!-- Step 1: Contact -->
                            <div class="checkout-block">
                                <div class="checkout-step-title">
                                    <span class="step-number">1</span> Contact Information
                                </div>
                                <div class="form-group">
                                    <label for="checkout-email">Email Address</label>
                                    <input type="email" id="checkout-email" required>
                                </div>
                            </div>

                            <!-- Step 2: Shipping Address -->
                            <div class="checkout-block">
                                <div class="checkout-step-title">
                                    <span class="step-number">2</span> Shipping Address
                                </div>

                                <div class="saved-address-grid">
                                    <?php foreach ($savedAddresses as $i => $addr): ?>
                                    <label class="saved-address-option">
                                        <input type="radio" name="saved_address" value="<?php echo htmlspecialchars($addr['id']); ?>" <?php echo $addr['default'] ? 'checked' : ''; ?>>
                                        <h4><?php echo htmlspecialchars($addr['label']); ?></h4>
                                        <p>
                                            <?php echo htmlspecialchars($addr['name']); ?><br>
                                            <?php echo htmlspecialchars($addr['line1']); ?><br>
                                            <?php echo htmlspecialchars($addr['city']); ?>, <?php echo htmlspecialchars($addr['state']); ?>
                                        </p>
                                    </label>
                                    <?php endforeach; ?>
                                </div>

                                <button type="button" class="new-address-toggle">
                                    <i class="bi bi-plus-circle"></i> Add a new address
                                </button>

                                <div class="new-address-form">
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="ship-first-name">First Name</label>
                                            <input type="text" id="ship-first-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="ship-last-name">Last Name</label>
                                            <input type="text" id="ship-last-name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="ship-address1">Street Address</label>
                                        <input type="text" id="ship-address1">
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="ship-city">City</label>
                                            <input type="text" id="ship-city">
                                        </div>
                                        <div class="form-group">
                                            <label for="ship-state">State</label>
                                            <input type="text" id="ship-state">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="ship-postal">Postal Code</label>
                                            <input type="text" id="ship-postal">
                                        </div>
                                        <div class="form-group">
                                            <label for="ship-phone">Phone Number</label>
                                            <input type="tel" id="ship-phone">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Step 3: Shipping Method -->
                            <div class="checkout-block">
                                <div class="checkout-step-title">
                                    <span class="step-number">3</span> Shipping Method
                                </div>

                                <label class="shipping-method-option">
                                    <span class="shipping-method-left">
                                        <input type="radio" name="shipping_method" value="standard" checked>
                                        <span><strong>Standard Shipping</strong><span>3&ndash;5 business days</span></span>
                                    </span>
                                    <span class="shipping-method-price">Free</span>
                                </label>

                                <label class="shipping-method-option">
                                    <span class="shipping-method-left">
                                        <input type="radio" name="shipping_method" value="express">
                                        <span><strong>Express Shipping</strong><span>1&ndash;2 business days</span></span>
                                    </span>
                                    <span class="shipping-method-price">$15.00</span>
                                </label>

                                <label class="shipping-method-option">
                                    <span class="shipping-method-left">
                                        <input type="radio" name="shipping_method" value="overnight">
                                        <span><strong>Overnight Shipping</strong><span>Next business day</span></span>
                                    </span>
                                    <span class="shipping-method-price">$25.00</span>
                                </label>
                            </div>

                            <!-- Step 4: Payment (visual placeholder only — see file header note) -->
                            <div class="checkout-block">
                                <div class="checkout-step-title">
                                    <span class="step-number">4</span> Payment
                                </div>

                                <div class="payment-note">
                                    <i class="bi bi-info-circle"></i>
                                    <span>Payment fields shown here are a visual placeholder for Phase 2 design. No real payment provider is connected yet — that requires its own research and approval step in Phase 5.</span>
                                </div>

                                <div class="card-icons">
                                    <i class="bi bi-credit-card"></i>
                                    <i class="bi bi-credit-card-2-front"></i>
                                </div>

                                <div class="form-group">
                                    <label for="card-number">Card Number</label>
                                    <input type="text" id="card-number" placeholder="0000 0000 0000 0000" inputmode="numeric" disabled>
                                </div>

                                <div class="card-row">
                                    <div class="form-group">
                                        <label for="card-expiry">Expiry Date</label>
                                        <input type="text" id="card-expiry" placeholder="MM / YY" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label for="card-cvv">CVV</label>
                                        <input type="text" id="card-cvv" placeholder="123" disabled>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="card-name">Name on Card</label>
                                    <input type="text" id="card-name" disabled>
                                </div>
                            </div>
                        </div>

                        <!-- ---------- Right: order summary ---------- -->
                        <aside class="cart-summary">
                            <h2>Order Summary</h2>

                            <div class="checkout-summary-items">
                                <?php foreach ($cartItems as $item): ?>
                                <div class="checkout-summary-item">
                                    <img src="https://placehold.co/200x260/<?php echo htmlspecialchars($item['colorHex']); ?>/FFFFFF?text=<?php echo urlencode($item['name']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                    <div class="checkout-summary-item-info">
                                        <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                                        <span><?php echo htmlspecialchars($item['size']); ?> &middot; <?php echo htmlspecialchars($item['color']); ?> &middot; Qty <?php echo (int) $item['qty']; ?></span>
                                    </div>
                                    <span class="checkout-summary-item-price">$<?php echo number_format($item['price'] * $item['qty'], 2); ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="summary-row">
                                <span>Subtotal</span>
                                <span class="value checkout-summary-subtotal" data-subtotal="<?php echo (float) $subtotal; ?>">$<?php echo number_format($subtotal, 2); ?></span>
                            </div>
                            <div class="summary-row">
                                <span>Shipping</span>
                                <span class="value checkout-summary-shipping">Free</span>
                            </div>

                            <div class="summary-divider"></div>

                            <div class="summary-row total">
                                <span>Total</span>
                                <span class="value checkout-summary-total">$<?php echo number_format($subtotal, 2); ?></span>
                            </div>

                            <button type="submit" class="btn btn-primary place-order-btn">
                                <i class="bi bi-lock-fill"></i> Place Order
                            </button>

                            <p class="secure-note">
                                <i class="bi bi-shield-check"></i> Your information is secure and encrypted
                            </p>
                        </aside>

                    </div>
                </form>
            </div>
        </section>
    </main>

    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/cart.js"></script>
</body>
</html>