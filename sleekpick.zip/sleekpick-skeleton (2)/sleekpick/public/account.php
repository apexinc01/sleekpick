<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Account Dashboard
 *
 * Phase 2 (Design) prototype. Customer + order + address data is
 * hard-coded here; in Phase 4 this requires an authenticated session
 * (see includes/auth.php) and pulls from `users`, `orders`, and
 * `addresses` tables via includes/database.php.
 *
 * This page assumes a logged-in customer. Route-guarding (redirect
 * to login.php if no session) is added in Phase 4.
 */

$pageTitle = 'My Account — SLEEKPICK';

$customer = [
    'firstName' => 'Amara',
    'lastName'  => 'Okoye',
    'email'     => 'amara.okoye@example.com',
    'phone'     => '+234 801 234 5678',
];

$orders = [
    ['id' => 'SP-10482', 'date' => 'Aug 5, 2026',  'items' => 3, 'total' => 234.00, 'status' => 'delivered'],
    ['id' => 'SP-10417', 'date' => 'Jul 22, 2026', 'items' => 1, 'total' => 46.00,  'status' => 'shipped'],
    ['id' => 'SP-10390', 'date' => 'Jul 10, 2026', 'items' => 2, 'total' => 162.00, 'status' => 'processing'],
    ['id' => 'SP-10312', 'date' => 'Jun 28, 2026', 'items' => 1, 'total' => 34.00,  'status' => 'cancelled'],
    ['id' => 'SP-10201', 'date' => 'Jun 3, 2026',  'items' => 4, 'total' => 318.00, 'status' => 'delivered'],
];

$addresses = [
    ['label' => 'Home', 'default' => true,  'name' => 'Amara Okoye', 'line1' => '14 Aggrey Road', 'city' => 'Port Harcourt', 'state' => 'Rivers State', 'country' => 'Nigeria'],
    ['label' => 'Office', 'default' => false, 'name' => 'Amara Okoye', 'line1' => '22 Trans Amadi Industrial Layout', 'city' => 'Port Harcourt', 'state' => 'Rivers State', 'country' => 'Nigeria'],
];

$wishlistCount = 6;
$mostRecentOrder = $orders[0] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="Manage your SLEEKPICK account, orders, and addresses.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>

    <!-- ================= PRELOADER ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>

    <!-- ================= HEADER ================= -->
    <header id="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">SLEEK<span>PICK</span></a>

            <nav class="main-nav" aria-label="Primary">
                <a href="index.php">Home</a>
                <a href="shop.php">Shop</a>
                <a href="shop.php?category=new">New Arrivals</a>
                <a href="shop.php?category=accessories">Accessories</a>
            </nav>

            <div class="header-actions">
                <button type="button" aria-label="Search">
                    <i class="bi bi-search"></i>
                </button>
                <button type="button" aria-label="Account">
                    <i class="bi bi-person-fill" style="color: var(--color-primary);"></i>
                </button>
                <button type="button" aria-label="Wishlist">
                    <i class="bi bi-heart"></i>
                </button>
                <button type="button" aria-label="Cart, 3 items">
                    <i class="bi bi-bag"></i>
                    <span class="cart-count">3</span>
                </button>
                <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </div>
    </header>

    <main>
        <!-- ================= PAGE HEADER ================= -->
        <section class="page-header">
            <div class="container">
                <nav class="breadcrumb" aria-label="Breadcrumb">
                    <a href="index.php">Home</a>
                    <i class="bi bi-chevron-right"></i>
                    <span class="current">My Account</span>
                </nav>
                <div class="account-welcome">
                    <h1>Welcome back, <?php echo htmlspecialchars($customer['firstName']); ?></h1>
                    <p>Manage your orders, addresses, and account details.</p>
                </div>
            </div>
        </section>

        <!-- ================= ACCOUNT LAYOUT ================= -->
        <section class="account-section">
            <div class="container account-layout">

                <!-- ---------- Sidebar nav ---------- -->
                <aside class="account-sidebar">
                    <nav class="account-nav" aria-label="Account navigation">
                        <button type="button" class="account-nav-item active" data-panel="overview">
                            <i class="bi bi-grid"></i> Overview
                        </button>
                        <button type="button" class="account-nav-item" data-panel="orders">
                            <i class="bi bi-box-seam"></i> Order History
                        </button>
                        <button type="button" class="account-nav-item" data-panel="addresses">
                            <i class="bi bi-geo-alt"></i> Addresses
                        </button>
                        <button type="button" class="account-nav-item" data-panel="settings">
                            <i class="bi bi-gear"></i> Account Settings
                        </button>
                        <a href="logout.php" class="account-nav-item logout">
                            <i class="bi bi-box-arrow-right"></i> Log Out
                        </a>
                    </nav>
                </aside>

                <!-- ---------- Panels ---------- -->
                <div class="account-content">

                    <!-- Overview -->
                    <div class="account-panel active" data-panel="overview">
                        <h2 class="panel-heading">Account Overview</h2>

                        <div class="account-stats-grid">
                            <div class="stat-card">
                                <i class="bi bi-box-seam"></i>
                                <div><strong><?php echo count($orders); ?></strong><span>Total Orders</span></div>
                            </div>
                            <div class="stat-card">
                                <i class="bi bi-heart"></i>
                                <div><strong><?php echo $wishlistCount; ?></strong><span>Wishlist Items</span></div>
                            </div>
                            <div class="stat-card">
                                <i class="bi bi-geo-alt"></i>
                                <div><strong><?php echo count($addresses); ?></strong><span>Saved Addresses</span></div>
                            </div>
                        </div>

                        <?php if ($mostRecentOrder): ?>
                        <h3 style="font-size: 0.95rem; margin-bottom: var(--space-sm);">Most Recent Order</h3>
                        <div class="recent-order-preview">
                            <div class="order-meta">
                                <strong>Order #<?php echo htmlspecialchars($mostRecentOrder['id']); ?></strong>
                                Placed <?php echo htmlspecialchars($mostRecentOrder['date']); ?> &middot; <?php echo (int) $mostRecentOrder['items']; ?> item<?php echo $mostRecentOrder['items'] > 1 ? 's' : ''; ?> &middot; $<?php echo number_format($mostRecentOrder['total'], 2); ?>
                            </div>
                            <span class="status-badge status-<?php echo htmlspecialchars($mostRecentOrder['status']); ?>"><?php echo htmlspecialchars($mostRecentOrder['status']); ?></span>
                        </div>
                        <p style="margin-top: var(--space-md);">
                            <a href="#" data-goto-panel="orders" class="view-order-link">View all orders <i class="bi bi-arrow-right"></i></a>
                        </p>
                        <?php endif; ?>
                    </div>

                    <!-- Order History -->
                    <div class="account-panel" data-panel="orders">
                        <h2 class="panel-heading">Order History</h2>

                        <table class="order-table">
                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Date</th>
                                    <th>Items</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><strong>#<?php echo htmlspecialchars($order['id']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($order['date']); ?></td>
                                    <td><?php echo (int) $order['items']; ?></td>
                                    <td>$<?php echo number_format($order['total'], 2); ?></td>
                                    <td><span class="status-badge status-<?php echo htmlspecialchars($order['status']); ?>"><?php echo htmlspecialchars($order['status']); ?></span></td>
                                    <td><a href="#" class="view-order-link">View</a></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Addresses -->
                    <div class="account-panel" data-panel="addresses">
                        <h2 class="panel-heading">Saved Addresses</h2>

                        <div class="address-grid">
                            <?php foreach ($addresses as $address): ?>
                            <div class="address-card<?php echo $address['default'] ? ' default' : ''; ?>">
                                <?php if ($address['default']): ?>
                                    <span class="default-badge">Default</span>
                                <?php endif; ?>
                                <h4><?php echo htmlspecialchars($address['label']); ?></h4>
                                <p>
                                    <?php echo htmlspecialchars($address['name']); ?><br>
                                    <?php echo htmlspecialchars($address['line1']); ?><br>
                                    <?php echo htmlspecialchars($address['city']); ?>, <?php echo htmlspecialchars($address['state']); ?><br>
                                    <?php echo htmlspecialchars($address['country']); ?>
                                </p>
                                <div class="address-actions">
                                    <button type="button">Edit</button>
                                    <button type="button" class="delete">Delete</button>
                                </div>
                            </div>
                            <?php endforeach; ?>

                            <button type="button" class="add-address-card">
                                <i class="bi bi-plus-circle"></i>
                                Add New Address
                            </button>
                        </div>
                    </div>

                    <!-- Account Settings -->
                    <div class="account-panel" data-panel="settings">
                        <h2 class="panel-heading">Account Settings</h2>

                        <form class="settings-form">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first-name">First Name</label>
                                    <input type="text" id="first-name" value="<?php echo htmlspecialchars($customer['firstName']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="last-name">Last Name</label>
                                    <input type="text" id="last-name" value="<?php echo htmlspecialchars($customer['lastName']); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" value="<?php echo htmlspecialchars($customer['email']); ?>">
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="tel" id="phone" value="<?php echo htmlspecialchars($customer['phone']); ?>">
                            </div>

                            <div class="form-divider"></div>

                            <h3 style="font-size: 0.95rem; margin-bottom: var(--space-md);">Change Password</h3>

                            <div class="form-group">
                                <label for="current-password">Current Password</label>
                                <input type="password" id="current-password" autocomplete="current-password">
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="new-password">New Password</label>
                                    <input type="password" id="new-password" autocomplete="new-password">
                                </div>
                                <div class="form-group">
                                    <label for="confirm-password">Confirm New Password</label>
                                    <input type="password" id="confirm-password" autocomplete="new-password">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary save-settings-btn">Save Changes</button>
                            <p class="form-message" role="status" aria-live="polite"></p>
                        </form>
                    </div>

                </div>
            </div>
        </section>
    </main>

    <!-- ================= FOOTER ================= -->
    <footer id="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="logo">SLEEK<span style="color: var(--color-secondary);">PICK</span></div>
                    <p>Futuristic fashion for people who dress like it's already tomorrow.</p>
                    <div class="footer-social">
                        <a href="#" aria-label="SLEEKPICK on Instagram"><i class="bi bi-instagram"></i></a>
                        <a href="#" aria-label="SLEEKPICK on X"><i class="bi bi-twitter-x"></i></a>
                        <a href="#" aria-label="SLEEKPICK on TikTok"><i class="bi bi-tiktok"></i></a>
                    </div>
                </div>

                <div class="footer-col">
                    <h4>Shop</h4>
                    <ul>
                        <li><a href="shop.php?category=outerwear">Outerwear</a></li>
                        <li><a href="shop.php?category=essentials">Essentials</a></li>
                        <li><a href="shop.php?category=bottoms">Bottoms</a></li>
                        <li><a href="shop.php?category=accessories">Accessories</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Account</h4>
                    <ul>
                        <li><a href="login.php">Sign In</a></li>
                        <li><a href="register.php">Create Account</a></li>
                        <li><a href="account.php">Order History</a></li>
                        <li><a href="cart.php">Cart</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Shipping & Returns</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <span>&copy; <?php echo date('Y'); ?> SLEEKPICK. All rights reserved.</span>
                <div>
                    <a href="#">Terms</a>
                    <a href="#">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="../assets/js/main.js"></script>
</body>
</html>