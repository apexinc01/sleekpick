<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Register Page
 *
 * Phase 2 (Design) prototype. Form posts nowhere yet — real submission
 * (server-side validation, password hashing via password_hash(),
 * duplicate-email check, session creation) is built in Phase 4 as
 * actions/register.php, per the project's auth security rules.
 */

$pageTitle = 'Create Account — SLEEKPICK';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="Create your SLEEKPICK account for faster checkout and order tracking.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>

    <!-- ================= PRELOADER ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>

    <!-- ================= HEADER (simplified for auth pages) ================= -->
    <header id="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">SLEEK<span>PICK</span></a>
          
            <div class="header-actions">
                <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </div>
    </header>

    <main>
        <section class="auth-section">
            <div class="auth-layout">

                <!-- ---------- Visual panel ---------- -->
                <div class="auth-visual corner-brackets">
                    <span></span><span></span><span></span><span></span>
                    <img src="https://picsum.photos/seed/sleekpick-register/1000/1300" alt="SLEEKPICK SS26 collection">
                    <div class="auth-visual-content">
                        <span class="section-eyebrow">Join SLEEKPICK</span>
                        <h2>Early access to every new drop.</h2>
                        <p>Create an account to save your details, track orders, and shop faster next time.</p>
                    </div>
                </div>

                <!-- ---------- Form panel ---------- -->
                <div class="auth-form-panel">
                    <div class="auth-card">
                        <a href="index.php" class="auth-back-link">
                            <i class="bi bi-arrow-left"></i> Back to Home
                        </a>

                        <h1>Create Account</h1>
                        <p class="auth-subtitle">Join for free — takes less than a minute.</p>

                        <form class="register-form" novalidate>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first-name">First Name</label>
                                    <input type="text" id="first-name" name="first_name" required>
                                    <p class="field-error"></p>
                                </div>
                                <div class="form-group">
                                    <label for="last-name">Last Name</label>
                                    <input type="text" id="last-name" name="last_name" required>
                                    <p class="field-error"></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" required>
                                <p class="field-error"></p>
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="password-input-wrap">
                                    <input type="password" id="password" name="password" required minlength="8" autocomplete="new-password">
                                    <button type="button" class="password-toggle-btn" aria-label="Show password">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </div>
                                <div class="password-strength">
                                    <div class="strength-bar"><div class="strength-bar-fill"></div></div>
                                    <span class="strength-label"></span>
                                </div>
                                <p class="field-error"></p>
                            </div>

                            <div class="form-group">
                                <label for="confirm-password">Confirm Password</label>
                                <div class="password-input-wrap">
                                    <input type="password" id="confirm-password" name="confirm_password" required autocomplete="new-password">
                                    <button type="button" class="password-toggle-btn" aria-label="Show password">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </div>
                                <p class="field-error"></p>
                            </div>

                            <div class="checkbox-group">
                                <input type="checkbox" id="agree-terms" name="agree_terms">
                                <label for="agree-terms">
                                    I agree to SLEEKPICK's <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.
                                </label>
                            </div>
                            <p class="field-error terms-error"></p>

                            <button type="submit" class="btn btn-primary auth-submit-btn">Create Account</button>
                        </form>

                        <div class="auth-divider">or</div>

                        <p class="auth-footer-note">
                            Already have an account? <a href="login.php">Sign In</a>
                        </p>
                    </div>
                </div>

            </div>
        </section>
    </main>

    <script src="../assets/js/main.js"></script>
</body>
</html>