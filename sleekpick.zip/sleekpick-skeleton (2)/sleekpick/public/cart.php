<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Cart Page
 *
 * Phase 2 (Design) prototype. Cart contents are hard-coded here;
 * in Phase 4 this reads from the `cart` + `cart_items` tables via
 * a session/user-linked cart (see includes/database.php, api/cart/).
 */

$pageTitle = 'Your Cart — SLEEKPICK';

// Hard-coded cart contents — placeholder until Phase 4/5 wire up real sessions.
$cartItems = [
    ['name' => 'Chrome Jacket',    'category' => 'Outerwear',  'size' => 'M', 'color' => 'Black', 'price' => 128, 'qty' => 1, 'colorHex' => '1B1F1F'],
    ['name' => 'Voltage Tee',      'category' => 'Essentials', 'size' => 'L', 'color' => 'Teal',  'price' => 42,  'qty' => 2, 'colorHex' => '54BAC1'],
    ['name' => 'Vector Backpack',  'category' => 'Accessories','size' => 'One Size', 'color' => 'Black', 'price' => 120, 'qty' => 1, 'colorHex' => '1B1F1F'],
];

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['qty'];
}

$freeShippingThreshold = 80;
$shipping = ($subtotal === 0 || $subtotal >= $freeShippingThreshold) ? 0 : 8;
$total = $subtotal + $shipping;
$amountToFreeShipping = max(0, $freeShippingThreshold - $subtotal);
$hasItems = count($cartItems) > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="Review your SLEEKPICK cart before checkout.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>

    <!-- ================= PRELOADER ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>

    <!-- ================= HEADER ================= -->
    <header id="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">SLEEK<span>PICK</span></a>

            <nav class="main-nav" aria-label="Primary">
                <a href="index.php">Home</a>
                <a href="shop.php">Shop</a>
                <a href="shop.php?category=new">New Arrivals</a>
                <a href="shop.php?category=accessories">Accessories</a>
            </nav>

            <div class="header-actions">
                <button type="button" aria-label="Search">
                    <i class="bi bi-search"></i>
                </button>
                <button type="button" aria-label="Account">
                    <i class="bi bi-person"></i>
                </button>
                <button type="button" aria-label="Wishlist">
                    <i class="bi bi-heart"></i>
                </button>
                <button type="button" aria-label="Cart, <?php echo count($cartItems); ?> items">
                    <i class="bi bi-bag"></i>
                    <span class="cart-count"><?php echo count($cartItems); ?></span>
                </button>
                <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </div>
    </header>

    <main>
        <!-- ================= PAGE HEADER ================= -->
        <section class="page-header">
            <div class="container">
                <nav class="breadcrumb" aria-label="Breadcrumb">
                    <a href="index.php">Home</a>
                    <i class="bi bi-chevron-right"></i>
                    <span class="current">Cart</span>
                </nav>
                <h1>Your Cart</h1>
            </div>
        </section>

        <!-- ================= CART ================= -->
        <section class="cart-section">
            <div class="container">

                <!-- ---------- Empty state (hidden by default via PHP condition below) ---------- -->
                <div class="empty-cart" style="<?php echo $hasItems ? 'display:none;' : ''; ?>">
                    <i class="bi bi-bag-x"></i>
                    <h2>Your cart is empty</h2>
                    <p>Looks like you haven't added anything yet. Let's fix that.</p>
                    <a href="shop.php" class="btn btn-primary">Continue Shopping</a>
                </div>

                <!-- ---------- Cart layout ---------- -->
                <div class="cart-layout" style="<?php echo $hasItems ? '' : 'display:none;'; ?>">

                    <!-- Items -->
                    <div>
                        <div class="cart-items">
                            <?php foreach ($cartItems as $item): ?>
                            <div class="cart-item" data-price="<?php echo (float) $item['price']; ?>">
                                <div class="cart-item-image">
                                    <img src="https://placehold.co/300x400/<?php echo htmlspecialchars($item['colorHex']); ?>/FFFFFF?text=<?php echo urlencode($item['name']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                </div>

                                <div class="cart-item-info">
                                    <span class="product-category"><?php echo htmlspecialchars($item['category']); ?></span>
                                    <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                    <p class="cart-item-variant">Size: <?php echo htmlspecialchars($item['size']); ?> &middot; Color: <?php echo htmlspecialchars($item['color']); ?></p>

                                    <div class="cart-item-controls">
                                        <div class="qty-stepper">
                                            <button type="button" class="qty-decrease" aria-label="Decrease quantity">&minus;</button>
                                            <input type="text" value="<?php echo (int) $item['qty']; ?>" inputmode="numeric" aria-label="Quantity">
                                            <button type="button" class="qty-increase" aria-label="Increase quantity">+</button>
                                        </div>
                                        <button type="button" class="remove-item-btn">
                                            <i class="bi bi-trash3"></i> Remove
                                        </button>
                                    </div>
                                </div>

                                <div class="cart-item-price">
                                    <span class="line-total">$<?php echo number_format($item['price'] * $item['qty'], 2); ?></span>
                                    <span class="unit-price">$<?php echo number_format($item['price'], 2); ?> each</span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <a href="shop.php" class="cart-back-link">
                            <i class="bi bi-arrow-left"></i> Continue Shopping
                        </a>
                    </div>

                    <!-- Order summary -->
                    <aside class="cart-summary">
                        <h2>Order Summary</h2>

                        <div class="summary-row">
                            <span>Subtotal</span>
                            <span class="value summary-subtotal">$<?php echo number_format($subtotal, 2); ?></span>
                        </div>
                        <div class="summary-row<?php echo $shipping === 0 ? ' free-shipping' : ''; ?>">
                            <span>Shipping</span>
                            <span class="value summary-shipping"><?php echo $shipping === 0 ? 'Free' : '$' . number_format($shipping, 2); ?></span>
                        </div>

                        <?php if ($amountToFreeShipping > 0): ?>
                            <p style="font-size:0.78rem; color: var(--color-gray); margin-top: -0.3rem; margin-bottom: var(--space-sm);">
                                Add $<?php echo number_format($amountToFreeShipping, 2); ?> more for free shipping
                            </p>
                        <?php endif; ?>

                        <form class="promo-form">
                            <label for="promo-code" class="visually-hidden">Promo code</label>
                            <input type="text" id="promo-code" placeholder="Promo code">
                            <button type="submit">Apply</button>
                        </form>

                        <div class="summary-divider"></div>

                        <div class="summary-row total">
                            <span>Total</span>
                            <span class="value summary-total">$<?php echo number_format($total, 2); ?></span>
                        </div>

                        <a href="checkout.php" class="btn btn-primary checkout-btn">
                            Proceed to Checkout <i class="bi bi-arrow-right"></i>
                        </a>

                        <p class="secure-note">
                            <i class="bi bi-shield-check"></i> Secure, encrypted checkout
                        </p>
                    </aside>
                </div>
            </div>
        </section>
    </main>

    <!-- ================= FOOTER ================= -->
    <footer id="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="logo">SLEEK<span style="color: var(--color-secondary);">PICK</span></div>
                    <p>Futuristic fashion for people who dress like it's already tomorrow.</p>
                    <div class="footer-social">
                        <a href="#" aria-label="SLEEKPICK on Instagram"><i class="bi bi-instagram"></i></a>
                        <a href="#" aria-label="SLEEKPICK on X"><i class="bi bi-twitter-x"></i></a>
                        <a href="#" aria-label="SLEEKPICK on TikTok"><i class="bi bi-tiktok"></i></a>
                    </div>
                </div>

                <div class="footer-col">
                    <h4>Shop</h4>
                    <ul>
                        <li><a href="shop.php?category=outerwear">Outerwear</a></li>
                        <li><a href="shop.php?category=essentials">Essentials</a></li>
                        <li><a href="shop.php?category=bottoms">Bottoms</a></li>
                        <li><a href="shop.php?category=accessories">Accessories</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Account</h4>
                    <ul>
                        <li><a href="login.php">Sign In</a></li>
                        <li><a href="register.php">Create Account</a></li>
                        <li><a href="account.php">Order History</a></li>
                        <li><a href="cart.php">Cart</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Shipping & Returns</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <span>&copy; <?php echo date('Y'); ?> SLEEKPICK. All rights reserved.</span>
                <div>
                    <a href="#">Terms</a>
                    <a href="#">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/cart.js"></script>
</body>
</html>