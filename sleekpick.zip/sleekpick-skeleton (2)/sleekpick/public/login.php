<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Login Page
 *
 * Phase 2 (Design) prototype. Form posts nowhere yet — real authentication
 * (server-side validation, password_verify(), session creation, redirect)
 * is built in Phase 4 as actions/login.php, per the project's auth
 * security rules. Never trust client-side validation alone.
 */

$pageTitle = 'Sign In — SLEEKPICK';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="Sign in to your SLEEKPICK account.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>

    <!-- ================= PRELOADER ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>

    <!-- ================= HEADER (simplified for auth pages) ================= -->
    <header id="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">SLEEK<span>PICK</span></a>
           
            <div class="header-actions">
                <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </div>
    </header>

    <main>
        <section class="auth-section">
            <div class="auth-layout">

                <!-- ---------- Visual panel ---------- -->
                <div class="auth-visual corner-brackets">
                    <span></span><span></span><span></span><span></span>
                    <img src="https://picsum.photos/seed/sleekpick-login/1000/1300" alt="SLEEKPICK SS26 collection">
                    <div class="auth-visual-content">
                        <span class="section-eyebrow">Welcome Back</span>
                        <h2>Pick up right where you left off.</h2>
                        <p>Sign in to view your orders, saved addresses, and wishlist.</p>
                    </div>
                </div>

                <!-- ---------- Form panel ---------- -->
                <div class="auth-form-panel">
                    <div class="auth-card">
                        <a href="index.php" class="auth-back-link">
                            <i class="bi bi-arrow-left"></i> Back to Home
                        </a>

                        <h1>Sign In</h1>
                        <p class="auth-subtitle">Welcome back — enter your details below.</p>

                        <form class="login-form" novalidate>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" required>
                                <p class="field-error"></p>
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="password-input-wrap">
                                    <input type="password" id="password" name="password" required autocomplete="current-password">
                                    <button type="button" class="password-toggle-btn" aria-label="Show password">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </div>
                                <p class="field-error"></p>
                            </div>

                            <div class="auth-options-row">
                                <div class="checkbox-group">
                                    <input type="checkbox" id="remember-me" name="remember_me">
                                    <label for="remember-me">Remember me</label>
                                </div>
                                <a href="#" class="forgot-password-link">Forgot Password?</a>
                            </div>

                            <button type="submit" class="btn btn-primary auth-submit-btn">Sign In</button>
                        </form>

                        <div class="auth-divider">or</div>

                        <p class="auth-footer-note">
                            Don't have an account? <a href="register.php">Create Account</a>
                        </p>
                    </div>
                </div>

            </div>
        </section>
    </main>

    <script src="../assets/js/main.js"></script>
</body>
</html>