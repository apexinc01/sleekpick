<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Product Detail Page
 *
 * Phase 2 (Design) prototype. Product is hard-coded here; in Phase 4
 * this loads via $_GET['id'] or $_GET['slug'] from the database
 * (products + product_variants + product_images tables).
 *
 * Placeholder images: placehold.co, per project decision.
 */

$pageTitle = 'Chrome Jacket — SLEEKPICK';

$product = [
    'name'        => 'Chrome Jacket',
    'category'    => 'Outerwear',
    'price'       => 128,
    'original'    => 160,
    'color_hex'   => '1B1F1F',
    'description' => 'A weatherproof shell built from a matte technical fabric with a subtle metallic finish. Engineered for movement, cut for the city.',
    'sizes'       => ['XS', 'S', 'M', 'L', 'XL'],
    'colors'      => [
        ['label' => 'Black', 'hex' => '1B1F1F'],
        ['label' => 'Teal',  'hex' => '448084'],
        ['label' => 'Red',   'hex' => 'C81A1A'],
    ],
    'in_stock'    => true,
];

$discountPercent = $product['original']
    ? (int) round((($product['original'] - $product['price']) / $product['original']) * 100)
    : 0;

$relatedProducts = [
    ['name' => 'Drift Trench Coat', 'category' => 'Outerwear',   'price' => 185, 'original' => null, 'badge' => null,  'color' => '448084'],
    ['name' => 'Halo Puffer Vest',  'category' => 'Outerwear',   'price' => 112, 'original' => null, 'badge' => null,  'color' => '8A9797'],
    ['name' => 'Pulse Hoodie',      'category' => 'Essentials',  'price' => 74,  'original' => null, 'badge' => 'New', 'color' => 'C81A1A'],
    ['name' => 'Vector Backpack',   'category' => 'Accessories', 'price' => 120, 'original' => 145, 'badge' => 'Sale','color' => '1B1F1F'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($product['description']); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body>

    <!-- ================= PRELOADER ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>

    <!-- ================= HEADER ================= -->
    <header id="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">SLEEK<span>PICK</span></a>

            <nav class="main-nav" aria-label="Primary">
                <a href="index.php">Home</a>
                <a href="shop.php" class="active">Shop</a>
                <a href="shop.php?category=new">New Arrivals</a>
                <a href="shop.php?category=accessories">Accessories</a>
            </nav>

            <div class="header-actions">
                <button type="button" aria-label="Search">
                    <i class="bi bi-search"></i>
                </button>
                <button type="button" aria-label="Account">
                    <i class="bi bi-person"></i>
                </button>
                <button type="button" aria-label="Wishlist">
                    <i class="bi bi-heart"></i>
                </button>
                <button type="button" aria-label="Cart, 3 items">
                    <i class="bi bi-bag"></i>
                    <span class="cart-count">3</span>
                </button>
                <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </div>
    </header>

    <main>
        <!-- ================= PAGE HEADER / BREADCRUMB ================= -->
        <section class="page-header">
            <div class="container">
                <nav class="breadcrumb" aria-label="Breadcrumb">
                    <a href="index.php">Home</a>
                    <i class="bi bi-chevron-right"></i>
                    <a href="shop.php">Shop</a>
                    <i class="bi bi-chevron-right"></i>
                    <a href="shop.php?category=outerwear"><?php echo htmlspecialchars($product['category']); ?></a>
                    <i class="bi bi-chevron-right"></i>
                    <span class="current"><?php echo htmlspecialchars($product['name']); ?></span>
                </nav>
            </div>
        </section>

        <!-- ================= PRODUCT DETAIL ================= -->
        <section class="product-detail">
            <div class="container product-detail-layout">

                <!-- ---------- Gallery ---------- -->
                <div class="product-gallery">
                    <div class="gallery-main corner-brackets">
                        <span></span><span></span><span></span><span></span>
                        <img src="https://placehold.co/900x1100/<?php echo htmlspecialchars($product['color_hex']); ?>/FFFFFF?text=<?php echo urlencode($product['name']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?> — front view" id="main-product-image">
                    </div>
                    <div class="gallery-thumbs">
                        <button type="button" class="gallery-thumb active" aria-label="View front">
                            <img src="https://placehold.co/300x400/<?php echo htmlspecialchars($product['color_hex']); ?>/FFFFFF?text=Front" alt="">
                        </button>
                        <button type="button" class="gallery-thumb" aria-label="View back">
                            <img src="https://placehold.co/300x400/448084/FFFFFF?text=Back" alt="">
                        </button>
                        <button type="button" class="gallery-thumb" aria-label="View detail">
                            <img src="https://placehold.co/300x400/8A9797/FFFFFF?text=Detail" alt="">
                        </button>
                        <button type="button" class="gallery-thumb" aria-label="View worn">
                            <img src="https://placehold.co/300x400/54BAC1/1B1F1F?text=Worn" alt="">
                        </button>
                    </div>
                </div>

                <!-- ---------- Info panel ---------- -->
                <div class="product-info-panel">
                    <span class="detail-category"><?php echo htmlspecialchars($product['category']); ?></span>
                    <h1 class="detail-name"><?php echo htmlspecialchars($product['name']); ?></h1>

                    <div class="detail-price">
                        <span class="price-current">$<?php echo number_format($product['price']); ?></span>
                        <?php if ($product['original']): ?>
                            <span class="price-original">$<?php echo number_format($product['original']); ?></span>
                            <span class="price-save"><?php echo $discountPercent; ?>% off</span>
                        <?php endif; ?>
                    </div>

                    <p class="detail-desc"><?php echo htmlspecialchars($product['description']); ?></p>

                    <?php if ($product['in_stock']): ?>
                        <div class="stock-status"><i class="bi bi-circle-fill"></i> In stock, ready to ship</div>
                    <?php else: ?>
                        <div class="stock-status" style="color: var(--color-primary);"><i class="bi bi-circle-fill"></i> Out of stock</div>
                    <?php endif; ?>

                    <!-- Color -->
                    <div class="option-group">
                        <div class="option-label">
                            <span>Color</span>
                            <span class="selected-value" data-selected="color"><?php echo htmlspecialchars($product['colors'][0]['label']); ?></span>
                        </div>
                        <div class="color-options detail-color-options">
                            <?php foreach ($product['colors'] as $i => $color): ?>
                                <button type="button"
                                        class="color-swatch<?php echo $i === 0 ? ' active' : ''; ?>"
                                        style="background:#<?php echo htmlspecialchars($color['hex']); ?>"
                                        data-label="<?php echo htmlspecialchars($color['label']); ?>"
                                        aria-label="<?php echo htmlspecialchars($color['label']); ?>">
                                    <i class="bi bi-check-lg"></i>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Size -->
                    <div class="option-group">
                        <div class="option-label">
                            <span>Size</span>
                            <a href="#" class="size-guide-link">Size Guide</a>
                        </div>
                        <div class="size-options detail-size-options">
                            <?php foreach ($product['sizes'] as $size): ?>
                                <button type="button" class="size-btn"><?php echo htmlspecialchars($size); ?></button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Quantity -->
                    <div class="option-group">
                        <div class="option-label"><span>Quantity</span></div>
                        <div class="qty-stepper">
                            <button type="button" class="qty-decrease" aria-label="Decrease quantity">&minus;</button>
                            <input type="text" value="1" inputmode="numeric" aria-label="Quantity">
                            <button type="button" class="qty-increase" aria-label="Increase quantity">+</button>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="detail-actions">
                        <button type="button" class="add-to-cart-btn">
                            <i class="bi bi-bag-plus"></i> Add to Cart
                        </button>
                        <button type="button" class="detail-wishlist-btn" aria-label="Add to wishlist" aria-pressed="false">
                            <i class="bi bi-heart"></i>
                        </button>
                    </div>

                    <!-- Trust row -->
                    <div class="trust-row">
                        <div class="value-item">
                            <i class="bi bi-truck"></i>
                            <div><strong>Free Shipping</strong><span>Orders over $80</span></div>
                        </div>
                        <div class="value-item">
                            <i class="bi bi-arrow-repeat"></i>
                            <div><strong>Easy Returns</strong><span>30-day window</span></div>
                        </div>
                        <div class="value-item">
                            <i class="bi bi-shield-check"></i>
                            <div><strong>Secure Checkout</strong><span>Encrypted</span></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ---------- Tabs ---------- -->
            <div class="container">
                <div class="product-tabs">
                    <div class="tab-buttons">
                        <button type="button" class="tab-btn active" data-tab="description">Description</button>
                        <button type="button" class="tab-btn" data-tab="details">Details &amp; Care</button>
                        <button type="button" class="tab-btn" data-tab="shipping">Shipping &amp; Returns</button>
                    </div>

                    <div class="tab-panel active" data-tab="description">
                        <p><?php echo htmlspecialchars($product['description']); ?> Designed as part of the SS26 collection, built to layer over essentials without adding bulk.</p>
                    </div>

                    <div class="tab-panel" data-tab="details">
                        <ul>
                            <li>Matte technical shell fabric, water-resistant finish</li>
                            <li>Adjustable storm cuffs, full-length zip with wind flap</li>
                            <li>Machine wash cold, hang dry, do not iron print areas</li>
                            <li>Imported</li>
                        </ul>
                    </div>

                    <div class="tab-panel" data-tab="shipping">
                        <p>Free standard shipping on orders over $80. Orders ship within 1–2 business days. Returns accepted within 30 days of delivery in original condition with tags attached.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- ================= RELATED PRODUCTS ================= -->
        <section class="related-section">
            <div class="container">
                <div class="section-heading">
                    <span class="section-eyebrow">You Might Also Like</span>
                    <h2>Complete the look</h2>
                </div>

                <div class="product-grid">
                    <?php foreach ($relatedProducts as $rp): ?>
                    <article class="product-card">
                        <div class="product-media corner-brackets">
                            <span></span><span></span><span></span><span></span>
                            <?php if ($rp['badge']): ?>
                                <span class="product-badge"><?php echo htmlspecialchars($rp['badge']); ?></span>
                            <?php endif; ?>
                            <button type="button" class="wishlist-btn" aria-label="Add <?php echo htmlspecialchars($rp['name']); ?> to wishlist" aria-pressed="false">
                                <i class="bi bi-heart"></i>
                            </button>
                            <img src="https://placehold.co/500x650/<?php echo htmlspecialchars($rp['color']); ?>/FFFFFF?text=<?php echo urlencode($rp['name']); ?>" alt="<?php echo htmlspecialchars($rp['name']); ?> product photo" loading="lazy">
                        </div>
                        <div class="product-info">
                            <span class="product-category"><?php echo htmlspecialchars($rp['category']); ?></span>
                            <h3 class="product-name"><?php echo htmlspecialchars($rp['name']); ?></h3>
                            <div class="product-price">
                                <span class="price-current">$<?php echo number_format($rp['price']); ?></span>
                                <?php if ($rp['original']): ?>
                                    <span class="price-original">$<?php echo number_format($rp['original']); ?></span>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="add-to-cart-btn">
                                <i class="bi bi-bag-plus"></i> Add to Cart
                            </button>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </main>

    <!-- ================= FOOTER ================= -->
    <footer id="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="logo">SLEEK<span style="color: var(--color-secondary);">PICK</span></div>
                    <p>Futuristic fashion for people who dress like it's already tomorrow.</p>
                    <div class="footer-social">
                        <a href="#" aria-label="SLEEKPICK on Instagram"><i class="bi bi-instagram"></i></a>
                        <a href="#" aria-label="SLEEKPICK on X"><i class="bi bi-twitter-x"></i></a>
                        <a href="#" aria-label="SLEEKPICK on TikTok"><i class="bi bi-tiktok"></i></a>
                    </div>
                </div>

                <div class="footer-col">
                    <h4>Shop</h4>
                    <ul>
                        <li><a href="shop.php?category=outerwear">Outerwear</a></li>
                        <li><a href="shop.php?category=essentials">Essentials</a></li>
                        <li><a href="shop.php?category=bottoms">Bottoms</a></li>
                        <li><a href="shop.php?category=accessories">Accessories</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Account</h4>
                    <ul>
                        <li><a href="login.php">Sign In</a></li>
                        <li><a href="register.php">Create Account</a></li>
                        <li><a href="account.php">Order History</a></li>
                        <li><a href="cart.php">Cart</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Shipping & Returns</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <span>&copy; <?php echo date('Y'); ?> SLEEKPICK. All rights reserved.</span>
                <div>
                    <a href="#">Terms</a>
                    <a href="#">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/cart.js"></script>
</body>
</html>