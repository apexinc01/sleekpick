<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Login Page
 *
 * Phase 2 (Design) prototype. Form posts nowhere yet.
 *
 * Real implementation (Phase 4) must:
 * - Verify credentials against the `users` table, restricted to
 *   role IN ('admin', 'editor', 'support') — customers must never
 *   be able to authenticate here.
 * - Use password_verify() against the stored password_hash().
 * - Start a distinct admin session (separate from the customer
 *   session) and redirect based on role-specific permissions.
 * - Rate-limit / lock out repeated failed attempts.
 */

$pageTitle = 'Admin Login — SLEEKPICK';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="robots" content="noindex, nofollow">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

    <div class="admin-login-page">
        <div class="admin-glow-secondary"></div>

        <div class="admin-login-card corner-brackets">
            <span></span><span></span><span></span><span></span>

            <div class="admin-logo">SLEEKPICK</div>
            <p class="admin-login-tag">Admin Panel</p>

            <form class="admin-login-form" novalidate>

                <div class="admin-form-group">
                    <label for="admin-email">Email Address</label>
                    <div class="admin-input-wrap">
                        <i class="bi bi-envelope leading-icon"></i>
                        <input type="email" id="admin-email" class="admin-input" placeholder="you@sleekpick.com" required>
                    </div>
                    <p class="admin-field-error"></p>
                </div>

                <div class="admin-form-group">
                    <label for="admin-password">Password</label>
                    <div class="admin-input-wrap">
                        <i class="bi bi-lock leading-icon"></i>
                        <input type="password" id="admin-password" class="admin-input" placeholder="••••••••" autocomplete="current-password" required style="padding-right: 2.6rem;">
                        <button type="button" class="admin-password-toggle" aria-label="Show password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                    <p class="admin-field-error"></p>
                </div>

                <div class="admin-form-options">
                    <label class="admin-checkbox-group">
                        <input type="checkbox" id="admin-remember">
                        Remember me
                    </label>
                    <a href="#" class="admin-forgot-link">Forgot Password?</a>
                </div>

                <button type="submit" class="admin-btn admin-btn-primary admin-login-submit">
                    <i class="bi bi-box-arrow-in-right"></i> Sign In
                </button>
                <p class="admin-login-message" aria-live="polite"></p>
            </form>

            <p class="admin-security-note">
                <i class="bi bi-shield-lock"></i> Restricted access — staff only
            </p>

            <a href="../public/index.php" class="admin-back-to-store">
                <i class="bi bi-arrow-left"></i> Back to Store
            </a>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>