<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Edit Product — SLEEKPICK Admin';
$productId = (int) ($_GET['id'] ?? 1);
$products = [
    1 => ['name' => 'Chrome Jacket', 'sku' => 'SP-CHJ-M-BLK', 'category' => 'outerwear', 'price' => '128.00', 'stock' => '24', 'status' => 'active', 'description' => 'A reflective technical layer with a sharp structured cut.'],
    2 => ['name' => 'Drift Trench Coat', 'sku' => 'SP-DTC-L-TEA', 'category' => 'outerwear', 'price' => '185.00', 'stock' => '11', 'status' => 'active', 'description' => 'Fluid outerwear engineered for movement through the city.'],
    3 => ['name' => 'Halo Puffer Vest', 'sku' => 'SP-HPV-M-GRY', 'category' => 'outerwear', 'price' => '112.00', 'stock' => '3', 'status' => 'active', 'description' => 'Lightweight insulation with a sculpted, modular profile.'],
];
$product = $products[$productId] ?? $products[1];
$categories = ['outerwear' => 'Outerwear', 'essentials' => 'Essentials', 'bottoms' => 'Bottoms', 'accessories' => 'Accessories'];

adminRenderHead($pageTitle);
adminRenderShellStart('products');
?>
<div class="admin-page-header">
    <div><a href="products.php" class="admin-back-link"><i class="bi bi-arrow-left"></i> Back to products</a><span class="admin-eyebrow">Catalog editor</span><h1>Edit Product</h1><p>Update the product details, stock, and publishing state.</p></div>
    <span class="admin-id-chip">Product #<?php echo $productId; ?></span>
</div>

<form class="admin-editor-layout" data-admin-form data-product-form data-mode="edit" data-product-id="<?php echo $productId; ?>">
    <section class="admin-card admin-editor-main">
        <div class="admin-card-header"><div><h2>Product details</h2><p class="admin-card-subtitle">Changes are saved in this browser demo.</p></div><?php echo adminStatusBadge($product['status']); ?></div>
        <div class="admin-form-grid">
            <div class="admin-form-group full-width"><label for="product-name">Product name</label><input class="admin-input" id="product-name" name="name" value="<?php echo adminEsc($product['name']); ?>" required maxlength="80"><div class="admin-character-count"><span data-character-count>0</span>/80</div><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-sku">SKU</label><input class="admin-input" id="product-sku" name="sku" value="<?php echo adminEsc($product['sku']); ?>" required maxlength="24"><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-category">Category</label><select class="admin-input" id="product-category" name="category" required><?php foreach ($categories as $slug => $label): ?><option value="<?php echo adminEsc($slug); ?>" <?php echo $product['category'] === $slug ? 'selected' : ''; ?>><?php echo adminEsc($label); ?></option><?php endforeach; ?></select><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-price">Price (USD)</label><div class="admin-input-prefix"><span>$</span><input class="admin-input" id="product-price" name="price" type="number" min="0" step="0.01" value="<?php echo adminEsc($product['price']); ?>" required></div><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-stock">Stock</label><input class="admin-input" id="product-stock" name="stock" type="number" min="0" step="1" value="<?php echo adminEsc($product['stock']); ?>" required><p class="admin-field-error"></p></div>
            <div class="admin-form-group full-width"><label for="product-description">Description</label><textarea class="admin-input admin-textarea" id="product-description" name="description" rows="6" maxlength="500"><?php echo adminEsc($product['description']); ?></textarea><div class="admin-character-count"><span data-character-count>0</span>/500</div><p class="admin-field-error"></p></div>
        </div>
    </section>
    <aside class="admin-editor-side">
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Product image</h2><p class="admin-card-subtitle">Replace the visual when the drop changes.</p></div></div>
            <label class="admin-upload-zone" for="product-image"><i class="bi bi-cloud-arrow-up"></i><strong>Choose a new image</strong><span>PNG, JPG up to 5MB</span><input type="file" id="product-image" name="image" accept="image/png,image/jpeg,image/webp" data-image-input></label>
            <div class="admin-image-preview" data-image-preview hidden><img alt="Product preview"><button type="button" data-clear-image aria-label="Remove image"><i class="bi bi-x-lg"></i></button></div>
            <label class="admin-color-picker-label" for="product-color">Fallback color</label><div class="admin-color-picker"><input type="color" id="product-color" name="color" value="#1B1F1F" data-color-input><span data-color-value>#1B1F1F</span></div>
        </section>
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Publishing</h2><p class="admin-card-subtitle">Control storefront visibility.</p></div></div>
            <?php foreach (['draft' => ['Save as draft', 'Keep it hidden while you prepare the drop.'], 'active' => ['Published', 'Visible to shoppers in the live catalog.'], 'archived' => ['Archive', 'Keep the record for reporting, but hide it.']] as $status => $copy): ?>
                <label class="admin-radio-option"><input type="radio" name="status" value="<?php echo $status; ?>" <?php echo $product['status'] === $status ? 'checked' : ''; ?>><span><strong><?php echo $copy[0]; ?></strong><small><?php echo $copy[1]; ?></small></span></label>
            <?php endforeach; ?>
        </section>
    </aside>
    <div class="admin-form-actions editor-actions"><a href="products.php" class="admin-btn admin-btn-ghost">Cancel</a><button type="submit" class="admin-btn admin-btn-primary"><i class="bi bi-check2"></i> Save changes</button></div>
</form>
<?php
adminRenderShellEnd();