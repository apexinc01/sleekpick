<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Settings — SLEEKPICK Admin';

adminRenderHead($pageTitle);
adminRenderShellStart('settings');
?>
<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Control centre</span>
        <h1>Settings</h1>
        <p>Shape how the SLEEKPICK admin experience works for your team.</p>
    </div>
    <button type="button" class="admin-btn admin-btn-primary" data-save-settings><i class="bi bi-check2"></i> Save settings</button>
</div>

<div class="admin-settings-layout">
    <nav class="admin-settings-nav" aria-label="Settings sections">
        <button type="button" class="active" data-settings-tab="store"><i class="bi bi-shop"></i><span>Store profile<small>Public identity</small></span></button>
        <button type="button" data-settings-tab="notifications"><i class="bi bi-bell"></i><span>Notifications<small>Team alerts</small></span></button>
        <button type="button" data-settings-tab="security"><i class="bi bi-shield-lock"></i><span>Security<small>Access controls</small></span></button>
    </nav>
    <div class="admin-settings-panels">
        <section class="admin-card admin-settings-panel active" data-settings-panel="store">
            <div class="admin-card-header"><div><h2>Store profile</h2><p class="admin-card-subtitle">These details help keep customer-facing communications consistent.</p></div><i class="bi bi-shop settings-panel-icon"></i></div>
            <div class="admin-form-grid">
                <div class="admin-form-group"><label for="store-name">Store name</label><input class="admin-input" id="store-name" value="SLEEKPICK"></div>
                <div class="admin-form-group"><label for="store-email">Support email</label><input class="admin-input" id="store-email" type="email" value="hello@sleekpick.com"></div>
                <div class="admin-form-group"><label for="store-currency">Currency</label><select class="admin-input" id="store-currency"><option>USD — US Dollar</option><option>NGN — Nigerian Naira</option><option>GBP — British Pound</option></select></div>
                <div class="admin-form-group"><label for="store-timezone">Timezone</label><select class="admin-input" id="store-timezone"><option>Africa/Lagos</option><option>Europe/London</option><option>America/New_York</option></select></div>
                <div class="admin-form-group full-width"><label for="store-description">Store description</label><textarea class="admin-input admin-textarea" id="store-description" rows="4">Futuristic fashion for people who dress like it is already tomorrow.</textarea></div>
            </div>
        </section>
        <section class="admin-card admin-settings-panel" data-settings-panel="notifications" hidden>
            <div class="admin-card-header"><div><h2>Notifications</h2><p class="admin-card-subtitle">Choose which events deserve your attention.</p></div><i class="bi bi-bell settings-panel-icon"></i></div>
            <label class="admin-switch-row"><span><strong>New orders</strong><small>Get an alert whenever a new order is placed.</small></span><input type="checkbox" checked data-settings-toggle><span class="admin-switch"></span></label>
            <label class="admin-switch-row"><span><strong>Low stock</strong><small>Alert the team when inventory drops below five units.</small></span><input type="checkbox" checked data-settings-toggle><span class="admin-switch"></span></label>
            <label class="admin-switch-row"><span><strong>New customers</strong><small>Receive a weekly summary of newly registered customers.</small></span><input type="checkbox" data-settings-toggle><span class="admin-switch"></span></label>
        </section>
        <section class="admin-card admin-settings-panel" data-settings-panel="security" hidden>
            <div class="admin-card-header"><div><h2>Security</h2><p class="admin-card-subtitle">Keep staff access protected as the team grows.</p></div><i class="bi bi-shield-lock settings-panel-icon"></i></div>
            <div class="admin-security-callout"><i class="bi bi-info-circle"></i><span><strong>Authentication is ready for server wiring.</strong><small>The current uploaded skeleton keeps admin forms in demo mode. Connect the staff session and password verification before production.</small></span></div>
            <div class="admin-security-row"><span><strong>Admin session</strong><small>Separate staff session recommended</small></span><span class="admin-status-badge admin-status-pending">Not connected</span></div>
            <div class="admin-security-row"><span><strong>Two-factor authentication</strong><small>Optional extra layer for staff accounts</small></span><button type="button" class="admin-btn admin-btn-ghost admin-btn-small" data-demo-action="2FA setup">Configure</button></div>
        </section>
    </div>
</div>
<?php
adminRenderShellEnd();