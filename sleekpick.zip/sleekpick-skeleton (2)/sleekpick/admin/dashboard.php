<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Dashboard
 *
 * Phase 2 (Design) prototype. All figures below are hard-coded;
 * in Phase 6 this aggregates real data via includes/database.php:
 * - Stats: COUNT/SUM queries against orders, users, products
 * - Revenue chart: SUM(total_amount) grouped by day from orders
 * - Recent orders: latest rows from orders (same shape as orders.php)
 * - Top products: SUM(quantity) grouped by product from order_items
 * - Low stock: product_variants WHERE stock_quantity < threshold
 */

$pageTitle = 'Dashboard — SLEEKPICK Admin';

$stats = [
    ['label' => 'Total Revenue',  'value' => '$18,420', 'trend' => '+12.4%', 'direction' => 'up',   'icon' => 'bi-cash-stack',   'tone' => 'primary'],
    ['label' => 'Total Orders',   'value' => '312',     'trend' => '+8.1%',  'direction' => 'up',   'icon' => 'bi-bag-check',    'tone' => 'secondary'],
    ['label' => 'Total Customers','value' => '1,204',   'trend' => '+4.6%',  'direction' => 'up',   'icon' => 'bi-people',       'tone' => 'accent'],
    ['label' => 'Total Products', 'value' => '86',      'trend' => '-2.0%',  'direction' => 'down', 'icon' => 'bi-box-seam',     'tone' => 'neutral'],
];

// Last 7 days of revenue, for the CSS bar chart. Values are percentages of the tallest bar (0-100).
$revenueChart = [
    ['label' => 'Mon', 'height' => 55],
    ['label' => 'Tue', 'height' => 68],
    ['label' => 'Wed', 'height' => 40],
    ['label' => 'Thu', 'height' => 82],
    ['label' => 'Fri', 'height' => 60],
    ['label' => 'Sat', 'height' => 95],
    ['label' => 'Sun', 'height' => 100, 'today' => true],
];
$weeklyRevenueTotal = '$4,860';

$recentOrders = [
    ['id' => 'SP-10482', 'customer' => 'Amara Okoye', 'date' => 'Aug 5, 2026', 'total' => 234.00, 'status' => 'delivered'],
    ['id' => 'SP-10481', 'customer' => 'Tunde Bakare', 'date' => 'Aug 5, 2026', 'total' => 96.00,  'status' => 'processing'],
    ['id' => 'SP-10480', 'customer' => 'Chiamaka Eze', 'date' => 'Aug 4, 2026', 'total' => 170.00, 'status' => 'pending'],
    ['id' => 'SP-10479', 'customer' => 'David Yusuf',  'date' => 'Aug 4, 2026', 'total' => 318.00, 'status' => 'shipped'],
    ['id' => 'SP-10478', 'customer' => 'Ngozi Umeh',   'date' => 'Aug 3, 2026', 'total' => 42.00,  'status' => 'delivered'],
];

$topProducts = [
    ['name' => 'Chrome Jacket',   'unitsSold' => 84, 'revenue' => 10752.00, 'colorHex' => '1B1F1F'],
    ['name' => 'Voltage Tee',     'unitsSold' => 62, 'revenue' => 2604.00,  'colorHex' => '54BAC1'],
    ['name' => 'Vector Backpack', 'unitsSold' => 41, 'revenue' => 4920.00,  'colorHex' => '1B1F1F'],
    ['name' => 'Pulse Hoodie',    'unitsSold' => 37, 'revenue' => 2738.00,  'colorHex' => 'C81A1A'],
];

$lowStock = [
    ['name' => 'Halo Puffer Vest', 'sku' => 'SP-HPV-M-BLK', 'stock' => 3],
    ['name' => 'Signal Cap',       'sku' => 'SP-SGC-OS-RED', 'stock' => 5],
    ['name' => 'Flux Joggers',     'sku' => 'SP-FLJ-L-GRY',  'stock' => 2],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="robots" content="noindex, nofollow">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

    <div class="admin-shell">

        <!-- ================= SIDEBAR ================= -->
        <aside class="admin-sidebar">
            <div class="admin-sidebar-logo">SLEEK<span>PICK</span></div>

            <nav class="admin-sidebar-nav">
                <a href="dashboard.php" class="admin-nav-link active">
                    <i class="bi bi-grid"></i> Dashboard
                </a>
                <a href="products.php" class="admin-nav-link">
                    <i class="bi bi-box-seam"></i> Products
                </a>
                <a href="categories.php" class="admin-nav-link">
                    <i class="bi bi-tags"></i> Categories
                </a>
                <a href="orders.php" class="admin-nav-link">
                    <i class="bi bi-bag-check"></i> Orders
                </a>
                <a href="customers.php" class="admin-nav-link">
                    <i class="bi bi-people"></i> Customers
                </a>
                <a href="settings.php" class="admin-nav-link">
                    <i class="bi bi-sliders"></i> Settings
                </a>
            </nav>

            <div class="admin-sidebar-footer">
                <a href="login.php" class="admin-nav-link logout">
                    <i class="bi bi-box-arrow-right"></i> Log Out
                </a>
            </div>
        </aside>

        <!-- Backdrop shown behind the sidebar when it's open on tablet/mobile -->
        <div class="admin-sidebar-backdrop"></div>

        <!-- ================= MAIN ================= -->
        <div class="admin-main">

            <!-- ---------- Topbar ---------- -->
            <header class="admin-topbar">
                <div class="admin-topbar-left">
                    <button type="button" class="admin-sidebar-toggle" aria-label="Toggle sidebar">
                        <i class="bi bi-list"></i>
                    </button>

                    <a href="dashboard.php" class="admin-topbar-logo">SLEEK<span>PICK</span></a>

                    <div class="admin-topbar-search">
                        <i class="bi bi-search"></i>
                        <input type="text" placeholder="Search orders, products, customers…">
                    </div>
                </div>

                <div class="admin-topbar-actions">
                    <a href="../public/index.php" class="admin-view-store-link" target="_blank" rel="noopener">
                        <i class="bi bi-box-arrow-up-right"></i> <span>View Store</span>
                    </a>
                    <button type="button" class="admin-notification-btn" aria-label="Notifications">
                        <i class="bi bi-bell"></i>
                        <span class="admin-notification-dot"></span>
                    </button>
                    <button type="button" class="admin-profile-btn">
                        <span class="admin-profile-avatar">A</span>
                        <span>
                            Amara Okoye
                            <span class="role-tag">Admin</span>
                        </span>
                    </button>
                </div>
            </header>

            <!-- ---------- Page content ---------- -->
            <div class="admin-content">

                <div class="admin-page-header">
                    <div>
                        <h1>Dashboard</h1>
                        <p>Welcome back, Amara. Here's what's happening with SLEEKPICK today.</p>
                    </div>
                </div>

                <!-- Stats -->
                <div class="admin-stats-row">
                    <?php foreach ($stats as $stat): ?>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-<?php echo htmlspecialchars($stat['tone']); ?>">
                                <i class="bi <?php echo htmlspecialchars($stat['icon']); ?>"></i>
                            </span>
                            <span class="admin-stat-trend <?php echo htmlspecialchars($stat['direction']); ?>">
                                <i class="bi bi-arrow-<?php echo $stat['direction'] === 'up' ? 'up' : 'down'; ?>-short"></i>
                                <?php echo htmlspecialchars($stat['trend']); ?>
                            </span>
                        </div>
                        <div class="admin-stat-value"><?php echo htmlspecialchars($stat['value']); ?></div>
                        <div class="admin-stat-label"><?php echo htmlspecialchars($stat['label']); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Two-column: main (chart + recent orders) / side (top products + quick actions + low stock) -->
                <div class="admin-dashboard-grid">

                    <!-- Left column -->
                    <div>
                        <!-- Revenue chart -->
                        <div class="admin-card">
                            <div class="admin-card-header">
                                <h2>Revenue This Week</h2>
                                <a href="#" class="admin-link">View Report</a>
                            </div>

                            <div class="revenue-summary">
                                <span class="amount"><?php echo htmlspecialchars($weeklyRevenueTotal); ?></span>
                                <span class="admin-stat-trend up">
                                    <i class="bi bi-arrow-up-short"></i> +9.2% vs last week
                                </span>
                            </div>

                            <div class="revenue-chart-bars">
                                <?php foreach ($revenueChart as $day): ?>
                                <div class="chart-bar-wrap<?php echo !empty($day['today']) ? ' is-today' : ''; ?>">
                                    <div class="chart-bar" style="height: <?php echo (int) $day['height']; ?>%;" title="<?php echo htmlspecialchars($day['label']); ?>"></div>
                                    <span class="chart-bar-label"><?php echo htmlspecialchars($day['label']); ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Recent orders -->
                        <div class="admin-card">
                            <div class="admin-card-header">
                                <h2>Recent Orders</h2>
                                <a href="orders.php" class="admin-link">View All</a>
                            </div>

                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>Order</th>
                                        <th>Customer</th>
                                        <th>Date</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentOrders as $order): ?>
                                    <tr>
                                        <td class="cell-strong">#<?php echo htmlspecialchars($order['id']); ?></td>
                                        <td><?php echo htmlspecialchars($order['customer']); ?></td>
                                        <td class="cell-muted"><?php echo htmlspecialchars($order['date']); ?></td>
                                        <td class="cell-strong">$<?php echo number_format($order['total'], 2); ?></td>
                                        <td>
                                            <span class="admin-status-badge admin-status-<?php echo htmlspecialchars($order['status']); ?>">
                                                <?php echo htmlspecialchars($order['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Right column -->
                    <div>
                        <!-- Top products -->
                        <div class="admin-card">
                            <div class="admin-card-header">
                                <h2>Top Products</h2>
                                <a href="products.php" class="admin-link">View All</a>
                            </div>

                            <div class="top-products-list">
                                <?php foreach ($topProducts as $i => $product): ?>
                                <div class="top-product-item">
                                    <span class="top-product-rank"><?php echo $i + 1; ?></span>
                                    <div class="top-product-img">
                                        <img src="https://placehold.co/100x130/<?php echo htmlspecialchars($product['colorHex']); ?>/FFFFFF?text=<?php echo urlencode(substr($product['name'], 0, 1)); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                    </div>
                                    <div class="top-product-info">
                                        <strong><?php echo htmlspecialchars($product['name']); ?></strong>
                                        <span><?php echo (int) $product['unitsSold']; ?> sold</span>
                                    </div>
                                    <span class="top-product-revenue">$<?php echo number_format($product['revenue'], 0); ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Quick actions -->
                        <div class="admin-card">
                            <div class="admin-card-header">
                                <h2>Quick Actions</h2>
                            </div>

                            <div class="quick-actions-list">
                                <a href="add-product.php" class="quick-action-btn">
                                    <i class="bi bi-plus-lg"></i> Add New Product
                                </a>
                                <a href="categories.php" class="quick-action-btn">
                                    <i class="bi bi-tags"></i> Manage Categories
                                </a>
                                <a href="orders.php" class="quick-action-btn">
                                    <i class="bi bi-bag-check"></i> View Pending Orders
                                </a>
                                <a href="customers.php" class="quick-action-btn">
                                    <i class="bi bi-people"></i> Manage Customers
                                </a>
                            </div>
                        </div>

                        <!-- Low stock alert -->
                        <div class="admin-card">
                            <div class="admin-card-header">
                                <h2>Low Stock Alert</h2>
                                <a href="products.php" class="admin-link">View All</a>
                            </div>

                            <div>
                                <?php foreach ($lowStock as $item): ?>
                                <div class="low-stock-item">
                                    <div>
                                        <?php echo htmlspecialchars($item['name']); ?><br>
                                        <span class="cell-muted" style="font-size:0.75rem;"><?php echo htmlspecialchars($item['sku']); ?></span>
                                    </div>
                                    <span class="stock-count"><?php echo (int) $item['stock']; ?> left</span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>