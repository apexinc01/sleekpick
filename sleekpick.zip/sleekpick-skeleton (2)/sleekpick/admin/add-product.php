<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Add Product — SLEEKPICK Admin';
$categories = ['outerwear' => 'Outerwear', 'essentials' => 'Essentials', 'bottoms' => 'Bottoms', 'accessories' => 'Accessories'];

adminRenderHead($pageTitle);
adminRenderShellStart('products');
?>
<div class="admin-page-header">
    <div><a href="products.php" class="admin-back-link"><i class="bi bi-arrow-left"></i> Back to products</a><span class="admin-eyebrow">Catalog editor</span><h1>Add Product</h1><p>Build a product record ready for the SLEEKPICK storefront.</p></div>
</div>

<form class="admin-editor-layout" data-admin-form data-product-form data-mode="create">
    <section class="admin-card admin-editor-main">
        <div class="admin-card-header"><div><h2>Product details</h2><p class="admin-card-subtitle">The core information customers will see.</p></div><span class="admin-draft-pill"><i class="bi bi-circle-fill"></i> Draft</span></div>
        <div class="admin-form-grid">
            <div class="admin-form-group full-width"><label for="product-name">Product name</label><input class="admin-input" id="product-name" name="name" placeholder="e.g. Orbit Shell Jacket" required maxlength="80"><div class="admin-character-count"><span data-character-count>0</span>/80</div><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-sku">SKU</label><input class="admin-input" id="product-sku" name="sku" placeholder="SP-ORB-M-BLK" required maxlength="24"><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-category">Category</label><select class="admin-input" id="product-category" name="category" required><option value="">Choose category</option><?php foreach ($categories as $slug => $label): ?><option value="<?php echo adminEsc($slug); ?>"><?php echo adminEsc($label); ?></option><?php endforeach; ?></select><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-price">Price (USD)</label><div class="admin-input-prefix"><span>$</span><input class="admin-input" id="product-price" name="price" type="number" min="0" step="0.01" placeholder="0.00" required></div><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="product-stock">Initial stock</label><input class="admin-input" id="product-stock" name="stock" type="number" min="0" step="1" placeholder="0" required><p class="admin-field-error"></p></div>
            <div class="admin-form-group full-width"><label for="product-description">Description</label><textarea class="admin-input admin-textarea" id="product-description" name="description" rows="6" maxlength="500" placeholder="Describe the fit, fabric, and details."></textarea><div class="admin-character-count"><span data-character-count>0</span>/500</div><p class="admin-field-error"></p></div>
        </div>
    </section>

    <aside class="admin-editor-side">
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Product image</h2><p class="admin-card-subtitle">Use a local image or the color preview.</p></div></div>
            <label class="admin-upload-zone" for="product-image"><i class="bi bi-cloud-arrow-up"></i><strong>Choose an image</strong><span>PNG, JPG up to 5MB</span><input type="file" id="product-image" name="image" accept="image/png,image/jpeg,image/webp" data-image-input></label>
            <div class="admin-image-preview" data-image-preview hidden><img alt="Product preview"><button type="button" data-clear-image aria-label="Remove image"><i class="bi bi-x-lg"></i></button></div>
            <label class="admin-color-picker-label" for="product-color">Fallback color</label><div class="admin-color-picker"><input type="color" id="product-color" name="color" value="#1B1F1F" data-color-input><span data-color-value>#1B1F1F</span></div>
        </section>
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Publishing</h2><p class="admin-card-subtitle">Choose how this product enters the catalog.</p></div></div>
            <label class="admin-radio-option"><input type="radio" name="status" value="draft" checked><span><strong>Save as draft</strong><small>Keep it hidden while you prepare the drop.</small></span></label>
            <label class="admin-radio-option"><input type="radio" name="status" value="active"><span><strong>Publish now</strong><small>Make it visible to shoppers immediately.</small></span></label>
        </section>
    </aside>
    <div class="admin-form-actions editor-actions"><a href="products.php" class="admin-btn admin-btn-ghost">Cancel</a><button type="submit" class="admin-btn admin-btn-primary"><i class="bi bi-check2"></i> Save product</button></div>
</form>
<?php
adminRenderShellEnd();