<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Customers — SLEEKPICK Admin';
$customers = [
    ['id' => 1, 'name' => 'Amara Okoye', 'email' => 'amara.okoye@example.com', 'location' => 'Port Harcourt, NG', 'orders' => 12, 'spent' => 1640.00, 'joined' => 'Aug 05, 2026', 'status' => 'active'],
    ['id' => 2, 'name' => 'Tunde Bakare', 'email' => 'tunde.bakare@example.com', 'location' => 'Lagos, NG', 'orders' => 4, 'spent' => 386.00, 'joined' => 'Aug 03, 2026', 'status' => 'active'],
    ['id' => 3, 'name' => 'Chiamaka Eze', 'email' => 'chiamaka.eze@example.com', 'location' => 'Enugu, NG', 'orders' => 8, 'spent' => 912.00, 'joined' => 'Jul 29, 2026', 'status' => 'active'],
    ['id' => 4, 'name' => 'David Yusuf', 'email' => 'david.yusuf@example.com', 'location' => 'Abuja, NG', 'orders' => 2, 'spent' => 318.00, 'joined' => 'Jul 22, 2026', 'status' => 'active'],
    ['id' => 5, 'name' => 'Ngozi Umeh', 'email' => 'ngozi.umeh@example.com', 'location' => 'Owerri, NG', 'orders' => 1, 'spent' => 42.00, 'joined' => 'Jul 18, 2026', 'status' => 'inactive'],
    ['id' => 6, 'name' => 'Emeka Obi', 'email' => 'emeka.obi@example.com', 'location' => 'Benin City, NG', 'orders' => 6, 'spent' => 704.00, 'joined' => 'Jul 12, 2026', 'status' => 'active'],
    ['id' => 7, 'name' => 'Fatima Bello', 'email' => 'fatima.bello@example.com', 'location' => 'Kano, NG', 'orders' => 3, 'spent' => 278.00, 'joined' => 'Jul 04, 2026', 'status' => 'active'],
    ['id' => 8, 'name' => 'Ifeoma Nwosu', 'email' => 'ifeoma.nwosu@example.com', 'location' => 'Uyo, NG', 'orders' => 5, 'spent' => 596.00, 'joined' => 'Jun 28, 2026', 'status' => 'active'],
];

$activeCount = count(array_filter($customers, static fn(array $customer): bool => $customer['status'] === 'active'));
$customerValue = array_sum(array_column($customers, 'spent'));
$orderCount = array_sum(array_column($customers, 'orders'));

adminRenderHead($pageTitle);
adminRenderShellStart('customers');
?>
<div class="admin-page-header">
    <div><span class="admin-eyebrow">Customer relationships</span><h1>Customers</h1><p>Understand the people behind every SLEEKPICK order.</p></div>
    <button type="button" class="admin-btn admin-btn-secondary" data-export-customers><i class="bi bi-download"></i> Export CSV</button>
</div>

<div class="admin-stats-row">
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-secondary"><i class="bi bi-people"></i></span></div><div class="admin-stat-value"><?php echo count($customers); ?></div><div class="admin-stat-label">Total customers</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-accent"><i class="bi bi-person-check"></i></span></div><div class="admin-stat-value"><?php echo $activeCount; ?></div><div class="admin-stat-label">Active accounts</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-neutral"><i class="bi bi-bag-check"></i></span></div><div class="admin-stat-value"><?php echo $orderCount; ?></div><div class="admin-stat-label">Orders placed</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-primary"><i class="bi bi-cash-stack"></i></span></div><div class="admin-stat-value">$<?php echo number_format($customerValue, 0); ?></div><div class="admin-stat-label">Customer value</div></div>
</div>

<div class="admin-toolbar-card">
    <div class="admin-filter-search"><i class="bi bi-search" aria-hidden="true"></i><input type="search" placeholder="Search name, email, or location" aria-label="Search customers" data-customer-search></div>
    <select class="admin-select" aria-label="Filter customers by status" data-customer-status><option value="all">All customers</option><option value="active">Active</option><option value="inactive">Inactive</option></select>
</div>

<div class="admin-table-card">
    <table class="admin-table admin-customers-table">
        <thead><tr><th>Customer</th><th>Location</th><th>Orders</th><th>Total spent</th><th>Joined</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($customers as $customer): ?>
            <tr data-customer-row data-status="<?php echo adminEsc($customer['status']); ?>">
                <td><div class="customer-cell"><span class="customer-avatar"><?php echo adminEsc(strtoupper(substr($customer['name'], 0, 1))); ?></span><span><strong><?php echo adminEsc($customer['name']); ?></strong><small><?php echo adminEsc($customer['email']); ?></small></span></div></td>
                <td class="cell-muted"><?php echo adminEsc($customer['location']); ?></td><td class="cell-strong"><?php echo (int) $customer['orders']; ?></td><td class="cell-strong">$<?php echo number_format($customer['spent'], 2); ?></td><td class="cell-muted"><?php echo adminEsc($customer['joined']); ?></td><td><?php echo adminStatusBadge($customer['status']); ?></td>
                <td><div class="admin-row-actions"><button type="button" class="customer-view-btn" aria-label="View <?php echo adminEsc($customer['name']); ?>" data-customer-view><i class="bi bi-arrow-up-right"></i></button></div></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div class="admin-table-footer"><span class="results-note" data-customer-results>Showing <?php echo count($customers); ?> customers</span><nav class="admin-pagination" aria-label="Customers pagination"><span class="current">1</span><a href="#" data-demo-page>2</a><a href="#" data-demo-page>3</a><a href="#" aria-label="Next page" data-demo-page><i class="bi bi-chevron-right"></i></a></nav></div>
</div>
<div class="admin-empty-state" data-customer-empty hidden><i class="bi bi-person-x"></i><h2>No customers found</h2><p>Try a different search or status filter.</p></div>
<?php
adminRenderShellEnd();