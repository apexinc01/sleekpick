<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Orders
 *
 * Phase 2 (Design) prototype. Order data is hard-coded here; in Phase 6
 * this queries the `orders` + `order_items` + `users` tables via
 * includes/database.php, with pagination and filtering built server-side.
 *
 * Access control note: per the project's role model, this page should be
 * reachable by 'admin' and 'support' roles only (not 'editor') once
 * Phase 4/6 authentication + authorization is wired up.
 */

$pageTitle = 'Orders — SLEEKPICK Admin';

$orders = [
    ['id' => 'SP-10482', 'customer' => 'Amara Okoye',    'email' => 'amara.okoye@example.com',    'date' => 'Aug 5, 2026',  'items' => 3, 'total' => 234.00, 'status' => 'delivered'],
    ['id' => 'SP-10481', 'customer' => 'Tunde Bakare',    'email' => 'tunde.bakare@example.com',    'date' => 'Aug 5, 2026',  'items' => 1, 'total' => 96.00,  'status' => 'processing'],
    ['id' => 'SP-10480', 'customer' => 'Chiamaka Eze',    'email' => 'chiamaka.eze@example.com',    'date' => 'Aug 4, 2026',  'items' => 2, 'total' => 170.00, 'status' => 'pending'],
    ['id' => 'SP-10479', 'customer' => 'David Yusuf',     'email' => 'david.yusuf@example.com',     'date' => 'Aug 4, 2026',  'items' => 4, 'total' => 318.00, 'status' => 'shipped'],
    ['id' => 'SP-10478', 'customer' => 'Ngozi Umeh',      'email' => 'ngozi.umeh@example.com',      'date' => 'Aug 3, 2026',  'items' => 1, 'total' => 42.00,  'status' => 'delivered'],
    ['id' => 'SP-10477', 'customer' => 'Emeka Obi',       'email' => 'emeka.obi@example.com',       'date' => 'Aug 3, 2026',  'items' => 2, 'total' => 152.00, 'status' => 'cancelled'],
    ['id' => 'SP-10476', 'customer' => 'Fatima Bello',    'email' => 'fatima.bello@example.com',    'date' => 'Aug 2, 2026',  'items' => 1, 'total' => 34.00,  'status' => 'pending'],
    ['id' => 'SP-10475', 'customer' => 'Ifeoma Nwosu',    'email' => 'ifeoma.nwosu@example.com',    'date' => 'Aug 2, 2026',  'items' => 3, 'total' => 226.00, 'status' => 'processing'],
    ['id' => 'SP-10474', 'customer' => 'Chukwudi Ike',    'email' => 'chukwudi.ike@example.com',    'date' => 'Aug 1, 2026',  'items' => 1, 'total' => 128.00, 'status' => 'shipped'],
    ['id' => 'SP-10473', 'customer' => 'Blessing Achebe', 'email' => 'blessing.achebe@example.com', 'date' => 'Aug 1, 2026',  'items' => 2, 'total' => 88.00,  'status' => 'delivered'],
];

$statusCounts = ['pending' => 0, 'processing' => 0, 'shipped' => 0, 'delivered' => 0, 'cancelled' => 0];
$totalRevenue = 0;
foreach ($orders as $o) {
    $statusCounts[$o['status']] = ($statusCounts[$o['status']] ?? 0) + 1;
    if ($o['status'] !== 'cancelled') {
        $totalRevenue += $o['total'];
    }
}

$statusOptions = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="robots" content="noindex, nofollow">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

    <div class="admin-shell">

        <!-- ================= SIDEBAR ================= -->
        <aside class="admin-sidebar">
            <div class="admin-sidebar-logo">SLEEK<span>PICK</span></div>

            <nav class="admin-sidebar-nav">
                <a href="dashboard.php" class="admin-nav-link">
                    <i class="bi bi-grid"></i> Dashboard
                </a>
                <a href="products.php" class="admin-nav-link">
                    <i class="bi bi-box-seam"></i> Products
                </a>
                <a href="categories.php" class="admin-nav-link">
                    <i class="bi bi-tags"></i> Categories
                </a>
                <a href="orders.php" class="admin-nav-link active">
                    <i class="bi bi-bag-check"></i> Orders
                </a>
                <a href="customers.php" class="admin-nav-link">
                    <i class="bi bi-people"></i> Customers
                </a>
                <a href="settings.php" class="admin-nav-link">
                    <i class="bi bi-sliders"></i> Settings
                </a>
            </nav>

            <div class="admin-sidebar-footer">
                <a href="login.php" class="admin-nav-link logout">
                    <i class="bi bi-box-arrow-right"></i> Log Out
                </a>
            </div>
        </aside>

        <!-- ================= MAIN ================= -->
     
        <!-- Backdrop shown behind the sidebar when it's open on tablet/mobile -->
        <div class="admin-sidebar-backdrop"></div>

        <!-- ================= MAIN ================= -->
        <div class="admin-main">

            <!-- ---------- Topbar ---------- -->
            <header class="admin-topbar">
                <div class="admin-topbar-left">
                    <button type="button" class="admin-sidebar-toggle" aria-label="Toggle sidebar">
                        <i class="bi bi-list"></i>
                    </button>

                    <!-- Shown only on tablet/mobile, where the sidebar (which normally
                         carries the logo) is hidden off-canvas by default -->
                    <a href="dashboard.php" class="admin-topbar-logo">SLEEK<span>PICK</span></a>

                    <div class="admin-topbar-search">
                        <i class="bi bi-search"></i>
                        <input type="text" placeholder="Search orders, products, customers…">
                    </div>
                </div>

                <div class="admin-topbar-actions">
                    <a href="../public/index.php" class="admin-view-store-link" target="_blank" rel="noopener">
                        <i class="bi bi-box-arrow-up-right"></i> <span>View Store</span>
                    </a>
                    <button type="button" class="admin-notification-btn" aria-label="Notifications">
                        <i class="bi bi-bell"></i>
                        <span class="admin-notification-dot"></span>
                    </button>
                    <button type="button" class="admin-profile-btn">
                        <span class="admin-profile-avatar">A</span>
                        <span>
                            Amara Okoye
                            <span class="role-tag">Admin</span>
                        </span>
                    </button>
                </div>
           
            </header>

            <!-- ---------- Page content ---------- -->
            <div class="admin-content">

                <div class="admin-page-header">
                    <div>
                        <h1>Orders</h1>
                        <p>Track and manage every order placed on SLEEKPICK.</p>
                    </div>
                    <button type="button" class="admin-btn admin-btn-primary" data-export-orders>
                        <i class="bi bi-download"></i> Export CSV
                    </button>
                </div>

                <!-- Stats -->
                <div class="admin-stats-row">
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-neutral"><i class="bi bi-hourglass-split"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $statusCounts['pending']; ?></div>
                        <div class="admin-stat-label">Pending</div>
                    </div>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-secondary"><i class="bi bi-arrow-repeat"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $statusCounts['processing']; ?></div>
                        <div class="admin-stat-label">Processing</div>
                    </div>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-accent"><i class="bi bi-truck"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $statusCounts['shipped'] + $statusCounts['delivered']; ?></div>
                        <div class="admin-stat-label">Shipped / Delivered</div>
                    </div>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-primary"><i class="bi bi-cash-stack"></i></span>
                        </div>
                        <div class="admin-stat-value">$<?php echo number_format($totalRevenue, 2); ?></div>
                        <div class="admin-stat-label">Revenue (excl. cancelled)</div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="admin-filters-bar">
                    <div class="admin-filter-search">
                        <i class="bi bi-search"></i>
                        <input type="search" placeholder="Search by order # or customer" data-order-search>
                    </div>
                    <select class="admin-select admin-filter-status">
                        <option value="all">All Statuses</option>
                        <?php foreach ($statusOptions as $status): ?>
                            <option value="<?php echo htmlspecialchars($status); ?>"><?php echo ucfirst($status); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="date" class="admin-input admin-select">
                    <span style="color: var(--admin-text-dim); font-size: 0.82rem;">to</span>
                    <input type="date" class="admin-input admin-select">
                </div>

                <!-- Orders table -->
                <div class="admin-table-card">
                    <table class="admin-table admin-orders-table">
                        <thead>
                            <tr>
                                <th>Order</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Update Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr data-order-id="<?php echo htmlspecialchars($order['id']); ?>" data-status="<?php echo htmlspecialchars($order['status']); ?>">
                                <td class="cell-strong">#<?php echo htmlspecialchars($order['id']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($order['customer']); ?><br>
                                    <span class="cell-muted" style="font-size:0.78rem;"><?php echo htmlspecialchars($order['email']); ?></span>
                                </td>
                                <td class="cell-muted"><?php echo htmlspecialchars($order['date']); ?></td>
                                <td class="cell-muted"><?php echo (int) $order['items']; ?></td>
                                <td class="cell-strong">$<?php echo number_format($order['total'], 2); ?></td>
                                <td>
                                    <span class="admin-status-badge admin-status-<?php echo htmlspecialchars($order['status']); ?>">
                                        <?php echo htmlspecialchars($order['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <select class="status-update-select" aria-label="Update status for order <?php echo htmlspecialchars($order['id']); ?>">
                                        <?php foreach ($statusOptions as $status): ?>
                                            <option value="<?php echo htmlspecialchars($status); ?>" <?php echo $status === $order['status'] ? 'selected' : ''; ?>>
                                                <?php echo ucfirst($status); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <div class="admin-row-actions">
                                        <a href="#" aria-label="View order <?php echo htmlspecialchars($order['id']); ?>">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="admin-table-footer">
                        <span class="results-note">Showing <?php echo count($orders); ?> of 48 orders</span>
                        <nav class="admin-pagination" aria-label="Orders pagination">
                            <a href="#" aria-label="Previous page"><i class="bi bi-chevron-left"></i></a>
                            <span class="current">1</span>
                            <a href="#">2</a>
                            <a href="#">3</a>
                            <a href="#">4</a>
                            <a href="#">5</a>
                            <a href="#" aria-label="Next page"><i class="bi bi-chevron-right"></i></a>
                        </nav>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>