<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Products
 *
 * Phase 2 (Design) prototype. Product data is hard-coded here; in
 * Phase 6 this queries `products` + `product_variants` (for stock)
 * via includes/database.php, with pagination/filtering server-side.
 *
 * Access control note: reachable by 'admin' and 'editor' roles
 * (not 'support') once Phase 4/6 authorization is wired up.
 */

$pageTitle = 'Products — SLEEKPICK Admin';

$products = [
    ['id' => 1,  'name' => 'Chrome Jacket',         'sku' => 'SP-CHJ-M-BLK',  'category' => 'outerwear',   'price' => 128, 'stock' => 24, 'status' => 'active',   'colorHex' => '1B1F1F'],
    ['id' => 2,  'name' => 'Drift Trench Coat',      'sku' => 'SP-DTC-L-TEA',  'category' => 'outerwear',   'price' => 185, 'stock' => 11, 'status' => 'active',   'colorHex' => '448084'],
    ['id' => 3,  'name' => 'Halo Puffer Vest',       'sku' => 'SP-HPV-M-GRY',  'category' => 'outerwear',   'price' => 112, 'stock' => 3,  'status' => 'active',   'colorHex' => '8A9797'],
    ['id' => 4,  'name' => 'Voltage Tee',            'sku' => 'SP-VLT-L-TEA',  'category' => 'essentials',  'price' => 42,  'stock' => 58, 'status' => 'active',   'colorHex' => '54BAC1'],
    ['id' => 5,  'name' => 'Echo Turtleneck',        'sku' => 'SP-ECH-M-BLK',  'category' => 'essentials',  'price' => 68,  'stock' => 0,  'status' => 'active',   'colorHex' => '1B1F1F'],
    ['id' => 6,  'name' => 'Pulse Hoodie',           'sku' => 'SP-PLS-XL-RED', 'category' => 'essentials',  'price' => 74,  'stock' => 32, 'status' => 'draft',    'colorHex' => 'C81A1A'],
    ['id' => 7,  'name' => 'Nova Cargo Pants',       'sku' => 'SP-NCP-M-TEA',  'category' => 'bottoms',     'price' => 96,  'stock' => 19, 'status' => 'active',   'colorHex' => '448084'],
    ['id' => 8,  'name' => 'Flux Joggers',           'sku' => 'SP-FLJ-L-GRY',  'category' => 'bottoms',     'price' => 58,  'stock' => 2,  'status' => 'active',   'colorHex' => '8A9797'],
    ['id' => 9,  'name' => 'Vector Straight Jeans',  'sku' => 'SP-VSJ-M-BLK',  'category' => 'bottoms',     'price' => 89,  'stock' => 27, 'status' => 'archived', 'colorHex' => '1B1F1F'],
    ['id' => 10, 'name' => 'Signal Cap',             'sku' => 'SP-SGC-OS-RED', 'category' => 'accessories', 'price' => 34,  'stock' => 5,  'status' => 'active',   'colorHex' => 'C81A1A'],
    ['id' => 11, 'name' => 'Glass Visor Sunglasses', 'sku' => 'SP-GVS-OS-TEA', 'category' => 'accessories', 'price' => 46,  'stock' => 14, 'status' => 'active',   'colorHex' => '54BAC1'],
    ['id' => 12, 'name' => 'Vector Backpack',        'sku' => 'SP-VBP-OS-BLK', 'category' => 'accessories', 'price' => 120, 'stock' => 8,  'status' => 'active',   'colorHex' => '1B1F1F'],
];

$totalProducts = count($products);
$activeCount = count(array_filter($products, fn($p) => $p['status'] === 'active'));
$draftCount = count(array_filter($products, fn($p) => $p['status'] === 'draft'));
$lowStockCount = count(array_filter($products, fn($p) => $p['stock'] > 0 && $p['stock'] <= 5));

$categories = ['outerwear' => 'Outerwear', 'essentials' => 'Essentials', 'bottoms' => 'Bottoms', 'accessories' => 'Accessories'];
$statusOptions = ['draft' => 'Draft', 'active' => 'Active', 'archived' => 'Archived'];

function stockState(int $stock): array {
    if ($stock === 0) return ['out-of-stock', 'Out of stock'];
    if ($stock <= 5) return ['low-stock', $stock . ' left'];
    return ['in-stock', $stock . ' in stock'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="robots" content="noindex, nofollow">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

    <div class="admin-shell">

        <!-- ================= SIDEBAR ================= -->
        <aside class="admin-sidebar">
            <div class="admin-sidebar-logo">SLEEK<span>PICK</span></div>

            <nav class="admin-sidebar-nav">
                <a href="dashboard.php" class="admin-nav-link">
                    <i class="bi bi-grid"></i> Dashboard
                </a>
                <a href="products.php" class="admin-nav-link active">
                    <i class="bi bi-box-seam"></i> Products
                </a>
                <a href="categories.php" class="admin-nav-link">
                    <i class="bi bi-tags"></i> Categories
                </a>
                <a href="orders.php" class="admin-nav-link">
                    <i class="bi bi-bag-check"></i> Orders
                </a>
                <a href="customers.php" class="admin-nav-link">
                    <i class="bi bi-people"></i> Customers
                </a>
                <a href="settings.php" class="admin-nav-link">
                    <i class="bi bi-sliders"></i> Settings
                </a>
            </nav>

            <div class="admin-sidebar-footer">
                <a href="login.php" class="admin-nav-link logout">
                    <i class="bi bi-box-arrow-right"></i> Log Out
                </a>
            </div>
        </aside>

        <!-- Backdrop shown behind the sidebar when it's open on tablet/mobile -->
        <div class="admin-sidebar-backdrop"></div>

        <!-- ================= MAIN ================= -->
        <div class="admin-main">

            <!-- ---------- Topbar ---------- -->
            <header class="admin-topbar">
                <div class="admin-topbar-left">
                    <button type="button" class="admin-sidebar-toggle" aria-label="Toggle sidebar">
                        <i class="bi bi-list"></i>
                    </button>

                    <a href="dashboard.php" class="admin-topbar-logo">SLEEK<span>PICK</span></a>

                    <div class="admin-topbar-search">
                        <i class="bi bi-search"></i>
                        <input type="text" placeholder="Search orders, products, customers…">
                    </div>
                </div>

                <div class="admin-topbar-actions">
                    <a href="../public/index.php" class="admin-view-store-link" target="_blank" rel="noopener">
                        <i class="bi bi-box-arrow-up-right"></i> <span>View Store</span>
                    </a>
                    <button type="button" class="admin-notification-btn" aria-label="Notifications">
                        <i class="bi bi-bell"></i>
                        <span class="admin-notification-dot"></span>
                    </button>
                    <button type="button" class="admin-profile-btn">
                        <span class="admin-profile-avatar">A</span>
                        <span>
                            Amara Okoye
                            <span class="role-tag">Admin</span>
                        </span>
                    </button>
                </div>
            </header>

            <!-- ---------- Page content ---------- -->
            <div class="admin-content">

                <div class="admin-page-header">
                    <div>
                        <h1>Products</h1>
                        <p>Manage your SLEEKPICK product catalog.</p>
                    </div>
                    <a href="add-product.php" class="admin-btn admin-btn-primary">
                        <i class="bi bi-plus-lg"></i> Add New Product
                    </a>
                </div>

                <!-- Stats -->
                <div class="admin-stats-row">
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-neutral"><i class="bi bi-box-seam"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $totalProducts; ?></div>
                        <div class="admin-stat-label">Total Products</div>
                    </div>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-accent"><i class="bi bi-check-circle"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $activeCount; ?></div>
                        <div class="admin-stat-label">Active</div>
                    </div>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-secondary"><i class="bi bi-file-earmark"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $draftCount; ?></div>
                        <div class="admin-stat-label">Draft</div>
                    </div>
                    <div class="admin-stat-card">
                        <div class="admin-stat-card-top">
                            <span class="admin-stat-icon tone-primary"><i class="bi bi-exclamation-triangle"></i></span>
                        </div>
                        <div class="admin-stat-value"><?php echo $lowStockCount; ?></div>
                        <div class="admin-stat-label">Low Stock</div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="admin-filters-bar">
                    <div class="admin-filter-search admin-product-search">
                        <i class="bi bi-search"></i>
                         <input type="search" placeholder="Search by name or SKU" data-product-search>
                    </div>
                    <select class="admin-select admin-filter-category">
                        <option value="all">All Categories</option>
                        <?php foreach ($categories as $slug => $label): ?>
                            <option value="<?php echo htmlspecialchars($slug); ?>"><?php echo htmlspecialchars($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select class="admin-select admin-filter-product-status">
                        <option value="all">All Statuses</option>
                        <?php foreach ($statusOptions as $slug => $label): ?>
                            <option value="<?php echo htmlspecialchars($slug); ?>"><?php echo htmlspecialchars($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Products table -->
                <div class="admin-table-card">
                    <table class="admin-table admin-products-table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" class="admin-checkbox" aria-label="Select all products"></th>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                            <?php [$stockClass, $stockLabel] = stockState($product['stock']); ?>
                            <tr data-product-id="<?php echo (int) $product['id']; ?>" data-category="<?php echo htmlspecialchars($product['category']); ?>" data-status="<?php echo htmlspecialchars($product['status']); ?>">
                                <td><input type="checkbox" class="admin-checkbox" aria-label="Select <?php echo htmlspecialchars($product['name']); ?>"></td>
                                <td>
                                    <div class="product-cell">
                                        <div class="product-thumb">
                                            <img src="https://placehold.co/100x130/<?php echo htmlspecialchars($product['colorHex']); ?>/FFFFFF?text=<?php echo urlencode(substr($product['name'], 0, 1)); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                        </div>
                                        <div class="product-cell-info">
                                            <strong><?php echo htmlspecialchars($product['name']); ?></strong>
                                            <span><?php echo htmlspecialchars($product['sku']); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="cell-muted"><?php echo htmlspecialchars($categories[$product['category']] ?? $product['category']); ?></td>
                                <td class="cell-strong">$<?php echo number_format($product['price'], 2); ?></td>
                                <td>
                                    <span class="stock-indicator <?php echo $stockClass; ?>"><?php echo htmlspecialchars($stockLabel); ?></span>
                                </td>
                                <td>
                                    <span class="admin-status-badge admin-status-<?php echo htmlspecialchars($product['status']); ?>">
                                        <?php echo htmlspecialchars($product['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="admin-row-actions">
                                        <a href="edit-product.php?id=<?php echo (int) $product['id']; ?>" aria-label="Edit <?php echo htmlspecialchars($product['name']); ?>">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <button type="button" class="delete-btn" data-delete-product aria-label="Delete <?php echo htmlspecialchars($product['name']); ?>">
                                            <i class="bi bi-trash3"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="admin-table-footer">
                        <span class="results-note">Showing <?php echo $totalProducts; ?> of 86 products</span>
                        <nav class="admin-pagination" aria-label="Products pagination">
                            <a href="#" aria-label="Previous page"><i class="bi bi-chevron-left"></i></a>
                            <span class="current">1</span>
                            <a href="#">2</a>
                            <a href="#">3</a>
                            <a href="#">4</a>
                            <a href="#" aria-label="Next page"><i class="bi bi-chevron-right"></i></a>
                        </nav>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>