<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Categories — SLEEKPICK Admin';
$categories = [
    ['id' => 1, 'name' => 'Outerwear', 'slug' => 'outerwear', 'description' => 'Technical layers, jackets, and statement pieces.', 'products' => 18, 'status' => 'active', 'updated' => 'Aug 05, 2026'],
    ['id' => 2, 'name' => 'Essentials', 'slug' => 'essentials', 'description' => 'Everyday pieces with a future-facing cut.', 'products' => 24, 'status' => 'active', 'updated' => 'Aug 04, 2026'],
    ['id' => 3, 'name' => 'Bottoms', 'slug' => 'bottoms', 'description' => 'Utility trousers, cargos, and engineered denim.', 'products' => 16, 'status' => 'active', 'updated' => 'Jul 30, 2026'],
    ['id' => 4, 'name' => 'Accessories', 'slug' => 'accessories', 'description' => 'Finishing details for the complete SLEEKPICK signal.', 'products' => 21, 'status' => 'active', 'updated' => 'Jul 26, 2026'],
    ['id' => 5, 'name' => 'Archive', 'slug' => 'archive', 'description' => 'Past drops kept for reporting and reference.', 'products' => 7, 'status' => 'hidden', 'updated' => 'Jul 18, 2026'],
];

$activeCount = count(array_filter($categories, static fn(array $category): bool => $category['status'] === 'active'));
$productCount = array_sum(array_column($categories, 'products'));

adminRenderHead($pageTitle);
adminRenderShellStart('categories');
?>
<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Catalog structure</span>
        <h1>Categories</h1>
        <p>Organise the collection so shoppers can find their next signal faster.</p>
    </div>
    <button type="button" class="admin-btn admin-btn-primary" data-open-modal="category-modal">
        <i class="bi bi-plus-lg" aria-hidden="true"></i> Add Category
    </button>
</div>

<div class="admin-stats-row">
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-secondary"><i class="bi bi-tags"></i></span></div><div class="admin-stat-value"><?php echo $activeCount; ?></div><div class="admin-stat-label">Live categories</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-neutral"><i class="bi bi-box-seam"></i></span></div><div class="admin-stat-value"><?php echo $productCount; ?></div><div class="admin-stat-label">Products assigned</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-accent"><i class="bi bi-eye"></i></span></div><div class="admin-stat-value"><?php echo count($categories); ?></div><div class="admin-stat-label">Total categories</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-primary"><i class="bi bi-eye-slash"></i></span></div><div class="admin-stat-value"><?php echo count($categories) - $activeCount; ?></div><div class="admin-stat-label">Hidden</div></div>
</div>

<div class="admin-toolbar-card">
    <div class="admin-filter-search"><i class="bi bi-search" aria-hidden="true"></i><input type="search" placeholder="Search categories" aria-label="Search categories" data-category-search></div>
    <select class="admin-select" aria-label="Filter categories by status" data-category-status><option value="all">All visibility</option><option value="active">Live</option><option value="hidden">Hidden</option></select>
</div>

<div class="admin-category-grid" data-category-grid>
    <?php foreach ($categories as $category): ?>
        <article class="admin-category-card" data-category-row data-status="<?php echo adminEsc($category['status']); ?>">
            <div class="admin-category-card-top">
                <span class="admin-category-icon"><i class="bi bi-<?php echo $category['status'] === 'active' ? 'layers' : 'archive'; ?>"></i></span>
                <div class="admin-row-actions">
                    <button type="button" data-category-toggle aria-label="Toggle <?php echo adminEsc($category['name']); ?> visibility"><i class="bi bi-<?php echo $category['status'] === 'active' ? 'eye-slash' : 'eye'; ?>"></i></button>
                    <button type="button" data-category-delete aria-label="Delete <?php echo adminEsc($category['name']); ?>"><i class="bi bi-trash3"></i></button>
                </div>
            </div>
            <h2><?php echo adminEsc($category['name']); ?></h2>
            <p><?php echo adminEsc($category['description']); ?></p>
            <div class="admin-category-card-footer"><span><strong><?php echo (int) $category['products']; ?></strong> products</span><?php echo adminStatusBadge($category['status']); ?></div>
            <small>Updated <?php echo adminEsc($category['updated']); ?></small>
        </article>
    <?php endforeach; ?>
</div>

<div class="admin-empty-state" data-category-empty hidden><i class="bi bi-search"></i><h2>No categories found</h2><p>Try a different search or visibility filter.</p></div>

<div class="admin-modal-backdrop" data-modal="category-modal" hidden>
    <section class="admin-modal" role="dialog" aria-modal="true" aria-labelledby="category-modal-title">
        <button type="button" class="admin-modal-close" data-close-modal aria-label="Close dialog"><i class="bi bi-x-lg"></i></button>
        <span class="admin-eyebrow">Catalog structure</span><h2 id="category-modal-title">Add a category</h2><p class="admin-modal-copy">Create a collection grouping for your product catalog.</p>
        <form class="admin-form-grid" data-admin-form data-category-form>
            <div class="admin-form-group full-width"><label for="category-name">Category name</label><input class="admin-input" id="category-name" name="name" placeholder="e.g. Footwear" required><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="category-slug">URL slug</label><input class="admin-input" id="category-slug" name="slug" placeholder="footwear" required><p class="admin-field-error"></p></div>
            <div class="admin-form-group"><label for="category-status">Visibility</label><select class="admin-input" id="category-status" name="status"><option value="active">Live</option><option value="hidden">Hidden</option></select><p class="admin-field-error"></p></div>
            <div class="admin-form-group full-width"><label for="category-description">Description</label><textarea class="admin-input admin-textarea" id="category-description" name="description" rows="4" maxlength="140" placeholder="A short description for the category"></textarea><div class="admin-character-count"><span data-character-count>0</span>/140</div><p class="admin-field-error"></p></div>
            <div class="admin-form-actions full-width"><button type="button" class="admin-btn admin-btn-ghost" data-close-modal>Cancel</button><button type="submit" class="admin-btn admin-btn-primary"><i class="bi bi-plus-lg"></i> Create category</button></div>
        </form>
    </section>
</div>
<?php
adminRenderShellEnd();