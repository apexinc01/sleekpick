<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Add to Cart (action endpoint)
 *
 * POST JSON endpoint called via fetch() from product.php / shop.php
 * "Add to Cart" buttons. Adds an item to the session cart (see
 * includes/functions.php) and returns the updated cart count/subtotal
 * as JSON so the frontend can update the header cart badge without
 * a full page reload.
 *
 * Two issues flagged in the prototype are now closed:
 *  - CSRF: the request must carry the session token (verifyCsrf()).
 *  - PRICE TRUST: name, price and image are looked up server-side from
 *    the `products` table by productId. Anything the client sends for
 *    those fields is ignored, so a tampered request cannot set its own
 *    price. Stock and variant validity are checked here too.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

// ---------- Validate & sanitize input ----------
$errors = [];

$productId = filter_var($input['productId'] ?? null, FILTER_VALIDATE_INT);
if ($productId === false || $productId === null || $productId <= 0) {
    $errors[] = 'A valid productId is required.';
}

$size = trim(strip_tags((string) ($input['size'] ?? '')));
if ($size === '' || mb_strlen($size) > 30) {
    $errors[] = 'Please choose a size.';
}

$color = trim(strip_tags((string) ($input['color'] ?? '')));
if ($color === '' || mb_strlen($color) > 30) {
    $errors[] = 'Please choose a colour.';
}

$quantity = filter_var($input['quantity'] ?? 1, FILTER_VALIDATE_INT);
if ($quantity === false || $quantity === null || $quantity < 1) {
    $quantity = 1;
}
$quantity = min($quantity, 10); // hard ceiling regardless of what was requested

if ($errors !== []) {
    jsonResponse(['success' => false, 'message' => implode(' ', $errors)], 422);
}

// ---------- Authoritative product lookup ----------
$product = dbFetch(
    'SELECT id, name, price, image, stock, is_active FROM products WHERE id = ? LIMIT 1',
    [$productId]
);

if ($product === null || (int) $product['is_active'] !== 1) {
    jsonResponse(['success' => false, 'message' => 'That product is no longer available.'], 404);
}

// ---------- Variant + stock check ----------
$variant = dbFetch(
    'SELECT id, stock, price_override FROM product_variants
     WHERE product_id = ? AND size = ? AND color = ? LIMIT 1',
    [$productId, $size, $color]
);

$hasVariants = (int) dbFetchColumn('SELECT COUNT(*) FROM product_variants WHERE product_id = ?', [$productId]) > 0;

if ($hasVariants && $variant === null) {
    jsonResponse(['success' => false, 'message' => 'That size and colour combination is not available.'], 422);
}

$availableStock = $variant !== null ? (int) $variant['stock'] : (int) $product['stock'];
if ($availableStock < 1) {
    jsonResponse(['success' => false, 'message' => 'That option is out of stock.'], 409);
}

$alreadyInCart = getCart()[cartItemKey((int) $product['id'], $size, $color)]['quantity'] ?? 0;
if (($alreadyInCart + $quantity) > $availableStock) {
    $quantity = max(0, $availableStock - (int) $alreadyInCart);
    if ($quantity === 0) {
        jsonResponse([
            'success' => false,
            'message' => 'You already have all remaining stock of that option in your cart.',
        ], 409);
    }
}

// Price always comes from the database, never from the request body.
$price = (float) ($variant['price_override'] ?? $product['price']);

$cart = addCartItem(
    (int) $product['id'],
    (string) $product['name'],
    $price,
    $size,
    $color,
    $quantity,
    (string) ($product['image'] ?? '')
);

jsonResponse([
    'success'      => true,
    'message'      => e((string) $product['name']) . ' added to cart.',
    'cartCount'    => getCartCount($cart),
    'cartSubtotal' => round(getCartSubtotal($cart), 2),
]);
