<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Checkout
 *
 * Session cart → actions/place-order.php.
 * No card gateway yet: payment options are cash on delivery / bank transfer.
 */

$pageTitle       = 'Checkout — SLEEKPICK';
$pageDescription = 'Complete your SLEEKPICK order.';
$activeNav       = '';
$showPreloader   = true;

require_once __DIR__ . '/../includes/header.php';

$cart = getCart();
if ($cart === []) {
    setFlash('error', 'Your cart is empty. Add something before checking out.');
    header('Location: cart.php');
    exit;
}

$subtotal = getCartSubtotal($cart);
$freeShippingThreshold = (float) (settingValue('free_shipping_minimum', '80') ?? 80);
$shippingFlatRate      = (float) (settingValue('shipping_flat_rate', '9.99') ?? 9.99);
$taxRatePercent        = (float) (settingValue('tax_rate_percent', '0') ?? 0);
$currencySymbol        = (string) (settingValue('currency_symbol', '$') ?? '$');

$shipping = ($subtotal >= $freeShippingThreshold) ? 0.0 : $shippingFlatRate;
$tax      = round($subtotal * ($taxRatePercent / 100), 2);
$total    = round($subtotal + $shipping + $tax, 2);

$lines = [];
foreach ($cart as $key => $item) {
    $productId = (int) ($item['productId'] ?? 0);
    $imagePath = (string) ($item['image'] ?? '');
    $name = (string) ($item['name'] ?? 'Product');

    if ($productId > 0) {
        $row = dbFetch(
            'SELECT name, image FROM products WHERE id = ? AND is_active = 1 LIMIT 1',
            [$productId]
        );
        if ($row !== null) {
            $name = (string) $row['name'];
            if (!empty($row['image'])) {
                $imagePath = (string) $row['image'];
            }
        }
    }

    $qty = max(1, (int) ($item['quantity'] ?? 1));
    $price = (float) ($item['price'] ?? 0);

    $lines[] = [
        'key'      => $key,
        'name'     => $name,
        'size'     => (string) ($item['size'] ?? ''),
        'color'    => (string) ($item['color'] ?? ''),
        'quantity' => $qty,
        'price'    => $price,
        'lineTotal'=> $price * $qty,
        'image'    => productImageUrl($imagePath !== '' ? $imagePath : null, $name),
    ];
}

$user = currentUser();
$prefillEmail = $user['email'] ?? '';
$prefillName  = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
$prefillPhone = $user['phone'] ?? '';

$savedAddresses = [];
if (isLoggedIn() && currentUserId()) {
    $savedAddresses = dbFetchAll(
        'SELECT id, label, full_name, line1, line2, city, state, postal_code, country, phone, is_default
           FROM addresses
          WHERE user_id = ?
          ORDER BY is_default DESC, id DESC',
        [currentUserId()]
    );
}

$flashes = takeFlashes();
?>

<main>
    <section class="page-header">
        <div class="container">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="index.php">Home</a>
                <i class="bi bi-chevron-right"></i>
                <a href="cart.php">Cart</a>
                <i class="bi bi-chevron-right"></i>
                <span class="current">Checkout</span>
            </nav>
            <h1>Checkout</h1>
            <p class="page-header-note">
                <i class="bi bi-shield-lock"></i> Secure checkout — no card details are collected yet.
            </p>
        </div>
    </section>

    <section class="checkout-section">
        <div class="container">

            <?php foreach ($flashes as $flash): ?>
                <div class="form-message <?php echo $flash['type'] === 'error' ? 'error' : 'success'; ?>" role="status">
                    <?php echo e((string) $flash['message']); ?>
                </div>
            <?php endforeach; ?>

            <form class="checkout-form"
                  method="post"
                  action="../actions/place-order.php"
                  id="checkout-form"
                  novalidate>
                <?php echo csrfField(); ?>

                <div class="checkout-layout">

                    <div>
                        <div class="checkout-block">
                            <div class="checkout-step-title">
                                <span class="step-number">1</span> Contact Information
                            </div>
                            <div class="form-group">
                                <label for="checkout-email">Email Address</label>
                                <input type="email" id="checkout-email" name="email"
                                       value="<?php echo e((string) $prefillEmail); ?>"
                                       required autocomplete="email">
                            </div>
                            <div class="form-group">
                                <label for="checkout-phone">Phone Number</label>
                                <input type="tel" id="checkout-phone" name="phone"
                                       value="<?php echo e((string) $prefillPhone); ?>"
                                       required autocomplete="tel">
                            </div>
                        </div>

                        <div class="checkout-block">
                            <div class="checkout-step-title">
                                <span class="step-number">2</span> Shipping Address
                            </div>

                            <?php if ($savedAddresses !== []): ?>
                                <div class="saved-address-grid">
                                    <?php foreach ($savedAddresses as $i => $addr): ?>
                                        <label class="saved-address-option">
                                            <input type="radio"
                                                   name="saved_address_id"
                                                   value="<?php echo (int) $addr['id']; ?>"
                                                   data-full-name="<?php echo e((string) $addr['full_name']); ?>"
                                                   data-line1="<?php echo e((string) $addr['line1']); ?>"
                                                   data-line2="<?php echo e((string) ($addr['line2'] ?? '')); ?>"
                                                   data-city="<?php echo e((string) $addr['city']); ?>"
                                                   data-state="<?php echo e((string) ($addr['state'] ?? '')); ?>"
                                                   data-postal="<?php echo e((string) ($addr['postal_code'] ?? '')); ?>"
                                                   data-country="<?php echo e((string) $addr['country']); ?>"
                                                   data-phone="<?php echo e((string) ($addr['phone'] ?? '')); ?>"
                                                <?php echo ((int) ($addr['is_default'] ?? 0) === 1 || $i === 0) ? ' checked' : ''; ?>>
                                            <h4><?php echo e((string) ($addr['label'] ?: 'Address')); ?></h4>
                                            <p>
                                                <?php echo e((string) $addr['full_name']); ?><br>
                                                <?php echo e((string) $addr['line1']); ?><br>
                                                <?php echo e((string) $addr['city']); ?><?php echo !empty($addr['state']) ? ', ' . e((string) $addr['state']) : ''; ?>
                                            </p>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" class="new-address-toggle">
                                    <i class="bi bi-plus-circle"></i> Use a different address
                                </button>
                            <?php endif; ?>

                            <div class="new-address-form<?php echo $savedAddresses === [] ? ' open' : ''; ?>">
                                <div class="form-group">
                                    <label for="ship-full-name">Full Name</label>
                                    <input type="text" id="ship-full-name" name="full_name"
                                           value="<?php echo e((string) $prefillName); ?>"
                                           <?php echo $savedAddresses === [] ? 'required' : ''; ?>
                                           autocomplete="name">
                                </div>
                                <div class="form-group">
                                    <label for="ship-address1">Street Address</label>
                                    <input type="text" id="ship-address1" name="line1"
                                           <?php echo $savedAddresses === [] ? 'required' : ''; ?>
                                           autocomplete="address-line1">
                                </div>
                                <div class="form-group">
                                    <label for="ship-address2">Apartment, suite, etc. <span class="optional">(optional)</span></label>
                                    <input type="text" id="ship-address2" name="line2" autocomplete="address-line2">
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="ship-city">City</label>
                                        <input type="text" id="ship-city" name="city"
                                               <?php echo $savedAddresses === [] ? 'required' : ''; ?>
                                               autocomplete="address-level2">
                                    </div>
                                    <div class="form-group">
                                        <label for="ship-state">State</label>
                                        <input type="text" id="ship-state" name="state" autocomplete="address-level1">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="ship-postal">Postal Code</label>
                                        <input type="text" id="ship-postal" name="postal_code" autocomplete="postal-code">
                                    </div>
                                    <div class="form-group">
                                        <label for="ship-country">Country</label>
                                        <input type="text" id="ship-country" name="country" value="Nigeria" required autocomplete="country-name">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="checkout-block">
                            <div class="checkout-step-title">
                                <span class="step-number">3</span> Shipping Method
                            </div>
                            <label class="shipping-method-option">
                                <span class="shipping-method-left">
                                    <input type="radio" name="shipping_method" value="standard" checked>
                                    <span>
                                        <strong>Standard Shipping</strong>
                                        <span>3–5 business days</span>
                                    </span>
                                </span>
                                <span class="shipping-method-price">
                                    <?php echo $shipping === 0.0 ? 'Free' : '$' . number_format($shipping, 2); ?>
                                </span>
                            </label>
                            <?php if ($shipping > 0): ?>
                                <p class="checkout-shipping-note">
                                    Free shipping on orders of $<?php echo number_format($freeShippingThreshold, 0); ?>+
                                </p>
                            <?php endif; ?>
                        </div>

                        <div class="checkout-block">
                            <div class="checkout-step-title">
                                <span class="step-number">4</span> Payment
                            </div>

                            <div class="payment-note">
                                <i class="bi bi-info-circle"></i>
                                <span>Card payments are not connected yet. Choose cash on delivery or bank transfer to place the order.</span>
                            </div>

                            <label class="shipping-method-option">
                                <span class="shipping-method-left">
                                    <input type="radio" name="payment_method" value="cash_on_delivery" checked>
                                    <span>
                                        <strong>Cash on Delivery</strong>
                                        <span>Pay when your order arrives</span>
                                    </span>
                                </span>
                                <span class="shipping-method-price"><i class="bi bi-cash-coin"></i></span>
                            </label>

                            <label class="shipping-method-option">
                                <span class="shipping-method-left">
                                    <input type="radio" name="payment_method" value="bank_transfer">
                                    <span>
                                        <strong>Bank Transfer</strong>
                                        <span>Instructions sent after order confirmation</span>
                                    </span>
                                </span>
                                <span class="shipping-method-price"><i class="bi bi-bank"></i></span>
                            </label>

                            <div class="form-group" style="margin-top:1rem;">
                                <label for="order-notes">Order notes <span class="optional">(optional)</span></label>
                                <textarea id="order-notes" name="notes" rows="3" maxlength="500" placeholder="Delivery notes, landmarks, etc."></textarea>
                            </div>
                        </div>
                    </div>

                    <aside class="cart-summary">
                        <h2>Order Summary</h2>

                        <div class="checkout-summary-items">
                            <?php foreach ($lines as $item): ?>
                                <div class="checkout-summary-item">
                                    <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>">
                                    <div class="checkout-summary-item-info">
                                        <strong><?php echo e($item['name']); ?></strong>
                                        <span>
                                            <?php echo e($item['size']); ?>
                                            &middot;
                                            <?php echo e($item['color']); ?>
                                            &middot; Qty <?php echo (int) $item['quantity']; ?>
                                        </span>
                                    </div>
                                    <span class="checkout-summary-item-price">
                                        $<?php echo number_format($item['lineTotal'], 2); ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="summary-row">
                            <span>Subtotal</span>
                            <span class="value checkout-summary-subtotal" data-subtotal="<?php echo e((string) $subtotal); ?>">
                                $<?php echo number_format($subtotal, 2); ?>
                            </span>
                        </div>
                        <div class="summary-row">
                            <span>Shipping</span>
                            <span class="value checkout-summary-shipping">
                                <?php echo $shipping === 0.0 ? 'Free' : '$' . number_format($shipping, 2); ?>
                            </span>
                        </div>
                        <?php if ($tax > 0): ?>
                            <div class="summary-row">
                                <span>Tax</span>
                                <span class="value">$<?php echo number_format($tax, 2); ?></span>
                            </div>
                        <?php endif; ?>

                        <div class="summary-divider"></div>

                        <div class="summary-row total">
                            <span>Total</span>
                            <span class="value checkout-summary-total">$<?php echo number_format($total, 2); ?></span>
                        </div>

                        <button type="submit" class="btn btn-primary place-order-btn">
                            <i class="bi bi-lock-fill"></i> Place Order
                        </button>

                        <p class="secure-note">
                            <i class="bi bi-shield-check"></i> Your information is secure
                        </p>
                        <p class="secure-note">
                            <a href="cart.php"><i class="bi bi-arrow-left"></i> Back to cart</a>
                        </p>
                    </aside>

                </div>
            </form>
        </div>
    </section>
</main>

<?php
$extraScripts = ['../assets/js/cart.js'];
require_once __DIR__ . '/../includes/footer.php';