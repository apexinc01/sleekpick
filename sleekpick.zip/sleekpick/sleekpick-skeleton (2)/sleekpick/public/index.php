<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Homepage
 *
 * Live storefront home: categories, featured products and new arrivals
 * are loaded from MySQL. Store name / free-shipping threshold come from
 * the settings table. Newsletter posts to actions/subscribe-newsletter.php.
 */

$pageTitle       = 'SLEEKPICK — Wear the Future';
$pageDescription = 'Futuristic fashion for people who dress like it\'s already tomorrow. Shop outerwear, essentials, bottoms and accessories.';
$activeNav       = 'home';

require_once __DIR__ . '/../includes/header.php';

$storeName = (string) (settingValue('store_name', 'SLEEKPICK') ?? 'SLEEKPICK');
$storeBlurb = (string) (settingValue(
    'store_description',
    'Futuristic fashion for people who dress like it\'s already tomorrow.'
) ?? '');
$freeShippingMin = (float) (settingValue('free_shipping_minimum', '80') ?? 80);
$currencySymbol  = (string) (settingValue('currency_symbol', '$') ?? '$');

$categories = dbFetchAll(
    "SELECT c.id, c.name, c.slug, c.description, c.image,
            COUNT(p.id) AS product_count
       FROM categories c
       LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1
      WHERE c.is_active = 1
      GROUP BY c.id
      ORDER BY c.sort_order ASC, c.name ASC"
);

$featuredProducts = dbFetchAll(
    "SELECT p.id, p.name, p.slug, p.sku, p.price, p.compare_price, p.image, p.badge,
            p.short_description, p.created_at, c.name AS category_name, c.slug AS category_slug
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.is_active = 1 AND p.is_featured = 1
      ORDER BY p.created_at DESC
      LIMIT 8"
);

// If nothing is marked featured yet, fall back to newest active products
if ($featuredProducts === []) {
    $featuredProducts = dbFetchAll(
        "SELECT p.id, p.name, p.slug, p.sku, p.price, p.compare_price, p.image, p.badge,
                p.short_description, p.created_at, c.name AS category_name, c.slug AS category_slug
           FROM products p
           LEFT JOIN categories c ON c.id = p.category_id
          WHERE p.is_active = 1
          ORDER BY p.created_at DESC
          LIMIT 8"
    );
}

$newArrivals = dbFetchAll(
    "SELECT p.id, p.name, p.slug, p.sku, p.price, p.compare_price, p.image, p.badge,
            p.short_description, p.created_at, c.name AS category_name, c.slug AS category_slug
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.is_active = 1
      ORDER BY p.created_at DESC
      LIMIT 4"
);

$saleProducts = dbFetchAll(
    "SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.image, p.badge,
            c.name AS category_name
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.is_active = 1
        AND p.compare_price IS NOT NULL
        AND p.compare_price > p.price
      ORDER BY (p.compare_price - p.price) DESC
      LIMIT 4"
);

$totalProducts = (int) dbFetchColumn('SELECT COUNT(*) FROM products WHERE is_active = 1');
$totalCategories = (int) dbFetchColumn('SELECT COUNT(*) FROM categories WHERE is_active = 1');

/**
 * Render a product card matching the shop grid markup.
 */
function homeProductCard(array $product): void
{
    $image = productImageUrl($product['image'] ?? null, (string) $product['name']);
    $price = (float) $product['price'];
    $compare = $product['compare_price'] !== null ? (float) $product['compare_price'] : null;
    $badge = trim((string) ($product['badge'] ?? ''));
    ?>
    <article class="product-card" data-product-id="<?php echo e((string) $product['id']); ?>">
        <a href="product.php?slug=<?php echo e((string) $product['slug']); ?>" class="product-media-link">
            <div class="product-media corner-brackets">
                <span></span><span></span><span></span><span></span>
                <?php if ($badge !== ''): ?>
                    <span class="product-badge"><?php echo e($badge); ?></span>
                <?php elseif ($compare !== null && $compare > $price): ?>
                    <span class="product-badge">Sale</span>
                <?php endif; ?>
                <button type="button" class="wishlist-btn"
                        aria-label="Add <?php echo e($product['name']); ?> to wishlist"
                        aria-pressed="false">
                    <i class="bi bi-heart"></i>
                </button>
                <img src="<?php echo e($image); ?>"
                     alt="<?php echo e($product['name']); ?>"
                     loading="lazy">
            </div>
        </a>
        <div class="product-info">
            <span class="product-category"><?php echo e((string) ($product['category_name'] ?? 'Collection')); ?></span>
            <h3 class="product-name">
                <a href="product.php?slug=<?php echo e((string) $product['slug']); ?>">
                    <?php echo e($product['name']); ?>
                </a>
            </h3>
            <div class="product-price">
                <span class="price-current">$<?php echo number_format($price, 2); ?></span>
                <?php if ($compare !== null && $compare > $price): ?>
                    <span class="price-original">$<?php echo number_format($compare, 2); ?></span>
                <?php endif; ?>
            </div>
            <a href="product.php?slug=<?php echo e((string) $product['slug']); ?>" class="add-to-cart-btn">
                <i class="bi bi-bag-plus"></i> View Product
            </a>
        </div>
    </article>
    <?php
}
?>

<main class="home-page">

    <!-- ================= HERO ================= -->
    <section class="hero">
        <div class="container hero-inner">
            <div class="hero-copy">
                <span class="section-eyebrow">SS26 Collection</span>
                <h1>Dress for the world <em>arriving next</em>.</h1>
                <p><?php echo e($storeBlurb !== '' ? $storeBlurb : 'Engineered silhouettes, tech-forward fabrics, and a color language built for people who move first.'); ?></p>
                <div class="hero-actions">
                    <a href="shop.php" class="btn btn-primary">
                        Shop the Collection <i class="bi bi-arrow-right"></i>
                    </a>
                    <a href="shop.php?category=new" class="btn btn-secondary">New Arrivals</a>
                </div>
                <div class="hero-stats">
                    <div>
                        <strong><?php echo number_format($totalProducts); ?>+</strong>
                        <span>Live styles</span>
                    </div>
                    <div>
                        <strong><?php echo number_format($totalCategories); ?></strong>
                        <span>Categories</span>
                    </div>
                    <div>
                        <strong><?php echo e($currencySymbol . number_format($freeShippingMin, 0)); ?>+</strong>
                        <span>Free shipping</span>
                    </div>
                </div>
            </div>

            <div class="hero-visual">
                <div class="hero-frame corner-brackets">
                    <span></span><span></span><span></span><span></span>
                    <img src="https://picsum.photos/seed/sleekpick-hero/900/1100"
                         alt="Model wearing a <?php echo e($storeName); ?> jacket from the SS26 collection"
                         loading="eager">
                </div>
                <div class="hero-badge">
                    <i class="bi bi-lightning-charge-fill"></i>
                    <div>
                        <strong>Free Shipping</strong>
                        <small>On orders over <?php echo e($currencySymbol . number_format($freeShippingMin, 0)); ?></small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= MARQUEE ================= -->
    <div class="home-marquee" aria-hidden="true">
        <div class="home-marquee-track">
            <?php for ($i = 0; $i < 2; $i++): ?>
                <span>Technical outerwear</span>
                <span>·</span>
                <span>Street-ready essentials</span>
                <span>·</span>
                <span>Engineered bottoms</span>
                <span>·</span>
                <span>Signal accessories</span>
                <span>·</span>
                <span>SS26 drop live</span>
                <span>·</span>
            <?php endfor; ?>
        </div>
    </div>

    <!-- ================= CATEGORIES ================= -->
    <section class="categories">
        <div class="container">
            <div class="section-heading">
                <span class="section-eyebrow">Shop by Category</span>
                <h2>Find your lane</h2>
                <p>Every collection is built from the same signal — sharp cuts, technical fabric, zero noise.</p>
            </div>

            <?php if ($categories === []): ?>
                <div class="home-empty">
                    <p>Categories will appear here once the catalog is live.</p>
                    <a href="shop.php" class="btn btn-secondary">Browse Shop</a>
                </div>
            <?php else: ?>
                <div class="category-grid">
                    <?php foreach ($categories as $index => $category):
                        $count = (int) $category['product_count'];
                        $seed = 'sleekpick-' . ($category['slug'] ?: ('cat' . $index));
                        $img = !empty($category['image'])
                            ? productImageUrl((string) $category['image'], (string) $category['name'])
                            : 'https://picsum.photos/seed/' . rawurlencode($seed) . '/500/650';
                        ?>
                        <a href="shop.php?category=<?php echo e((string) $category['slug']); ?>" class="category-card">
                            <img src="<?php echo e($img); ?>" alt="<?php echo e($category['name']); ?> category" loading="lazy">
                            <div class="category-label">
                                <span><?php echo $count; ?> Style<?php echo $count === 1 ? '' : 's'; ?></span>
                                <h3><?php echo e($category['name']); ?></h3>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ================= FEATURED PRODUCTS ================= -->
    <section class="products home-featured">
        <div class="container">
            <div class="section-heading">
                <span class="section-eyebrow">Trending Now</span>
                <h2>Featured from the catalog</h2>
                <p>Live products pulled straight from the SLEEKPICK database.</p>
            </div>

            <?php if ($featuredProducts === []): ?>
                <div class="home-empty">
                    <p>No products published yet. Add products in the admin catalog.</p>
                </div>
            <?php else: ?>
                <div class="product-grid">
                    <?php foreach ($featuredProducts as $product): ?>
                        <?php homeProductCard($product); ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="section-footer">
                <a href="shop.php" class="btn btn-secondary">View All Products <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
    </section>

    <!-- ================= STORY / LOOKBOOK ================= -->
    <section class="home-story">
        <div class="container home-story-inner">
            <div class="home-story-visual corner-brackets">
                <span></span><span></span><span></span><span></span>
                <img src="https://picsum.photos/seed/sleekpick-story/900/1000"
                     alt="<?php echo e($storeName); ?> lookbook" loading="lazy">
            </div>
            <div class="home-story-copy">
                <span class="section-eyebrow">The Signal</span>
                <h2>Built for motion. Styled for impact.</h2>
                <p><?php echo e($storeName); ?> designs for people who treat clothing like equipment — precise, durable, and ready for the next frame.</p>
                <ul class="home-story-list">
                    <li><i class="bi bi-check2-circle"></i> Technical fabrics with everyday comfort</li>
                    <li><i class="bi bi-check2-circle"></i> Silhouettes engineered for movement</li>
                    <li><i class="bi bi-check2-circle"></i> Limited drops, no filler seasons</li>
                </ul>
                <a href="shop.php?category=new" class="btn btn-primary">Explore New Arrivals</a>
            </div>
        </div>
    </section>

    <!-- ================= NEW ARRIVALS ================= -->
    <section class="products home-new">
        <div class="container">
            <div class="section-heading">
                <span class="section-eyebrow">Just Landed</span>
                <h2>New arrivals</h2>
                <p>Fresh from the catalog — newest first.</p>
            </div>

            <?php if ($newArrivals === []): ?>
                <div class="home-empty"><p>New arrivals will show here as products are published.</p></div>
            <?php else: ?>
                <div class="product-grid product-grid-four">
                    <?php foreach ($newArrivals as $product): ?>
                        <?php homeProductCard($product); ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="section-footer">
                <a href="shop.php?sort=newest" class="btn btn-secondary">Shop Newest <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
    </section>

    <!-- ================= PROMO + SALE STRIP ================= -->
    <section class="container home-promo-split">
        <div class="promo-banner home-promo-main">
            <img src="https://picsum.photos/seed/sleekpick-promo/1400/700" alt="<?php echo e($storeName); ?> seasonal promotion" loading="lazy">
            <div class="promo-content">
                <span class="section-eyebrow">Limited Drop</span>
                <h2>Outerwear that does not restock</h2>
                <p>Once a shell is gone, it is archived. Move while the signal is live.</p>
                <a href="shop.php?category=outerwear" class="btn btn-primary">Shop Outerwear</a>
            </div>
        </div>

        <?php if ($saleProducts !== []): ?>
            <div class="home-sale-panel">
                <div class="section-heading section-heading-left">
                    <span class="section-eyebrow">On Sale</span>
                    <h2>Marked down, still sharp</h2>
                </div>
                <div class="home-sale-list">
                    <?php foreach ($saleProducts as $product):
                        $img = productImageUrl($product['image'] ?? null, (string) $product['name']);
                        $price = (float) $product['price'];
                        $compare = (float) $product['compare_price'];
                        $off = $compare > 0 ? (int) round((($compare - $price) / $compare) * 100) : 0;
                        ?>
                        <a href="product.php?slug=<?php echo e((string) $product['slug']); ?>" class="home-sale-item">
                            <img src="<?php echo e($img); ?>" alt="" loading="lazy">
                            <div>
                                <strong><?php echo e($product['name']); ?></strong>
                                <span><?php echo e((string) ($product['category_name'] ?? '')); ?></span>
                                <div class="product-price">
                                    <span class="price-current">$<?php echo number_format($price, 2); ?></span>
                                    <span class="price-original">$<?php echo number_format($compare, 2); ?></span>
                                </div>
                            </div>
                            <?php if ($off > 0): ?>
                                <em>-<?php echo $off; ?>%</em>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </section>

    <!-- ================= VALUE STRIP ================= -->
    <section class="value-strip">
        <div class="container value-grid">
            <div class="value-item">
                <i class="bi bi-truck"></i>
                <div>
                    <strong>Free Shipping</strong>
                    <span>On orders over <?php echo e($currencySymbol . number_format($freeShippingMin, 0)); ?></span>
                </div>
            </div>
            <div class="value-item">
                <i class="bi bi-arrow-repeat"></i>
                <div>
                    <strong>Easy Returns</strong>
                    <span>30-day return window</span>
                </div>
            </div>
            <div class="value-item">
                <i class="bi bi-shield-check"></i>
                <div>
                    <strong>Secure Checkout</strong>
                    <span>Encrypted payment flow</span>
                </div>
            </div>
            <div class="value-item">
                <i class="bi bi-headset"></i>
                <div>
                    <strong>Support</strong>
                    <span>Real answers, fast</span>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= NEWSLETTER ================= -->
    <section class="newsletter">
        <div class="container newsletter-inner">
            <span class="section-eyebrow">Stay in the Loop</span>
            <h2>Get first access to new drops</h2>
            <form id="newsletter-form"
                  class="newsletter-form"
                  method="post"
                  action="../actions/subscribe-newsletter.php"
                  novalidate>
                <?php echo csrfField(); ?>
                <label for="newsletter-email" class="visually-hidden">Email address</label>
                <input type="email" id="newsletter-email" name="email" placeholder="you@email.com" required autocomplete="email">
                <button type="submit" class="btn btn-primary">Subscribe</button>
            </form>
            <p class="form-message" role="status" aria-live="polite"></p>
            <p class="newsletter-note">No spam. Unsubscribe anytime.</p>
        </div>
    </section>

</main>

<?php
$extraScripts = [];
require_once __DIR__ . '/../includes/footer.php';