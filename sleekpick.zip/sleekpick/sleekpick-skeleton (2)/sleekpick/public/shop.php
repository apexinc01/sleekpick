<?php
declare(strict_types=1);

$pageTitle = 'Shop — SLEEKPICK';
$pageDescription = 'Shop the live SLEEKPICK collection from outerwear, essentials, bottoms, and accessories.';
$activeNav = 'shop';

require_once __DIR__ . '/../includes/header.php';

$categorySlug = strtolower(trim((string) ($_GET['category'] ?? '')));
$search = trim((string) ($_GET['q'] ?? ''));
$sort = (string) ($_GET['sort'] ?? 'featured');
$minPrice = is_numeric($_GET['min'] ?? null) ? max(0, (float) $_GET['min']) : null;
$maxPrice = is_numeric($_GET['max'] ?? null) ? max(0, (float) $_GET['max']) : null;

$where = ['p.is_active = 1'];
$params = [];
if ($categorySlug === 'new') {
    $where[] = 'p.is_featured = 1';
} elseif ($categorySlug !== '') {
    $where[] = 'c.slug = ?';
    $params[] = $categorySlug;
}
if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.sku LIKE ? OR p.short_description LIKE ?)';
    array_push($params, "%{$search}%", "%{$search}%", "%{$search}%");
}
if ($minPrice !== null) {
    $where[] = 'p.price >= ?';
    $params[] = $minPrice;
}
if ($maxPrice !== null) {
    $where[] = 'p.price <= ?';
    $params[] = $maxPrice;
}
$orderBy = match ($sort) {
    'price-low' => 'p.price ASC',
    'price-high' => 'p.price DESC',
    'newest' => 'p.created_at DESC',
    default => 'p.is_featured DESC, p.created_at DESC',
};

$products = dbFetchAll(
    "SELECT p.id, p.sku, p.name, p.slug, p.short_description, p.price, p.compare_price,
            p.stock, p.image, p.badge, p.created_at, c.name AS category, c.slug AS category_slug
     FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     WHERE " . implode(' AND ', $where) . "
     ORDER BY {$orderBy}",
    $params
);
$categories = dbFetchAll(
    "SELECT c.name, c.slug, COUNT(p.id) AS product_count
     FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1
     WHERE c.is_active = 1 GROUP BY c.id ORDER BY c.sort_order, c.name"
);

function shopProductCard(array $product): void
{
    $variants = productVariants((int) $product['id']);
    $sizes = array_values(array_unique(array_column($variants, 'size')));
    $colors = array_values(array_unique(array_column($variants, 'color')));
    $image = productImageUrl($product['image'] ?? null, (string) $product['name']);
    ?>
    <article class="product-card"
             data-product-id="<?php echo e($product['id']); ?>"
             data-order="<?php echo e($product['id']); ?>"
             data-newest="<?php echo e(strtotime((string) $product['created_at'])); ?>"
             data-category="<?php echo e((string) ($product['category_slug'] ?? '')); ?>"
             data-price="<?php echo e($product['price']); ?>"
             data-sizes="<?php echo e(implode(',', $sizes)); ?>"
             data-colors="<?php echo e(implode(',', $colors)); ?>">
        <a href="product.php?slug=<?php echo e($product['slug']); ?>" class="product-media-link">
            <div class="product-media corner-brackets">
                <span></span><span></span><span></span><span></span>
                <?php if (!empty($product['badge'])): ?><span class="product-badge"><?php echo e($product['badge']); ?></span><?php endif; ?>
                <button type="button" class="wishlist-btn" aria-label="Add <?php echo e($product['name']); ?> to wishlist" aria-pressed="false"><i class="bi bi-heart"></i></button>
                <img src="<?php echo e($image); ?>" alt="<?php echo e($product['name']); ?> product photo" loading="lazy">
            </div>
        </a>
        <div class="product-info">
            <span class="product-category"><?php echo e($product['category'] ?? 'Collection'); ?></span>
            <h3 class="product-name"><a href="product.php?slug=<?php echo e($product['slug']); ?>"><?php echo e($product['name']); ?></a></h3>
            <div class="product-price"><span class="price-current">$<?php echo number_format((float) $product['price'], 2); ?></span><?php if ($product['compare_price'] !== null): ?><span class="price-original">$<?php echo number_format((float) $product['compare_price'], 2); ?></span><?php endif; ?></div>
            <button type="button" class="add-to-cart-btn" data-product-id="<?php echo e($product['id']); ?>" data-size="<?php echo e($sizes[0] ?? 'One Size'); ?>" data-color="<?php echo e($colors[0] ?? 'Default'); ?>"<?php echo (int) $product['stock'] < 1 ? ' disabled' : ''; ?>><i class="bi bi-bag-plus"></i> <?php echo (int) $product['stock'] < 1 ? 'Out of Stock' : 'Add to Cart'; ?></button>
        </div>
    </article>
    <?php
}
?>
<main>
    <section class="page-header"><div class="container"><nav class="breadcrumb" aria-label="Breadcrumb"><a href="index.php">Home</a><i class="bi bi-chevron-right"></i><span class="current">Shop</span></nav><h1><?php echo $categorySlug !== '' ? e(ucwords(str_replace('-', ' ', $categorySlug))) : 'All Products'; ?></h1><p>Live products from the SLEEKPICK catalogue — <?php echo count($products); ?> available now.</p></div></section>
    <section class="shop-section"><div class="container shop-layout">
        <aside class="filters-sidebar" id="filters-sidebar" aria-label="Product filters">
            <button type="button" class="filter-drawer-close" aria-label="Close filters"><i class="bi bi-x-lg"></i></button>
            <div class="filters-header"><h2>Filters</h2><a href="shop.php" class="clear-filters">Clear All</a></div>
            <div class="filter-group"><h3>Category</h3><?php foreach ($categories as $category): ?><label class="filter-option"><input type="checkbox" data-label="<?php echo e($category['name']); ?>" value="<?php echo e($category['slug']); ?>"<?php echo $categorySlug === $category['slug'] ? ' checked' : ''; ?>> <?php echo e($category['name']); ?> <span class="count">(<?php echo (int) $category['product_count']; ?>)</span></label><?php endforeach; ?></div>
            <div class="filter-group"><h3>Size</h3><div class="size-options"><?php foreach (['XS','S','M','L','XL','One Size'] as $size): ?><button type="button" class="size-btn"><?php echo e($size); ?></button><?php endforeach; ?></div></div>
            <div class="filter-group"><h3>Color</h3><div class="color-options"><?php foreach (['Black' => '#1B1F1F','White' => '#FFFFFF','Red' => '#C81A1A','Teal' => '#54BAC1','Gray' => '#8A9797'] as $label => $hex): ?><button type="button" class="color-swatch" style="background:<?php echo $hex; ?>" data-label="<?php echo e($label); ?>" aria-label="<?php echo e($label); ?>"><i class="bi bi-check-lg"></i></button><?php endforeach; ?></div></div>
            <div class="filter-group"><h3>Price</h3><div class="price-inputs"><input type="number" min="0" placeholder="Min" aria-label="Minimum price" id="price-min" value="<?php echo $minPrice !== null ? e($minPrice) : ''; ?>"><span>&ndash;</span><input type="number" min="0" placeholder="Max" aria-label="Maximum price" id="price-max" value="<?php echo $maxPrice !== null ? e($maxPrice) : ''; ?>"></div><button type="button" class="apply-price-btn">Apply</button></div>
        </aside>
        <div class="filter-drawer-backdrop"></div>
        <div class="shop-main">
            <div class="shop-toolbar"><span class="results-count" id="shop-results-count"><?php echo count($products); ?> results</span><div class="toolbar-right"><button type="button" class="mobile-filter-btn"><i class="bi bi-sliders"></i> Filters <span class="filter-badge" style="display:none;">0</span></button><div class="sort-select-wrap"><select class="sort-select" id="shop-sort-select" aria-label="Sort products"><option value="featured"<?php echo $sort === 'featured' ? ' selected' : ''; ?>>Featured</option><option value="price-low"<?php echo $sort === 'price-low' ? ' selected' : ''; ?>>Price: Low to High</option><option value="price-high"<?php echo $sort === 'price-high' ? ' selected' : ''; ?>>Price: High to Low</option><option value="newest"<?php echo $sort === 'newest' ? ' selected' : ''; ?>>Newest</option></select><i class="bi bi-chevron-down"></i></div></div></div>
            <div class="active-filters"></div>
            <p class="shop-no-results" style="display:none;">No products match your filters. <a href="shop.php" class="clear-filters-inline">Clear all filters</a></p>
            <div class="product-grid" id="shop-product-grid"><?php foreach ($products as $product) { shopProductCard($product); } ?></div>
        </div>
    </div></section>
</main>
<?php
$extraScripts = ['../assets/js/shop.js', '../assets/js/cart.js'];
require_once __DIR__ . '/../includes/footer.php';