<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Account Dashboard
 *
 * Requires a logged-in customer. Loads profile, orders and addresses
 * from MySQL. ?order= highlights a placed order; ?panel= opens a tab.
 */

$pageTitle       = 'My Account — SLEEKPICK';
$pageDescription = 'Manage your SLEEKPICK account, orders, and addresses.';
$activeNav       = '';

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

requireLogin('login.php');

$user = currentUser();
if ($user === null) {
    header('Location: login.php');
    exit;
}

$userId = (int) $user['id'];
$userEmail = (string) $user['email'];

$panel = strtolower(trim((string) ($_GET['panel'] ?? 'overview')));
if (!in_array($panel, ['overview', 'orders', 'addresses', 'settings'], true)) {
    $panel = 'overview';
}

$highlightOrder = trim((string) ($_GET['order'] ?? ''));
if ($highlightOrder !== '') {
    $panel = 'orders';
}

$orders = dbFetchAll(
    'SELECT o.id, o.order_number, o.status, o.payment_status, o.payment_method,
            o.total, o.placed_at,
            (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
       FROM orders o
      WHERE o.user_id = ? OR o.email = ?
      ORDER BY o.placed_at DESC
      LIMIT 50',
    [$userId, $userEmail]
);

$addresses = dbFetchAll(
    'SELECT id, label, full_name, line1, line2, city, state, postal_code, country, phone, is_default
       FROM addresses
      WHERE user_id = ?
      ORDER BY is_default DESC, id DESC',
    [$userId]
);

$orderCount = count($orders);
$addressCount = count($addresses);
$mostRecentOrder = $orders[0] ?? null;
$flashes = takeFlashes();

require_once __DIR__ . '/../includes/header.php';
?>

<main>
    <section class="page-header">
        <div class="container">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="index.php">Home</a>
                <i class="bi bi-chevron-right"></i>
                <span class="current">My Account</span>
            </nav>
            <div class="account-welcome">
                <h1>Welcome back, <?php echo e((string) $user['first_name']); ?></h1>
                <p>Manage your orders, addresses, and account details.</p>
            </div>
        </div>
    </section>

    <section class="account-section">
        <div class="container account-layout">

            <aside class="account-sidebar">
                <nav class="account-nav" aria-label="Account navigation">
                    <button type="button" class="account-nav-item<?php echo $panel === 'overview' ? ' active' : ''; ?>" data-panel="overview">
                        <i class="bi bi-grid"></i> Overview
                    </button>
                    <button type="button" class="account-nav-item<?php echo $panel === 'orders' ? ' active' : ''; ?>" data-panel="orders">
                        <i class="bi bi-box-seam"></i> Order History
                    </button>
                    <button type="button" class="account-nav-item<?php echo $panel === 'addresses' ? ' active' : ''; ?>" data-panel="addresses">
                        <i class="bi bi-geo-alt"></i> Addresses
                    </button>
                    <button type="button" class="account-nav-item<?php echo $panel === 'settings' ? ' active' : ''; ?>" data-panel="settings">
                        <i class="bi bi-gear"></i> Account Settings
                    </button>
                    <a href="logout.php" class="account-nav-item logout">
                        <i class="bi bi-box-arrow-right"></i> Log Out
                    </a>
                </nav>
            </aside>

            <div class="account-content">

                <?php foreach ($flashes as $flash): ?>
                    <div class="form-message <?php echo $flash['type'] === 'error' ? 'error' : 'success'; ?>" role="status">
                        <?php echo e((string) $flash['message']); ?>
                    </div>
                <?php endforeach; ?>

                <div class="account-panel<?php echo $panel === 'overview' ? ' active' : ''; ?>" data-panel="overview">
                    <h2 class="panel-heading">Account Overview</h2>

                    <div class="account-stats-grid">
                        <div class="stat-card">
                            <i class="bi bi-box-seam"></i>
                            <div>
                                <strong><?php echo (int) $orderCount; ?></strong>
                                <span>Total Orders</span>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="bi bi-geo-alt"></i>
                            <div>
                                <strong><?php echo (int) $addressCount; ?></strong>
                                <span>Saved Addresses</span>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="bi bi-person-check"></i>
                            <div>
                                <strong><?php echo e(ucfirst((string) $user['role'])); ?></strong>
                                <span>Account type</span>
                            </div>
                        </div>
                    </div>

                    <?php if ($mostRecentOrder): ?>
                        <h3 class="account-subheading">Most Recent Order</h3>
                        <div class="recent-order-preview">
                            <div class="order-meta">
                                <strong>Order #<?php echo e((string) $mostRecentOrder['order_number']); ?></strong>
                                Placed <?php echo e(date('M j, Y', strtotime((string) $mostRecentOrder['placed_at']))); ?>
                                &middot;
                                <?php echo (int) $mostRecentOrder['item_count']; ?>
                                item<?php echo (int) $mostRecentOrder['item_count'] === 1 ? '' : 's'; ?>
                                &middot;
                                $<?php echo number_format((float) $mostRecentOrder['total'], 2); ?>
                            </div>
                            <span class="status-badge status-<?php echo e((string) $mostRecentOrder['status']); ?>">
                                <?php echo e((string) $mostRecentOrder['status']); ?>
                            </span>
                        </div>
                        <p class="account-panel-link">
                            <a href="#" data-goto-panel="orders" class="view-order-link">
                                View all orders <i class="bi bi-arrow-right"></i>
                            </a>
                        </p>
                    <?php else: ?>
                        <div class="account-empty">
                            <p>You have not placed an order yet.</p>
                            <a href="shop.php" class="btn btn-secondary">Start shopping</a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="account-panel<?php echo $panel === 'orders' ? ' active' : ''; ?>" data-panel="orders" id="orders">
                    <h2 class="panel-heading">Order History</h2>

                    <?php if ($orders === []): ?>
                        <div class="account-empty">
                            <p>No orders found for this account.</p>
                            <a href="shop.php" class="btn btn-primary">Browse the shop</a>
                        </div>
                    <?php else: ?>
                        <div class="order-table-wrap">
                            <table class="order-table">
                                <thead>
                                    <tr>
                                        <th>Order</th>
                                        <th>Date</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        <th>Payment</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order):
                                        $isHighlight = $highlightOrder !== ''
                                            && strcasecmp($highlightOrder, (string) $order['order_number']) === 0;
                                        ?>
                                        <tr class="<?php echo $isHighlight ? 'order-row-highlight' : ''; ?>"
                                            id="order-<?php echo e((string) $order['order_number']); ?>">
                                            <td>
                                                <strong>#<?php echo e((string) $order['order_number']); ?></strong>
                                                <?php if ($isHighlight): ?>
                                                    <span class="order-just-placed">Just placed</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(date('M j, Y', strtotime((string) $order['placed_at']))); ?></td>
                                            <td><?php echo (int) $order['item_count']; ?></td>
                                            <td>$<?php echo number_format((float) $order['total'], 2); ?></td>
                                            <td>
                                                <?php echo e(str_replace('_', ' ', (string) $order['payment_method'])); ?>
                                                <br>
                                                <small><?php echo e((string) $order['payment_status']); ?></small>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?php echo e((string) $order['status']); ?>">
                                                    <?php echo e((string) $order['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="account-panel<?php echo $panel === 'addresses' ? ' active' : ''; ?>" data-panel="addresses">
                    <h2 class="panel-heading">Saved Addresses</h2>

                    <div class="address-grid">
                        <?php if ($addresses === []): ?>
                            <div class="account-empty">
                                <p>No saved addresses yet. Addresses you use at checkout can appear here when you are signed in.</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($addresses as $address): ?>
                                <div class="address-card<?php echo (int) $address['is_default'] === 1 ? ' default' : ''; ?>">
                                    <?php if ((int) $address['is_default'] === 1): ?>
                                        <span class="default-badge">Default</span>
                                    <?php endif; ?>
                                    <h4><?php echo e((string) ($address['label'] ?: 'Address')); ?></h4>
                                    <p>
                                        <?php echo e((string) $address['full_name']); ?><br>
                                        <?php echo e((string) $address['line1']); ?><br>
                                        <?php if (!empty($address['line2'])): ?>
                                            <?php echo e((string) $address['line2']); ?><br>
                                        <?php endif; ?>
                                        <?php echo e((string) $address['city']); ?><?php echo !empty($address['state']) ? ', ' . e((string) $address['state']) : ''; ?><br>
                                        <?php if (!empty($address['postal_code'])): ?>
                                            <?php echo e((string) $address['postal_code']); ?><br>
                                        <?php endif; ?>
                                        <?php echo e((string) $address['country']); ?>
                                        <?php if (!empty($address['phone'])): ?>
                                            <br><?php echo e((string) $address['phone']); ?>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="account-panel<?php echo $panel === 'settings' ? ' active' : ''; ?>" data-panel="settings">
                    <h2 class="panel-heading">Account Settings</h2>

                    <form class="settings-form"
                          method="post"
                          action="../actions/account-profile-save.php">
                        <?php echo csrfField(); ?>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="first-name">First Name</label>
                                <input type="text" id="first-name" name="first_name"
                                       value="<?php echo e((string) $user['first_name']); ?>" required maxlength="60">
                            </div>
                            <div class="form-group">
                                <label for="last-name">Last Name</label>
                                <input type="text" id="last-name" name="last_name"
                                       value="<?php echo e((string) $user['last_name']); ?>" required maxlength="60">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email"
                                   value="<?php echo e((string) $user['email']); ?>" required maxlength="190">
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone"
                                   value="<?php echo e((string) ($user['phone'] ?? '')); ?>" maxlength="30">
                        </div>

                        <div class="form-divider"></div>

                        <h3 class="account-subheading">Change Password</h3>
                        <p class="account-hint">Leave blank to keep your current password.</p>

                        <div class="form-group">
                            <label for="current-password">Current Password</label>
                            <input type="password" id="current-password" name="current_password" autocomplete="current-password">
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="new-password">New Password</label>
                                <input type="password" id="new-password" name="new_password" autocomplete="new-password" minlength="8">
                            </div>
                            <div class="form-group">
                                <label for="confirm-password">Confirm New Password</label>
                                <input type="password" id="confirm-password" name="confirm_password" autocomplete="new-password" minlength="8">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary save-settings-btn">Save Changes</button>
                    </form>
                </div>

            </div>
        </div>
    </section>
</main>

<?php
require_once __DIR__ . '/../includes/footer.php';