<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Logout link target (customer site)
 *
 * Kept because existing markup links to public/logout.php. Logging out
 * must be a POST with a CSRF token (see actions/logout.php), so this
 * page renders a tiny auto-submitting form rather than destroying the
 * session on a GET request.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signing out — SLEEKPICK</title>
    <meta name="robots" content="noindex">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
</head>
<body class="auth-page">
    <main class="auth-shell">
        <div class="auth-card" style="text-align:center;">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <p style="margin-top:1rem;">Signing you out<span aria-hidden="true">…</span></p>

            <form id="logout-form" method="post" action="../actions/logout.php">
                <?php echo csrfField(); ?>
                <noscript>
                    <button type="submit" class="btn btn-primary" style="margin-top:1rem;">
                        <i class="bi bi-box-arrow-right"></i> Confirm sign out
                    </button>
                </noscript>
            </form>
        </div>
    </main>

    <script>
        document.getElementById('logout-form').submit();
    </script>
</body>
</html>
