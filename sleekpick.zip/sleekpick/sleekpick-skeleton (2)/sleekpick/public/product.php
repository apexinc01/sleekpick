<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Product Detail Page
 * Loads one product by slug (or id), variants, related items.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

$slug = trim((string) ($_GET['slug'] ?? ''));
$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);

$product = null;
if ($slug !== '') {
    $product = dbFetch(
        'SELECT p.*, c.name AS category, c.slug AS category_slug
           FROM products p
           LEFT JOIN categories c ON c.id = p.category_id
          WHERE p.slug = ? AND p.is_active = 1
          LIMIT 1',
        [$slug]
    );
} elseif ($id) {
    $product = dbFetch(
        'SELECT p.*, c.name AS category, c.slug AS category_slug
           FROM products p
           LEFT JOIN categories c ON c.id = p.category_id
          WHERE p.id = ? AND p.is_active = 1
          LIMIT 1',
        [$id]
    );
}

if ($product === null) {
    http_response_code(404);
    $pageTitle = 'Product Not Found — SLEEKPICK';
    $pageDescription = 'This product is no longer available.';
    $activeNav = 'shop';
    require_once __DIR__ . '/../includes/header.php';
    ?>
    <main>
        <section class="page-header">
            <div class="container">
                <h1>Product not found</h1>
                <p>This signal is no longer available.</p>
                <a class="btn btn-primary" href="shop.php">Back to Shop</a>
            </div>
        </section>
    </main>
    <?php
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$pageTitle = $product['name'] . ' — SLEEKPICK';
$pageDescription = (string) ($product['short_description'] ?: ($product['description'] ?? 'SLEEKPICK product'));
$activeNav = 'shop';

$variants = productVariants((int) $product['id']);
$sizes = array_values(array_unique(array_filter(array_column($variants, 'size'))));
$colors = array_values(array_unique(array_filter(array_column($variants, 'color'))));

if ($sizes === []) {
    $sizes = ['One Size'];
}
if ($colors === []) {
    $colors = ['Default'];
}

$defaultSize = $sizes[0];
$defaultColor = $colors[0];

foreach ($variants as $variantRow) {
    if ((int) ($variantRow['stock'] ?? 0) > 0) {
        $defaultSize = (string) $variantRow['size'];
        $defaultColor = (string) $variantRow['color'];
        break;
    }
}

$image = productImageUrl($product['image'] ?? null, (string) $product['name']);
$galleryImages = [
    $image,
    'https://picsum.photos/seed/sp' . (int) $product['id'] . 'a/800/1000',
    'https://picsum.photos/seed/sp' . (int) $product['id'] . 'b/800/1000',
];

$discount = 0;
if ($product['compare_price'] !== null && (float) $product['compare_price'] > (float) $product['price']) {
    $discount = (int) round(
        (((float) $product['compare_price'] - (float) $product['price']) / (float) $product['compare_price']) * 100
    );
}

$freeShippingMin = (float) (settingValue('free_shipping_minimum', '80') ?? 80);
$inStock = (int) $product['stock'] > 0;
if ($variants !== []) {
    $inStock = false;
    foreach ($variants as $variantRow) {
        if ((int) ($variantRow['stock'] ?? 0) > 0) {
            $inStock = true;
            break;
        }
    }
}

$related = dbFetchAll(
    'SELECT p.*, c.name AS category, c.slug AS category_slug
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.is_active = 1
        AND p.id <> ?
        AND (p.category_id <=> ?)
      ORDER BY p.is_featured DESC, p.created_at DESC
      LIMIT 4',
    [(int) $product['id'], $product['category_id']]
);

$colorHex = [
    'Black' => '#1B1F1F',
    'White' => '#F5F5F5',
    'Teal'  => '#54BAC1',
    'Gray'  => '#8A8F98',
    'Grey'  => '#8A8F98',
    'Default' => '#54BAC1',
];

require_once __DIR__ . '/../includes/header.php';
?>

<main>
    <section class="page-header">
        <div class="container">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="index.php">Home</a>
                <i class="bi bi-chevron-right"></i>
                <a href="shop.php">Shop</a>
                <?php if (!empty($product['category_slug'])): ?>
                    <i class="bi bi-chevron-right"></i>
                    <a href="shop.php?category=<?php echo e((string) $product['category_slug']); ?>">
                        <?php echo e((string) $product['category']); ?>
                    </a>
                <?php endif; ?>
                <i class="bi bi-chevron-right"></i>
                <span class="current"><?php echo e((string) $product['name']); ?></span>
            </nav>
        </div>
    </section>

    <section class="product-detail">
        <div class="container product-detail-layout">

            <div class="product-gallery">
                <div class="gallery-main corner-brackets">
                    <span></span><span></span><span></span><span></span>
                    <img src="<?php echo e($galleryImages[0]); ?>"
                         alt="<?php echo e((string) $product['name']); ?>"
                         id="main-product-image">
                </div>
                <div class="gallery-thumbs">
                    <?php foreach ($galleryImages as $index => $thumbSrc): ?>
                        <button type="button"
                                class="gallery-thumb<?php echo $index === 0 ? ' active' : ''; ?>"
                                aria-label="View image <?php echo $index + 1; ?>">
                            <img src="<?php echo e($thumbSrc); ?>" alt="" loading="lazy">
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="product-info-panel" data-product-id="<?php echo (int) $product['id']; ?>">
                <span class="detail-category"><?php echo e((string) ($product['category'] ?? 'Collection')); ?></span>
                <h1 class="detail-name"><?php echo e((string) $product['name']); ?></h1>

                <div class="detail-price">
                    <span class="price-current">$<?php echo number_format((float) $product['price'], 2); ?></span>
                    <?php if ($product['compare_price'] !== null && $discount > 0): ?>
                        <span class="price-original">$<?php echo number_format((float) $product['compare_price'], 2); ?></span>
                        <span class="price-save"><?php echo $discount; ?>% off</span>
                    <?php endif; ?>
                </div>

                <?php if (!empty($product['short_description'])): ?>
                    <p class="detail-desc"><?php echo e((string) $product['short_description']); ?></p>
                <?php endif; ?>

                <div class="stock-status<?php echo $inStock ? '' : ' is-out'; ?>">
                    <i class="bi bi-circle-fill"></i>
                    <?php echo $inStock ? 'In stock, ready to ship' : 'Out of stock'; ?>
                </div>

                <div class="option-group">
                    <div class="option-label">
                        <span>Color</span>
                        <span class="selected-value" data-selected="color"><?php echo e($defaultColor); ?></span>
                    </div>
                    <div class="color-options detail-color-options">
                        <?php foreach ($colors as $color): ?>
                            <?php
                            $hex = $colorHex[$color] ?? '#54BAC1';
                            $isActive = $color === $defaultColor;
                            ?>
                            <button type="button"
                                    class="color-swatch<?php echo $isActive ? ' active' : ''; ?>"
                                    data-label="<?php echo e($color); ?>"
                                    aria-label="<?php echo e($color); ?>"
                                    style="background: <?php echo e($hex); ?>;">
                                <i class="bi bi-check-lg"></i>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="option-group">
                    <div class="option-label">
                        <span>Size</span>
                        <span class="selected-value" data-selected="size"><?php echo e($defaultSize); ?></span>
                    </div>
                    <div class="size-options detail-size-options">
                        <?php foreach ($sizes as $size): ?>
                            <button type="button"
                                    class="size-btn<?php echo $size === $defaultSize ? ' active' : ''; ?>">
                                <?php echo e($size); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="option-group">
                    <div class="option-label"><span>Quantity</span></div>
                    <div class="qty-stepper">
                        <button type="button" class="qty-decrease" aria-label="Decrease quantity">&minus;</button>
                        <input type="text" value="1" inputmode="numeric" aria-label="Quantity">
                        <button type="button" class="qty-increase" aria-label="Increase quantity">+</button>
                    </div>
                </div>

                <div class="detail-actions">
                    <button type="button"
                            class="add-to-cart-btn"
                            data-product-id="<?php echo (int) $product['id']; ?>"
                            data-size="<?php echo e($defaultSize); ?>"
                            data-color="<?php echo e($defaultColor); ?>"
                            <?php echo $inStock ? '' : ' disabled'; ?>>
                        <i class="bi bi-bag-plus"></i>
                        <?php echo $inStock ? 'Add to Cart' : 'Out of Stock'; ?>
                    </button>
                    <button type="button"
                            class="detail-wishlist-btn"
                            aria-label="Add to wishlist"
                            aria-pressed="false">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>

                <div class="trust-row">
                    <div class="value-item">
                        <i class="bi bi-truck"></i>
                        <div>
                            <strong>Free Shipping</strong>
                            <span>Orders over $<?php echo number_format($freeShippingMin, 0); ?></span>
                        </div>
                    </div>
                    <div class="value-item">
                        <i class="bi bi-arrow-repeat"></i>
                        <div>
                            <strong>Easy Returns</strong>
                            <span>30-day window</span>
                        </div>
                    </div>
                    <div class="value-item">
                        <i class="bi bi-shield-check"></i>
                        <div>
                            <strong>Secure Checkout</strong>
                            <span>Encrypted</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="product-tabs">
                <div class="tab-buttons">
                    <button type="button" class="tab-btn active" data-tab="description">Description</button>
                    <button type="button" class="tab-btn" data-tab="details">Details &amp; Care</button>
                    <button type="button" class="tab-btn" data-tab="shipping">Shipping &amp; Returns</button>
                </div>

                <div class="tab-panel active" data-tab="description">
                    <p><?php echo e((string) ($product['description'] ?: $product['short_description'])); ?></p>
                </div>

                <div class="tab-panel" data-tab="details">
                    <p>
                        SKU: <?php echo e((string) ($product['sku'] ?? '—')); ?><br>
                        Category: <?php echo e((string) ($product['category'] ?? 'Collection')); ?><br>
                        Designed for movement with a technical SLEEKPICK finish.
                    </p>
                </div>

                <div class="tab-panel" data-tab="shipping">
                    <p>
                        Free standard shipping on orders over $<?php echo number_format($freeShippingMin, 0); ?>.
                        Returns accepted within 30 days in original condition.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <?php if ($related !== []): ?>
        <section class="related-section">
            <div class="container">
                <div class="section-heading">
                    <span class="section-eyebrow">You Might Also Like</span>
                    <h2>Complete the look</h2>
                </div>
                <div class="product-grid">
                    <?php foreach ($related as $item):
                        $relVariants = productVariants((int) $item['id']);
                        $relSizes = array_values(array_unique(array_filter(array_column($relVariants, 'size'))));
                        $relColors = array_values(array_unique(array_filter(array_column($relVariants, 'color'))));
                        $relSize = $relSizes[0] ?? 'One Size';
                        $relColor = $relColors[0] ?? 'Default';
                        foreach ($relVariants as $rv) {
                            if ((int) ($rv['stock'] ?? 0) > 0) {
                                $relSize = (string) $rv['size'];
                                $relColor = (string) $rv['color'];
                                break;
                            }
                        }
                        ?>
                        <article class="product-card">
                            <div class="product-media">
                                <a href="product.php?slug=<?php echo e((string) $item['slug']); ?>">
                                    <img src="<?php echo e(productImageUrl($item['image'] ?? null, (string) $item['name'])); ?>"
                                         alt="<?php echo e((string) $item['name']); ?>"
                                         loading="lazy">
                                </a>
                            </div>
                            <div class="product-info">
                                <span class="product-category"><?php echo e((string) ($item['category'] ?? 'Collection')); ?></span>
                                <h3 class="product-name">
                                    <a href="product.php?slug=<?php echo e((string) $item['slug']); ?>">
                                        <?php echo e((string) $item['name']); ?>
                                    </a>
                                </h3>
                                <div class="product-price">
                                    <span class="price-current">$<?php echo number_format((float) $item['price'], 2); ?></span>
                                </div>
                                <button type="button"
                                        class="add-to-cart-btn"
                                        data-product-id="<?php echo (int) $item['id']; ?>"
                                        data-size="<?php echo e($relSize); ?>"
                                        data-color="<?php echo e($relColor); ?>">
                                    <i class="bi bi-bag-plus"></i> Add to Cart
                                </button>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php
$extraScripts = ['../assets/js/cart.js'];
require_once __DIR__ . '/../includes/footer.php';