<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Cart Page
 *
 * Reads the session cart (see includes/functions.php). Quantity updates
 * and removals go through actions/update-cart.php and
 * actions/remove-from-cart.php via assets/js/cart.js.
 */

$pageTitle       = 'Your Cart — SLEEKPICK';
$pageDescription = 'Review your SLEEKPICK cart before checkout.';
$activeNav       = '';

require_once __DIR__ . '/../includes/header.php';

$cart = getCart();
$cartCount = getCartCount($cart);
$subtotal = getCartSubtotal($cart);

$freeShippingThreshold = (float) (settingValue('free_shipping_minimum', '80') ?? 80);
$shippingFlatRate      = (float) (settingValue('shipping_flat_rate', '9.99') ?? 9.99);
$currencySymbol        = (string) (settingValue('currency_symbol', '$') ?? '$');

$shipping = ($subtotal <= 0 || $subtotal >= $freeShippingThreshold) ? 0.0 : $shippingFlatRate;
$total = $subtotal + $shipping;
$amountToFreeShipping = max(0.0, $freeShippingThreshold - $subtotal);
$hasItems = $cart !== [];

// Enrich lines with a fresh image URL when possible
$lines = [];
foreach ($cart as $key => $item) {
    $productId = (int) ($item['productId'] ?? 0);
    $imagePath = (string) ($item['image'] ?? '');
    $name = (string) ($item['name'] ?? 'Product');
    $slug = '';

    if ($productId > 0) {
        $row = dbFetch(
            'SELECT slug, image, name FROM products WHERE id = ? AND is_active = 1 LIMIT 1',
            [$productId]
        );
        if ($row !== null) {
            $slug = (string) $row['slug'];
            if (!empty($row['image'])) {
                $imagePath = (string) $row['image'];
            }
            $name = (string) $row['name'];
        }
    }

    $lines[] = [
        'key'      => $key,
        'productId'=> $productId,
        'name'     => $name,
        'slug'     => $slug,
        'price'    => (float) ($item['price'] ?? 0),
        'size'     => (string) ($item['size'] ?? ''),
        'color'    => (string) ($item['color'] ?? ''),
        'quantity' => max(1, (int) ($item['quantity'] ?? 1)),
        'image'    => productImageUrl($imagePath !== '' ? $imagePath : null, $name),
    ];
}
?>

<main>
    <section class="page-header">
        <div class="container">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="index.php">Home</a>
                <i class="bi bi-chevron-right"></i>
                <span class="current">Cart</span>
            </nav>
            <h1>Your Cart</h1>
            <?php if ($hasItems): ?>
                <p class="page-header-note"><?php echo (int) $cartCount; ?> item<?php echo $cartCount === 1 ? '' : 's'; ?> in your bag</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="cart-section"
             data-free-shipping="<?php echo e((string) $freeShippingThreshold); ?>"
             data-shipping-rate="<?php echo e((string) $shippingFlatRate); ?>"
             data-currency="<?php echo e($currencySymbol); ?>">
        <div class="container">

            <div class="empty-cart"<?php echo $hasItems ? ' hidden' : ''; ?>>
                <i class="bi bi-bag-x"></i>
                <h2>Your cart is empty</h2>
                <p>Looks like you haven't added anything yet. Let's fix that.</p>
                <a href="shop.php" class="btn btn-primary">Continue Shopping</a>
            </div>

            <div class="cart-layout"<?php echo $hasItems ? '' : ' hidden'; ?>>

                <div>
                    <div class="cart-items">
                        <?php foreach ($lines as $item):
                            $lineTotal = $item['price'] * $item['quantity'];
                            ?>
                            <div class="cart-item"
                                 data-key="<?php echo e($item['key']); ?>"
                                 data-price="<?php echo e((string) $item['price']); ?>"
                                 data-product-id="<?php echo (int) $item['productId']; ?>">
                                <div class="cart-item-image">
                                    <?php if ($item['slug'] !== ''): ?>
                                        <a href="product.php?slug=<?php echo e($item['slug']); ?>">
                                            <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>">
                                        </a>
                                    <?php else: ?>
                                        <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>">
                                    <?php endif; ?>
                                </div>

                                <div class="cart-item-info">
                                    <h3>
                                        <?php if ($item['slug'] !== ''): ?>
                                            <a href="product.php?slug=<?php echo e($item['slug']); ?>"><?php echo e($item['name']); ?></a>
                                        <?php else: ?>
                                            <?php echo e($item['name']); ?>
                                        <?php endif; ?>
                                    </h3>
                                    <p class="cart-item-variant">
                                        Size: <?php echo e($item['size']); ?>
                                        &middot;
                                        Color: <?php echo e($item['color']); ?>
                                    </p>

                                    <div class="cart-item-controls">
                                        <div class="qty-stepper">
                                            <button type="button" class="qty-decrease" aria-label="Decrease quantity">&minus;</button>
                                            <input type="text"
                                                   value="<?php echo (int) $item['quantity']; ?>"
                                                   inputmode="numeric"
                                                   aria-label="Quantity for <?php echo e($item['name']); ?>">
                                            <button type="button" class="qty-increase" aria-label="Increase quantity">+</button>
                                        </div>
                                        <button type="button" class="remove-item-btn">
                                            <i class="bi bi-trash3"></i> Remove
                                        </button>
                                    </div>
                                </div>

                                <div class="cart-item-price">
                                    <span class="line-total">$<?php echo number_format($lineTotal, 2); ?></span>
                                    <span class="unit-price">$<?php echo number_format($item['price'], 2); ?> each</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <a href="shop.php" class="cart-back-link">
                        <i class="bi bi-arrow-left"></i> Continue Shopping
                    </a>
                </div>

                <aside class="cart-summary">
                    <h2>Order Summary</h2>

                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span class="value summary-subtotal">$<?php echo number_format($subtotal, 2); ?></span>
                    </div>
                    <div class="summary-row<?php echo $shipping === 0.0 ? ' free-shipping' : ''; ?>">
                        <span>Shipping</span>
                        <span class="value summary-shipping">
                            <?php echo $shipping === 0.0 ? 'Free' : '$' . number_format($shipping, 2); ?>
                        </span>
                    </div>

                    <p class="free-shipping-hint"<?php echo $amountToFreeShipping > 0 ? '' : ' hidden'; ?>>
                        Add <strong class="free-shipping-remaining">$<?php echo number_format($amountToFreeShipping, 2); ?></strong>
                        more for free shipping
                    </p>

                    <div class="summary-divider"></div>

                    <div class="summary-row total">
                        <span>Total</span>
                        <span class="value summary-total">$<?php echo number_format($total, 2); ?></span>
                    </div>

                    <a href="checkout.php" class="btn btn-primary checkout-btn">
                        Proceed to Checkout <i class="bi bi-arrow-right"></i>
                    </a>

                    <p class="secure-note">
                        <i class="bi bi-shield-check"></i> Secure, encrypted checkout
                    </p>
                </aside>
            </div>
        </div>
    </section>
</main>

<?php
$extraScripts = ['../assets/js/cart.js'];
require_once __DIR__ . '/../includes/footer.php';