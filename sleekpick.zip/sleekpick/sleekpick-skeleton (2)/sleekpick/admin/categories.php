<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Categories
 *
 * Live category list from the `categories` table with product counts.
 * Create posts to actions/admin-category-save.php.
 * Visibility toggle uses actions/admin-category-status.php (fetch).
 */

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Categories — SLEEKPICK Admin';

$search = trim((string) ($_GET['q'] ?? $_GET['search'] ?? ''));
$statusFilter = strtolower(trim((string) ($_GET['status'] ?? 'all')));
if (!in_array($statusFilter, ['all', 'active', 'hidden'], true)) {
    $statusFilter = 'all';
}
if (mb_strlen($search) > 80) {
    $search = mb_substr($search, 0, 80);
}

$where  = [];
$params = [];

if ($search !== '') {
    $where[] = '(c.name LIKE ? OR c.slug LIKE ? OR c.description LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if ($statusFilter === 'active') {
    $where[] = 'c.is_active = 1';
} elseif ($statusFilter === 'hidden') {
    $where[] = 'c.is_active = 0';
}

$whereSql = $where === [] ? '' : ' WHERE ' . implode(' AND ', $where);

$categories = dbFetchAll(
    'SELECT c.id, c.name, c.slug, c.description, c.sort_order, c.is_active, c.created_at,
            (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count
       FROM categories c'
    . $whereSql
    . ' ORDER BY c.sort_order ASC, c.name ASC',
    $params
);

$totalCategories = (int) dbFetchColumn('SELECT COUNT(*) FROM categories');
$activeCount     = (int) dbFetchColumn('SELECT COUNT(*) FROM categories WHERE is_active = 1');
$hiddenCount     = (int) dbFetchColumn('SELECT COUNT(*) FROM categories WHERE is_active = 0');
$productCount    = (int) dbFetchColumn('SELECT COUNT(*) FROM products WHERE category_id IS NOT NULL');

$hasFilters = $search !== '' || $statusFilter !== 'all';
$flashes = takeFlashes();

adminRenderHead($pageTitle);
adminRenderShellStart('categories');
?>

<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Catalog structure</span>
        <h1>Categories</h1>
        <p>Organise the collection so shoppers can find their next signal faster.</p>
    </div>
    <button type="button" class="admin-btn admin-btn-primary" data-open-modal="category-modal">
        <i class="bi bi-plus-lg" aria-hidden="true"></i> Add Category
    </button>
</div>

<?php foreach ($flashes as $flash): ?>
    <div class="admin-flash admin-flash-<?php echo $flash['type'] === 'error' ? 'error' : 'success'; ?>">
        <i class="bi <?php echo $flash['type'] === 'error' ? 'bi-exclamation-triangle' : 'bi-check-circle'; ?>"></i>
        <span><?php echo adminEsc((string) $flash['message']); ?></span>
    </div>
<?php endforeach; ?>

<div class="admin-stats-row">
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-secondary"><i class="bi bi-tags"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($activeCount); ?></div>
        <div class="admin-stat-label">Live categories</div>
    </div>
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-neutral"><i class="bi bi-box-seam"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($productCount); ?></div>
        <div class="admin-stat-label">Products assigned</div>
    </div>
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-accent"><i class="bi bi-layers"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($totalCategories); ?></div>
        <div class="admin-stat-label">Total categories</div>
    </div>
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-primary"><i class="bi bi-eye-slash"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($hiddenCount); ?></div>
        <div class="admin-stat-label">Hidden</div>
    </div>
</div>

<form class="admin-toolbar-card" method="get" action="categories.php">
    <div class="admin-filter-search">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" name="q" value="<?php echo adminEsc($search); ?>"
               placeholder="Search categories" aria-label="Search categories" data-category-search>
    </div>
    <select class="admin-select" name="status" aria-label="Filter categories by status" data-category-status>
        <option value="all">All visibility</option>
        <option value="active"<?php echo $statusFilter === 'active' ? ' selected' : ''; ?>>Live</option>
        <option value="hidden"<?php echo $statusFilter === 'hidden' ? ' selected' : ''; ?>>Hidden</option>
    </select>
    <button type="submit" class="admin-btn admin-btn-secondary admin-btn-small">Apply</button>
    <?php if ($hasFilters): ?>
        <a href="categories.php" class="admin-btn admin-btn-ghost admin-btn-small">Reset</a>
    <?php endif; ?>
</form>

<?php if ($categories === []): ?>
    <div class="admin-empty-state" data-category-empty>
        <i class="bi bi-tags"></i>
        <?php if ($totalCategories === 0): ?>
            <h2>No categories yet</h2>
            <p>Create your first category to organise the SLEEKPICK catalog.</p>
        <?php else: ?>
            <h2>No categories found</h2>
            <p>Try a different search or visibility filter.</p>
            <p><a href="categories.php" class="admin-btn admin-btn-secondary">Reset filters</a></p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="admin-category-grid" data-category-grid>
        <?php foreach ($categories as $category):
            $isActive    = (int) $category['is_active'] === 1;
            $statusLabel = $isActive ? 'active' : 'hidden';
            $nextState   = $isActive ? 0 : 1;
            $toggleIcon  = $isActive ? 'bi-eye-slash' : 'bi-eye';
            $toggleLabel = $isActive ? 'Hide' : 'Show';
            $createdAt   = $category['created_at'] ? date('M j, Y', strtotime((string) $category['created_at'])) : '—';
            ?>
            <article class="admin-category-card"
                     data-category-row
                     data-category-id="<?php echo (int) $category['id']; ?>"
                     data-status="<?php echo adminEsc($statusLabel); ?>">
                <div class="admin-category-card-top">
                    <span class="admin-category-icon">
                        <i class="bi bi-<?php echo $isActive ? 'layers' : 'archive'; ?>"></i>
                    </span>
                    <div class="admin-row-actions">
                        <button type="button"
                                data-category-toggle="<?php echo (int) $category['id']; ?>"
                                data-next-state="<?php echo $nextState; ?>"
                                aria-label="<?php echo adminEsc($toggleLabel . ' ' . $category['name']); ?>">
                            <i class="bi <?php echo $toggleIcon; ?>"></i>
                        </button>
                    </div>
                </div>
                <h2><?php echo adminEsc($category['name']); ?></h2>
                <p><?php echo adminEsc($category['description'] ?: 'No description yet.'); ?></p>
                <div class="admin-category-card-footer">
                    <span><strong><?php echo (int) $category['product_count']; ?></strong> products</span>
                    <?php echo adminStatusBadge($statusLabel); ?>
                </div>
                <small>
                    /<?php echo adminEsc($category['slug']); ?>
                    · Created <?php echo adminEsc($createdAt); ?>
                </small>
            </article>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="admin-modal-backdrop" data-modal="category-modal" hidden>
    <section class="admin-modal" role="dialog" aria-modal="true" aria-labelledby="category-modal-title">
        <button type="button" class="admin-modal-close" data-close-modal aria-label="Close dialog">
            <i class="bi bi-x-lg"></i>
        </button>
        <span class="admin-eyebrow">Catalog structure</span>
        <h2 id="category-modal-title">Add a category</h2>
        <p class="admin-modal-copy">Create a collection grouping for your product catalog.</p>

        <form class="admin-form-grid" method="post" action="../actions/admin-category-save.php" data-category-form>
            <?php echo csrfField(); ?>

            <div class="admin-form-group full-width">
                <label for="category-name">Category name</label>
                <input class="admin-input" id="category-name" name="name" placeholder="e.g. Footwear" required maxlength="80">
                <p class="admin-field-error"></p>
            </div>

            <div class="admin-form-group">
                <label for="category-slug">URL slug <small>(optional)</small></label>
                <input class="admin-input" id="category-slug" name="slug" placeholder="footwear" maxlength="80">
                <p class="admin-field-error"></p>
            </div>

            <div class="admin-form-group">
                <label for="category-status">Visibility</label>
                <select class="admin-input" id="category-status" name="status">
                    <option value="active">Live</option>
                    <option value="hidden">Hidden</option>
                </select>
                <p class="admin-field-error"></p>
            </div>

            <div class="admin-form-group full-width">
                <label for="category-description">Description</label>
                <textarea class="admin-input admin-textarea" id="category-description" name="description"
                          rows="4" maxlength="255" placeholder="A short description for the category"></textarea>
                <div class="admin-character-count"><span data-character-count>0</span>/255</div>
                <p class="admin-field-error"></p>
            </div>

            <div class="admin-form-actions full-width">
                <button type="button" class="admin-btn admin-btn-ghost" data-close-modal>Cancel</button>
                <button type="submit" class="admin-btn admin-btn-primary">
                    <i class="bi bi-plus-lg"></i> Create category
                </button>
            </div>
        </form>
    </section>
</div>

<?php
adminRenderShellEnd();