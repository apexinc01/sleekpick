<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/admin-helpers.php';
require_once __DIR__ . '/../includes/admin-layout.php';

requireAdmin('login.php');

$pageTitle  = 'Edit Product — SLEEKPICK Admin';
$productId = (int) ($_GET['id'] ?? 0);

$product = dbFetch('SELECT * FROM products WHERE id = ? LIMIT 1', [$productId]);
if ($product === null) {
    setFlash('error', 'Product not found.');
    header('Location: products.php');
    exit;
}

$categories   = dbFetchAll('SELECT id, name, slug FROM categories WHERE is_active = 1 ORDER BY sort_order, name');
$categorySlug = $product['category_id'] ? (string) dbFetchColumn('SELECT slug FROM categories WHERE id = ? LIMIT 1', [$product['category_id']]) : '';
$currentStatus = $product['is_active'] ? 'active' : 'draft';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf(false);

    $name        = trim((string) ($_POST['name'] ?? ''));
    $sku         = trim((string) ($_POST['sku'] ?? ''));
    $newCatSlug  = trim((string) ($_POST['category'] ?? ''));
    $price       = (string) ($_POST['price'] ?? '');
    $stock       = (string) ($_POST['stock'] ?? '');
    $description = trim((string) ($_POST['description'] ?? ''));
    $status      = in_array($_POST['status'] ?? '', ['draft', 'active', 'archived'], true) ? $_POST['status'] : 'draft';

    if ($name === '') {
        $errors['name'] = 'Product name is required.';
    } elseif (strlen($name) > 150) {
        $errors['name'] = 'Name must be 150 characters or fewer.';
    }
    if ($sku === '') {
        $errors['sku'] = 'SKU is required.';
    } elseif (dbFetchColumn('SELECT 1 FROM products WHERE sku = ? AND id <> ? LIMIT 1', [$sku, $productId]) !== null) {
        $errors['sku'] = 'That SKU is already in use.';
    }
    if ($newCatSlug === '' || dbFetchColumn('SELECT 1 FROM categories WHERE slug = ? AND is_active = 1 LIMIT 1', [$newCatSlug]) === null) {
        $errors['category'] = 'Choose a valid category.';
    }
    if ($price === '' || !is_numeric($price) || (float) $price < 0) {
        $errors['price'] = 'Enter a valid price.';
    }
    if ($stock === '' || !ctype_digit($stock) || (int) $stock < 0) {
        $errors['stock'] = 'Enter a valid stock quantity.';
    }
    if ($description !== '' && strlen($description) > 500) {
        $errors['description'] = 'Description must be 500 characters or fewer.';
    }

    $imagePath = $product['image'];
    $upload = handleProductImageUpload('image');
    if (!empty($upload['error'])) {
        $errors['image'] = $upload['error'];
    } elseif ($upload['ok']) {
        if ($product['image'] && is_file(APP_ROOT . '/' . $product['image'])) {
            @unlink(APP_ROOT . '/' . $product['image']);
        }
        $imagePath = $upload['path'];
    }

    if ($errors === []) {
        $categoryId = (int) dbFetchColumn('SELECT id FROM categories WHERE slug = ? LIMIT 1', [$newCatSlug]);
        dbExecute(
            'UPDATE products
                SET category_id = ?, sku = ?, name = ?, description = ?, price = ?, stock = ?, image = ?, is_active = ?
              WHERE id = ?',
            [
                $categoryId,
                $sku,
                $name,
                $description !== '' ? $description : null,
                (float) $price,
                (int) $stock,
                $imagePath,
                $status === 'active' ? 1 : 0,
                $productId,
            ]
        );

        setFlash('success', 'Product updated.');
        header('Location: products.php');
        exit;
    }

    // Repopulate the form with the submitted values so the admin keeps their edits.
    $product['name']        = $name;
    $product['sku']          = $sku;
    $product['price']        = $price;
    $product['stock']        = $stock;
    $product['description']  = $description;
    $categorySlug            = $newCatSlug;
    $currentStatus           = $status;
}

adminRenderHead($pageTitle);
adminRenderShellStart('products');
?>
<div class="admin-page-header">
    <div><a href__="products.php" class="admin-back-link"><i class="bi bi-arrow-left"></i> Back to products</a><span class="admin-eyebrow">Catalog editor</span><h1>Edit Product</h1><p>Update the product details, stock, and publishing state.</p></div>
    <span class="admin-id-chip">Product #<?php echo adminEsc((string) $productId); ?></span>
</div>

<?php foreach (takeFlashes() as $flash): ?>
    <div class="admin-flash admin-flash-<?php echo adminEsc($flash['type']); ?>"><?php echo adminEsc($flash['message']); ?></div>
<?php endforeach; ?>

<form class="admin-editor-layout" data-admin-form data-product-form data-mode="edit" data-product-id="<?php echo adminEsc((string) $productId); ?>" method="post" action="edit-product.php?id=<?php echo adminEsc((string) $productId); ?>" enctype="multipart/form-data">
    <?php echo csrfField(); ?>
    <section class="admin-card admin-editor-main">
        <div class="admin-card-header"><div><h2>Product details</h2><p class="admin-card-subtitle">Changes are saved to the database.</p></div><?php echo adminStatusBadge($currentStatus); ?></div>
        <div class="admin-form-grid">
            <div class="admin-form-group full-width"><label for="product-name">Product name</label><input class="admin-input" id="product-name" name="name" value="<?php echo adminEsc($product['name']); ?>" required maxlength="80"><div class="admin-character-count"><span data-character-count>0</span>/80</div><p class="admin-field-error"><?php echo adminEsc($errors['name'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-sku">SKU</label><input class="admin-input" id="product-sku" name="sku" value="<?php echo adminEsc($product['sku']); ?>" required maxlength="40"><p class="admin-field-error"><?php echo adminEsc($errors['sku'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-category">Category</label><select class="admin-input" id="product-category" name="category" required><?php foreach ($categories as $cat): ?><option value="<?php echo adminEsc($cat['slug']); ?>"<?php echo $categorySlug === $cat['slug'] ? ' selected' : ''; ?>><?php echo adminEsc($cat['name']); ?></option><?php endforeach; ?></select><p class="admin-field-error"><?php echo adminEsc($errors['category'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-price">Price (USD)</label><div class="admin-input-prefix"><span>$</span><input class="admin-input" id="product-price" name="price" type="number" min="0" step="0.01" value="<?php echo adminEsc($product['price']); ?>" required></div><p class="admin-field-error"><?php echo adminEsc($errors['price'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-stock">Stock</label><input class="admin-input" id="product-stock" name="stock" type="number" min="0" step="1" value="<?php echo adminEsc((string) $product['stock']); ?>" required><p class="admin-field-error"><?php echo adminEsc($errors['stock'] ?? ''); ?></p></div>
            <div class="admin-form-group full-width"><label for="product-description">Description</label><textarea class="admin-input admin-textarea" id="product-description" name="description" rows="6" maxlength="500"><?php echo adminEsc($product['description'] ?? ''); ?></textarea><div class="admin-character-count"><span data-character-count>0</span>/500</div><p class="admin-field-error"><?php echo adminEsc($errors['description'] ?? ''); ?></p></div>
        </div>
    </section>
    <aside class="admin-editor-side">
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Product image</h2><p class="admin-card-subtitle">Replace the visual when the drop changes.</p></div></div>
            <label class="admin-upload-zone" for="product-image"><i class="bi bi-cloud-arrow-up"></i><strong>Choose a new image</strong><span>PNG, JPG up to 5MB</span><input type="file" id="product-image" name="image" accept="image/png,image/jpeg,image/webp" data-image-input></label>
            <div class="admin-image-preview" data-image-preview<?php echo $product['image'] ? '' : ' hidden'; ?>><img src="<?php echo adminEsc(productImageUrl($product['image'], $product['name'])); ?>" alt="Product preview"><button type="button" data-clear-image aria-label="Remove image"><i class="bi bi-x-lg"></i></button></div>
            <p class="admin-field-error"><?php echo adminEsc($errors['image'] ?? ''); ?></p>
            <label class="admin-color-picker-label" for="product-color">Fallback color</label><div class="admin-color-picker"><input type="color" id="product-color" name="color" value="#1B1F1F" data-color-input><span data-color-value>#1B1F1F</span></div>
        </section>
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Publishing</h2><p class="admin-card-subtitle">Control storefront visibility.</p></div></div>
            <?php foreach (['draft' => ['Save as draft', 'Keep it hidden while you prepare the drop.'], 'active' => ['Published', 'Visible to shoppers in the live catalog.'], 'archived' => ['Archive', 'Keep the record for reporting, but hide it.']] as $status => $copy): ?>
                <label class="admin-radio-option"><input type="radio" name="status" value="<?php echo adminEsc($status); ?>"<?php echo $currentStatus === $status ? ' checked' : ''; ?>><span><strong><?php echo adminEsc($copy[0]); ?></strong><small><?php echo adminEsc($copy[1]); ?></small></span></label>
            <?php endforeach; ?>
        </section>
    </aside>
    <div class="admin-form-actions editor-actions"><a href__="products.php" class="admin-btn admin-btn-ghost">Cancel</a><button type="submit" class="admin-btn admin-btn-primary"><i class="bi bi-check2"></i> Save changes</button></div>
</form>
<?php
adminRenderShellEnd();