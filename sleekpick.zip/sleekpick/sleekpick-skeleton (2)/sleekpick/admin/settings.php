<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Settings
 *
 * Store profile, notification preferences and security overview.
 * Values are read from / written to the `settings` key-value table.
 */

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Settings — SLEEKPICK Admin';

$storeName        = (string) (settingValue('store_name', 'SLEEKPICK') ?? 'SLEEKPICK');
$storeEmail       = (string) (settingValue('store_email', 'hello@sleekpick.com') ?? 'hello@sleekpick.com');
$storeDescription = (string) (settingValue('store_description', 'Futuristic fashion for people who dress like it is already tomorrow.') ?? '');
$currency         = (string) (settingValue('currency', 'USD') ?? 'USD');
$timezone         = (string) (settingValue('timezone', 'Africa/Lagos') ?? 'Africa/Lagos');
$currencySymbol   = (string) (settingValue('currency_symbol', '$') ?? '$');
$freeShippingMin  = (string) (settingValue('free_shipping_minimum', '80') ?? '80');
$shippingFlat     = (string) (settingValue('shipping_flat_rate', '9.99') ?? '9.99');
$taxRate          = (string) (settingValue('tax_rate_percent', '0') ?? '0');

$notifyOrders     = (settingValue('notify_new_orders', '1') ?? '1') === '1';
$notifyLowStock   = (settingValue('notify_low_stock', '1') ?? '1') === '1';
$notifyCustomers  = (settingValue('notify_new_customers', '0') ?? '0') === '1';

$currencies = [
    'USD' => 'USD — US Dollar',
    'NGN' => 'NGN — Nigerian Naira',
    'GBP' => 'GBP — British Pound',
    'EUR' => 'EUR — Euro',
];
$timezones = [
    'Africa/Lagos',
    'Europe/London',
    'America/New_York',
    'UTC',
];

$flashes = takeFlashes();
$adminUser = currentUser();

adminRenderHead($pageTitle);
adminRenderShellStart('settings');
?>

<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Control centre</span>
        <h1>Settings</h1>
        <p>Shape how the SLEEKPICK store and admin experience work for your team.</p>
    </div>
    <button type="submit" form="settings-form" class="admin-btn admin-btn-primary">
        <i class="bi bi-check2"></i> Save settings
    </button>
</div>

<?php foreach ($flashes as $flash): ?>
    <div class="admin-flash admin-flash-<?php echo $flash['type'] === 'error' ? 'error' : 'success'; ?>">
        <i class="bi <?php echo $flash['type'] === 'error' ? 'bi-exclamation-triangle' : 'bi-check-circle'; ?>"></i>
        <span><?php echo adminEsc((string) $flash['message']); ?></span>
    </div>
<?php endforeach; ?>

<form id="settings-form" class="admin-settings-layout" method="post" action="../actions/admin-settings-save.php">
    <?php echo csrfField(); ?>

    <nav class="admin-settings-nav" aria-label="Settings sections">
        <button type="button" class="active" data-settings-tab="store">
            <i class="bi bi-shop"></i>
            <span>Store profile<small>Public identity</small></span>
        </button>
        <button type="button" data-settings-tab="commerce">
            <i class="bi bi-truck"></i>
            <span>Commerce<small>Shipping & tax</small></span>
        </button>
        <button type="button" data-settings-tab="notifications">
            <i class="bi bi-bell"></i>
            <span>Notifications<small>Team alerts</small></span>
        </button>
        <button type="button" data-settings-tab="security">
            <i class="bi bi-shield-lock"></i>
            <span>Security<small>Access controls</small></span>
        </button>
    </nav>

    <div class="admin-settings-panels">

        <section class="admin-card admin-settings-panel active" data-settings-panel="store">
            <div class="admin-card-header">
                <div>
                    <h2>Store profile</h2>
                    <p class="admin-card-subtitle">These details keep customer-facing communications consistent.</p>
                </div>
                <i class="bi bi-shop settings-panel-icon"></i>
            </div>
            <div class="admin-form-grid">
                <div class="admin-form-group">
                    <label for="store-name">Store name</label>
                    <input class="admin-input" id="store-name" name="store_name" value="<?php echo adminEsc($storeName); ?>" required maxlength="120">
                    <p class="admin-field-error"></p>
                </div>
                <div class="admin-form-group">
                    <label for="store-email">Support email</label>
                    <input class="admin-input" id="store-email" name="store_email" type="email" value="<?php echo adminEsc($storeEmail); ?>" required maxlength="150">
                    <p class="admin-field-error"></p>
                </div>
                <div class="admin-form-group">
                    <label for="store-currency">Currency</label>
                    <select class="admin-input" id="store-currency" name="currency">
                        <?php foreach ($currencies as $code => $label): ?>
                            <option value="<?php echo adminEsc($code); ?>"<?php echo $currency === $code ? ' selected' : ''; ?>>
                                <?php echo adminEsc($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="admin-form-group">
                    <label for="store-timezone">Timezone</label>
                    <select class="admin-input" id="store-timezone" name="timezone">
                        <?php foreach ($timezones as $tz): ?>
                            <option value="<?php echo adminEsc($tz); ?>"<?php echo $timezone === $tz ? ' selected' : ''; ?>>
                                <?php echo adminEsc($tz); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="admin-form-group full-width">
                    <label for="store-description">Store description</label>
                    <textarea class="admin-input admin-textarea" id="store-description" name="store_description" rows="4" maxlength="500"><?php echo adminEsc($storeDescription); ?></textarea>
                </div>
            </div>
        </section>

        <section class="admin-card admin-settings-panel" data-settings-panel="commerce" hidden>
            <div class="admin-card-header">
                <div>
                    <h2>Commerce</h2>
                    <p class="admin-card-subtitle">Shipping thresholds and tax used at checkout.</p>
                </div>
                <i class="bi bi-truck settings-panel-icon"></i>
            </div>
            <div class="admin-form-grid">
                <div class="admin-form-group">
                    <label for="free-shipping-minimum">Free shipping minimum</label>
                    <input class="admin-input" id="free-shipping-minimum" name="free_shipping_minimum" type="number" min="0" step="0.01" value="<?php echo adminEsc($freeShippingMin); ?>">
                </div>
                <div class="admin-form-group">
                    <label for="shipping-flat-rate">Flat shipping rate</label>
                    <input class="admin-input" id="shipping-flat-rate" name="shipping_flat_rate" type="number" min="0" step="0.01" value="<?php echo adminEsc($shippingFlat); ?>">
                </div>
                <div class="admin-form-group">
                    <label for="tax-rate">Tax rate (%)</label>
                    <input class="admin-input" id="tax-rate" name="tax_rate_percent" type="number" min="0" max="100" step="0.01" value="<?php echo adminEsc($taxRate); ?>">
                </div>
                <div class="admin-form-group">
                    <label for="currency-symbol">Currency symbol</label>
                    <input class="admin-input" id="currency-symbol" name="currency_symbol" value="<?php echo adminEsc($currencySymbol); ?>" maxlength="8">
                </div>
            </div>
        </section>

        <section class="admin-card admin-settings-panel" data-settings-panel="notifications" hidden>
            <div class="admin-card-header">
                <div>
                    <h2>Notifications</h2>
                    <p class="admin-card-subtitle">Choose which events deserve your attention.</p>
                </div>
                <i class="bi bi-bell settings-panel-icon"></i>
            </div>
            <label class="admin-switch-row">
                <span><strong>New orders</strong><small>Get an alert whenever a new order is placed.</small></span>
                <input type="checkbox" name="notify_new_orders" value="1"<?php echo $notifyOrders ? ' checked' : ''; ?>>
                <span class="admin-switch"></span>
            </label>
            <label class="admin-switch-row">
                <span><strong>Low stock</strong><small>Alert the team when inventory drops below five units.</small></span>
                <input type="checkbox" name="notify_low_stock" value="1"<?php echo $notifyLowStock ? ' checked' : ''; ?>>
                <span class="admin-switch"></span>
            </label>
            <label class="admin-switch-row">
                <span><strong>New customers</strong><small>Receive a weekly summary of newly registered customers.</small></span>
                <input type="checkbox" name="notify_new_customers" value="1"<?php echo $notifyCustomers ? ' checked' : ''; ?>>
                <span class="admin-switch"></span>
            </label>
        </section>

        <section class="admin-card admin-settings-panel" data-settings-panel="security" hidden>
            <div class="admin-card-header">
                <div>
                    <h2>Security</h2>
                    <p class="admin-card-subtitle">Staff authentication is live. Keep access limited to trusted accounts.</p>
                </div>
                <i class="bi bi-shield-lock settings-panel-icon"></i>
            </div>

            <div class="admin-security-callout">
                <i class="bi bi-shield-check"></i>
                <span>
                    <strong>Staff authentication is connected.</strong>
                    <small>Login uses password hashing, CSRF protection, attempt throttling and session regeneration.</small>
                </span>
            </div>

            <div class="admin-security-row">
                <span>
                    <strong>Admin session</strong>
                    <small>Signed in as <?php echo adminEsc($adminUser['email'] ?? 'staff'); ?></small>
                </span>
                <span class="admin-status-badge admin-status-active">Active</span>
            </div>
            <div class="admin-security-row">
                <span>
                    <strong>Role</strong>
                    <small>Access is controlled by the users.role column in the database</small>
                </span>
                <span class="admin-status-badge admin-status-active"><?php echo adminEsc(ucfirst((string) ($adminUser['role'] ?? 'admin'))); ?></span>
            </div>
            <div class="admin-security-row">
                <span>
                    <strong>Password protection</strong>
                    <small>Credentials are verified with password_verify() — never stored in plain text</small>
                </span>
                <span class="admin-status-badge admin-status-active">Enabled</span>
            </div>
            <div class="admin-security-row">
                <span>
                    <strong>Login throttling</strong>
                    <small>Failed attempts are limited to reduce brute-force risk</small>
                </span>
                <span class="admin-status-badge admin-status-active">Enabled</span>
            </div>
        </section>

    </div>
</form>

<?php
adminRenderShellEnd();