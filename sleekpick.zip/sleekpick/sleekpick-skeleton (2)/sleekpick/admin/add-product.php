<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/admin-helpers.php';
require_once __DIR__ . '/../includes/admin-layout.php';

requireAdmin('login.php');

$pageTitle = 'Add Product — SLEEKPICK Admin';

$categories = dbFetchAll('SELECT id, name, slug FROM categories WHERE is_active = 1 ORDER BY sort_order, name');

$errors = [];
$old = ['name' => '', 'sku' => '', 'category' => '', 'price' => '', 'stock' => '', 'description' => '', 'status' => 'draft'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf(false);

    $old['name']        = trim((string) ($_POST['name'] ?? ''));
    $old['sku']         = trim((string) ($_POST['sku'] ?? ''));
    $old['category']    = trim((string) ($_POST['category'] ?? ''));
    $old['price']       = (string) ($_POST['price'] ?? '');
    $old['stock']       = (string) ($_POST['stock'] ?? '');
    $old['description'] = trim((string) ($_POST['description'] ?? ''));
    $old['status']      = in_array($_POST['status'] ?? '', ['draft', 'active'], true) ? $_POST['status'] : 'draft';

    if ($old['name'] === '') {
        $errors['name'] = 'Product name is required.';
    } elseif (strlen($old['name']) > 150) {
        $errors['name'] = 'Name must be 150 characters or fewer.';
    }
    if ($old['sku'] === '') {
        $errors['sku'] = 'SKU is required.';
    } elseif (dbFetchColumn('SELECT 1 FROM products WHERE sku = ? LIMIT 1', [$old['sku']]) !== null) {
        $errors['sku'] = 'That SKU is already in use.';
    }
    if ($old['category'] === '' || dbFetchColumn('SELECT 1 FROM categories WHERE slug = ? AND is_active = 1 LIMIT 1', [$old['category']]) === null) {
        $errors['category'] = 'Choose a valid category.';
    }
    if ($old['price'] === '' || !is_numeric($old['price']) || (float) $old['price'] < 0) {
        $errors['price'] = 'Enter a valid price.';
    }
    if ($old['stock'] === '' || !ctype_digit($old['stock']) || (int) $old['stock'] < 0) {
        $errors['stock'] = 'Enter a valid stock quantity.';
    }
    if ($old['description'] !== '' && strlen($old['description']) > 500) {
        $errors['description'] = 'Description must be 500 characters or fewer.';
    }

    $imagePath = null;
    $upload = handleProductImageUpload('image');
    if (!empty($upload['error'])) {
        $errors['image'] = $upload['error'];
    } elseif ($upload['ok']) {
        $imagePath = $upload['path'];
    }

    if ($errors === []) {
        $categoryId = (int) dbFetchColumn('SELECT id FROM categories WHERE slug = ? LIMIT 1', [$old['category']]);
        $slug       = ensureUniqueProductSlug(slugify($old['name']) ?: 'product');

        dbInsert(
            'INSERT INTO products
                (category_id, sku, name, slug, short_description, description, price, stock, image, is_active, is_featured)
             VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, 0)',
            [
                $categoryId,
                $old['sku'],
                $old['name'],
                $slug,
                $old['description'] !== '' ? $old['description'] : null,
                (float) $old['price'],
                (int) $old['stock'],
                $imagePath,
                $old['status'] === 'active' ? 1 : 0,
            ]
        );

        setFlash('success', 'Product "' . $old['name'] . '" created.');
        header('Location: products.php');
        exit;
    }
}

adminRenderHead($pageTitle);
adminRenderShellStart('products');
?>
<div class="admin-page-header">
    <div><a href__="products.php" class="admin-back-link"><i class="bi bi-arrow-left"></i> Back to products</a><span class="admin-eyebrow">Catalog editor</span><h1>Add Product</h1><p>Build a product record ready for the SLEEKPICK storefront.</p></div>
</div>

<?php foreach (takeFlashes() as $flash): ?>
    <div class="admin-flash admin-flash-<?php echo adminEsc($flash['type']); ?>"><?php echo adminEsc($flash['message']); ?></div>
<?php endforeach; ?>

<form class="admin-editor-layout" data-admin-form data-product-form data-mode="create" method="post" action="add-product.php" enctype="multipart/form-data">
    <?php echo csrfField(); ?>
    <section class="admin-card admin-editor-main">
        <div class="admin-card-header"><div><h2>Product details</h2><p class="admin-card-subtitle">The core information customers will see.</p></div><span class="admin-draft-pill"><i class="bi bi-circle-fill"></i> Draft</span></div>
        <div class="admin-form-grid">
            <div class="admin-form-group full-width"><label for="product-name">Product name</label><input class="admin-input" id="product-name" name="name" placeholder="e.g. Orbit Shell Jacket" required maxlength="80" value="<?php echo adminEsc($old['name']); ?>"><div class="admin-character-count"><span data-character-count>0</span>/80</div><p class="admin-field-error"><?php echo adminEsc($errors['name'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-sku">SKU</label><input class="admin-input" id="product-sku" name="sku" placeholder="SP-ORB-M-BLK" required maxlength="40" value="<?php echo adminEsc($old['sku']); ?>"><p class="admin-field-error"><?php echo adminEsc($errors['sku'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-category">Category</label><select class="admin-input" id="product-category" name="category" required><option value="">Choose category</option><?php foreach ($categories as $cat): ?><option value="<?php echo adminEsc($cat['slug']); ?>"<?php echo $old['category'] === $cat['slug'] ? ' selected' : ''; ?>><?php echo adminEsc($cat['name']); ?></option><?php endforeach; ?></select><p class="admin-field-error"><?php echo adminEsc($errors['category'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-price">Price (USD)</label><div class="admin-input-prefix"><span>$</span><input class="admin-input" id="product-price" name="price" type="number" min="0" step="0.01" placeholder="0.00" required value="<?php echo adminEsc($old['price']); ?>"></div><p class="admin-field-error"><?php echo adminEsc($errors['price'] ?? ''); ?></p></div>
            <div class="admin-form-group"><label for="product-stock">Initial stock</label><input class="admin-input" id="product-stock" name="stock" type="number" min="0" step="1" placeholder="0" required value="<?php echo adminEsc($old['stock']); ?>"><p class="admin-field-error"><?php echo adminEsc($errors['stock'] ?? ''); ?></p></div>
            <div class="admin-form-group full-width"><label for="product-description">Description</label><textarea class="admin-input admin-textarea" id="product-description" name="description" rows="6" maxlength="500" placeholder="Describe the fit, fabric, and details."><?php echo adminEsc($old['description']); ?></textarea><div class="admin-character-count"><span data-character-count>0</span>/500</div><p class="admin-field-error"><?php echo adminEsc($errors['description'] ?? ''); ?></p></div>
        </div>
    </section>

    <aside class="admin-editor-side">
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Product image</h2><p class="admin-card-subtitle">Use a local image or the color preview.</p></div></div>
            <label class="admin-upload-zone" for="product-image"><i class="bi bi-cloud-arrow-up"></i><strong>Choose an image</strong><span>PNG, JPG up to 5MB</span><input type="file" id="product-image" name="image" accept="image/png,image/jpeg,image/webp" data-image-input></label>
            <div class="admin-image-preview" data-image-preview hidden><img alt="Product preview"><button type="button" data-clear-image aria-label="Remove image"><i class="bi bi-x-lg"></i></button></div>
            <p class="admin-field-error"><?php echo adminEsc($errors['image'] ?? ''); ?></p>
            <label class="admin-color-picker-label" for="product-color">Fallback color</label><div class="admin-color-picker"><input type="color" id="product-color" name="color" value="#1B1F1F" data-color-input><span data-color-value>#1B1F1F</span></div>
        </section>
        <section class="admin-card">
            <div class="admin-card-header"><div><h2>Publishing</h2><p class="admin-card-subtitle">Choose how this product enters the catalog.</p></div></div>
            <label class="admin-radio-option"><input type="radio" name="status" value="draft"<?php echo $old['status'] === 'draft' ? ' checked' : ''; ?>><span><strong>Save as draft</strong><small>Keep it hidden while you prepare the drop.</small></span></label>
            <label class="admin-radio-option"><input type="radio" name="status" value="active"<?php echo $old['status'] === 'active' ? ' checked' : ''; ?>><span><strong>Publish now</strong><small>Make it visible to shoppers immediately.</small></span></label>
        </section>
    </aside>
    <div class="admin-form-actions editor-actions"><a href__="products.php" class="admin-btn admin-btn-ghost">Cancel</a><button type="submit" class="admin-btn admin-btn-primary"><i class="bi bi-check2"></i> Save product</button></div>
</form>
<?php
adminRenderShellEnd();