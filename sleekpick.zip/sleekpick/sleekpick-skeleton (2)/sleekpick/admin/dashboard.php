<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Dashboard — SLEEKPICK Admin';

$stats = [
    [
        'label' => 'Total Revenue',
        'value' => (float) (dbFetchColumn("SELECT COALESCE(SUM(total), 0) FROM orders WHERE status NOT IN ('cancelled', 'refunded')") ?? 0),
        'format' => 'money',
        'trend' => 'Live',
        'direction' => 'up',
        'icon' => 'bi-cash-stack',
        'tone' => 'primary',
    ],
    [
        'label' => 'Total Orders',
        'value' => (int) (dbFetchColumn('SELECT COUNT(*) FROM orders') ?? 0),
        'format' => 'number',
        'trend' => 'Live',
        'direction' => 'up',
        'icon' => 'bi-bag-check',
        'tone' => 'secondary',
    ],
    [
        'label' => 'Total Customers',
        'value' => (int) (dbFetchColumn("SELECT COUNT(*) FROM users WHERE role = 'customer'") ?? 0),
        'format' => 'number',
        'trend' => 'Live',
        'direction' => 'up',
        'icon' => 'bi-people',
        'tone' => 'accent',
    ],
    [
        'label' => 'Active Products',
        'value' => (int) (dbFetchColumn('SELECT COUNT(*) FROM products WHERE is_active = 1') ?? 0),
        'format' => 'number',
        'trend' => 'Live',
        'direction' => 'up',
        'icon' => 'bi-box-seam',
        'tone' => 'neutral',
    ],
];

$today = new DateTimeImmutable('today');
$chartStart = $today->modify('-6 days')->format('Y-m-d 00:00:00');
$revenueRows = dbFetchAll(
    "SELECT DATE(placed_at) AS day, COALESCE(SUM(total), 0) AS revenue
     FROM orders
     WHERE placed_at >= ? AND status NOT IN ('cancelled', 'refunded')
     GROUP BY DATE(placed_at)
     ORDER BY day",
    [$chartStart]
);
$revenueByDay = [];
foreach ($revenueRows as $row) {
    $revenueByDay[(string) $row['day']] = (float) $row['revenue'];
}
$weeklyRevenueTotal = 0.0;
$weeklyRevenue = [];
for ($offset = 6; $offset >= 0; $offset--) {
    $day = $today->modify("-{$offset} days");
    $key = $day->format('Y-m-d');
    $amount = $revenueByDay[$key] ?? 0.0;
    $weeklyRevenueTotal += $amount;
    $weeklyRevenue[] = ['label' => $day->format('D'), 'amount' => $amount];
}
$maxRevenue = max(array_column($weeklyRevenue, 'amount') ?: [1]);
foreach ($weeklyRevenue as &$day) {
    $day['height'] = $maxRevenue > 0 ? max(5, (int) round(($day['amount'] / $maxRevenue) * 100)) : 5;
    $day['today'] = $day['label'] === $today->format('D');
}
unset($day);

$recentOrders = dbFetchAll(
    "SELECT o.order_number, o.email, o.placed_at, o.total, o.status,
            COALESCE(CONCAT(u.first_name, ' ', u.last_name), o.ship_full_name, o.email) AS customer,
            COUNT(oi.id) AS item_count
     FROM orders o
     LEFT JOIN users u ON u.id = o.user_id
     LEFT JOIN order_items oi ON oi.order_id = o.id
     GROUP BY o.id
     ORDER BY o.placed_at DESC
     LIMIT 5"
);

$topProducts = dbFetchAll(
    "SELECT product_name AS name, SUM(quantity) AS units_sold, SUM(line_total) AS revenue
     FROM order_items oi
     INNER JOIN orders o ON o.id = oi.order_id
     WHERE o.status NOT IN ('cancelled', 'refunded')
     GROUP BY oi.product_id, oi.product_name
     ORDER BY units_sold DESC
     LIMIT 4"
);

$lowStock = dbFetchAll(
    "SELECT name, sku, stock
     FROM products
     WHERE is_active = 1 AND stock <= 5
     ORDER BY stock ASC, name
     LIMIT 5"
);

adminRenderHead($pageTitle);
adminRenderShellStart('dashboard');
?>
<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Store intelligence</span>
        <h1>Dashboard</h1>
        <p>Live performance and inventory signals from your SLEEKPICK database.</p>
    </div>
    <a href="products.php" class="admin-btn admin-btn-secondary"><i class="bi bi-box-seam"></i> Manage catalog</a>
</div>

<div class="admin-stats-row">
    <?php foreach ($stats as $stat): ?>
        <div class="admin-stat-card">
            <div class="admin-stat-card-top">
                <span class="admin-stat-icon tone-<?php echo adminEsc($stat['tone']); ?>"><i class="bi <?php echo adminEsc($stat['icon']); ?>"></i></span>
                <span class="admin-stat-trend <?php echo adminEsc($stat['direction']); ?>"><i class="bi bi-broadcast-pin"></i> <?php echo adminEsc($stat['trend']); ?></span>
            </div>
            <div class="admin-stat-value">
                <?php echo $stat['format'] === 'money' ? '$' . number_format((float) $stat['value'], 2) : number_format((int) $stat['value']); ?>
            </div>
            <div class="admin-stat-label"><?php echo adminEsc($stat['label']); ?></div>
        </div>
    <?php endforeach; ?>
</div>

<div class="admin-dashboard-grid">
    <div>
        <section class="admin-card">
            <div class="admin-card-header">
                <div><span class="admin-eyebrow">Last seven days</span><h2>Revenue This Week</h2></div>
                <span class="admin-live-pill"><i class="bi bi-database-check"></i> MySQL</span>
            </div>
            <div class="revenue-summary">
                <span class="amount">$<?php echo number_format($weeklyRevenueTotal, 2); ?></span>
                <span class="admin-stat-trend up"><i class="bi bi-activity"></i> Live total</span>
            </div>
            <div class="revenue-chart-bars" aria-label="Revenue for the last seven days">
                <?php foreach ($weeklyRevenue as $day): ?>
                    <div class="chart-bar-wrap<?php echo $day['today'] ? ' is-today' : ''; ?>">
                        <div class="chart-bar" style="height: <?php echo (int) $day['height']; ?>%;" title="$<?php echo number_format($day['amount'], 2); ?>"></div>
                        <span class="chart-bar-label"><?php echo adminEsc($day['label']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="admin-card">
            <div class="admin-card-header"><h2>Recent Orders</h2><a href="orders.php" class="admin-link">View all</a></div>
            <?php if ($recentOrders === []): ?>
                <div class="admin-empty-state"><i class="bi bi-bag-x"></i><h2>No orders yet</h2><p>New orders will appear here automatically.</p></div>
            <?php else: ?>
                <div class="admin-table-scroll">
                    <table class="admin-table">
                        <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($recentOrders as $order): ?>
                            <tr>
                                <td class="cell-strong">#<?php echo adminEsc($order['order_number']); ?></td>
                                <td><?php echo adminEsc($order['customer']); ?></td>
                                <td class="cell-muted"><?php echo adminEsc(date('M j, Y', strtotime((string) $order['placed_at']))); ?></td>
                                <td class="cell-strong">$<?php echo number_format((float) $order['total'], 2); ?></td>
                                <td><?php echo adminStatusBadge((string) $order['status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <div>
        <section class="admin-card">
            <div class="admin-card-header"><h2>Top Products</h2><a href="products.php" class="admin-link">View all</a></div>
            <?php if ($topProducts === []): ?>
                <div class="admin-empty-state"><i class="bi bi-box-seam"></i><h2>No sales yet</h2><p>Product performance will appear after the first order.</p></div>
            <?php else: ?>
                <div class="top-products-list">
                <?php foreach ($topProducts as $index => $product): ?>
                    <div class="top-product-item">
                        <span class="top-product-rank"><?php echo $index + 1; ?></span>
                        <div class="top-product-img"><div class="admin-product-placeholder"><i class="bi bi-box-seam"></i></div></div>
                        <div class="top-product-info"><strong><?php echo adminEsc($product['name']); ?></strong><span><?php echo (int) $product['units_sold']; ?> sold</span></div>
                        <span class="top-product-revenue">$<?php echo number_format((float) $product['revenue'], 0); ?></span>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="admin-card">
            <div class="admin-card-header"><h2>Quick Actions</h2></div>
            <div class="quick-actions-list">
                <a href="add-product.php" class="quick-action-btn"><i class="bi bi-plus-lg"></i> Add New Product</a>
                <a href="categories.php" class="quick-action-btn"><i class="bi bi-tags"></i> Manage Categories</a>
                <a href="orders.php?status=pending" class="quick-action-btn"><i class="bi bi-hourglass-split"></i> Review Pending Orders</a>
                <a href="customers.php" class="quick-action-btn"><i class="bi bi-people"></i> Manage Customers</a>
            </div>
        </section>

        <section class="admin-card">
            <div class="admin-card-header"><h2>Low Stock Alert</h2><a href="products.php?stock=low" class="admin-link">View all</a></div>
            <?php if ($lowStock === []): ?>
                <div class="admin-empty-state"><i class="bi bi-check2-circle"></i><h2>Inventory looks good</h2><p>No active products are at five units or below.</p></div>
            <?php else: ?>
                <?php foreach ($lowStock as $item): ?>
                    <div class="low-stock-item"><div><?php echo adminEsc($item['name']); ?><br><span class="cell-muted low-stock-sku"><?php echo adminEsc($item['sku']); ?></span></div><span class="stock-count"><?php echo (int) $item['stock']; ?> left</span></div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </div>
</div>
<?php adminRenderShellEnd(); ?>