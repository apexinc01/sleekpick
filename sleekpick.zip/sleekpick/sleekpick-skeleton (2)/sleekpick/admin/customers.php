<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Customers — SLEEKPICK Admin';
$statusOptions = ['all', 'active', 'suspended'];
$status = strtolower(trim((string) ($_GET['status'] ?? 'all')));
$status = in_array($status, $statusOptions, true) ? $status : 'all';
$search = trim((string) ($_GET['search'] ?? ''));

$where = ["u.role = 'customer'"];
$params = [];
if ($status !== 'all') {
    $where[] = 'u.status = ?';
    $params[] = $status;
}
if ($search !== '') {
    $where[] = '(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR o.ship_city LIKE ?)';
    array_push($params, "%{$search}%", "%{$search}%", "%{$search}%", "%{$search}%");
}

$customers = dbFetchAll(
    "SELECT u.id, u.first_name, u.last_name, u.email, u.status, u.created_at,
            COALESCE(MAX(o.ship_city), '—') AS location,
            COUNT(DISTINCT o.id) AS order_count,
            COALESCE(SUM(CASE WHEN o.status NOT IN ('cancelled', 'refunded') THEN o.total ELSE 0 END), 0) AS total_spent
     FROM users u
     LEFT JOIN orders o ON o.user_id = u.id
     WHERE " . implode(' AND ', $where) . "
     GROUP BY u.id
     ORDER BY u.created_at DESC",
    $params
);
$activeCount = (int) (dbFetchColumn("SELECT COUNT(*) FROM users WHERE role = 'customer' AND status = 'active'") ?? 0);
$customerCount = (int) (dbFetchColumn("SELECT COUNT(*) FROM users WHERE role = 'customer'") ?? 0);
$orderCount = (int) (dbFetchColumn("SELECT COUNT(*) FROM orders") ?? 0);
$customerValue = (float) (dbFetchColumn("SELECT COALESCE(SUM(total), 0) FROM orders WHERE status NOT IN ('cancelled', 'refunded')") ?? 0);

adminRenderHead($pageTitle);
adminRenderShellStart('customers');
?>
<div class="admin-page-header">
    <div><span class="admin-eyebrow">Customer relationships</span><h1>Customers</h1><p>Real registered customers and their order value from MySQL.</p></div>
    <button type="button" class="admin-btn admin-btn-secondary" data-export-customers><i class="bi bi-download"></i> Export CSV</button>
</div>

<div class="admin-stats-row">
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-secondary"><i class="bi bi-people"></i></span></div><div class="admin-stat-value"><?php echo number_format($customerCount); ?></div><div class="admin-stat-label">Total customers</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-accent"><i class="bi bi-person-check"></i></span></div><div class="admin-stat-value"><?php echo number_format($activeCount); ?></div><div class="admin-stat-label">Active accounts</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-neutral"><i class="bi bi-bag-check"></i></span></div><div class="admin-stat-value"><?php echo number_format($orderCount); ?></div><div class="admin-stat-label">Orders placed</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-primary"><i class="bi bi-cash-stack"></i></span></div><div class="admin-stat-value">$<?php echo number_format($customerValue, 0); ?></div><div class="admin-stat-label">Store revenue</div></div>
</div>

<form class="admin-toolbar-card" method="get">
    <div class="admin-filter-search"><i class="bi bi-search"></i><input type="search" name="search" value="<?php echo adminEsc($search); ?>" placeholder="Search name, email, or location" aria-label="Search customers" data-customer-search></div>
    <select class="admin-select" name="status" aria-label="Filter customers by status" data-customer-status>
        <option value="all">All customers</option>
        <option value="active"<?php echo $status === 'active' ? ' selected' : ''; ?>>Active</option>
        <option value="suspended"<?php echo $status === 'suspended' ? ' selected' : ''; ?>>Suspended</option>
    </select>
    <button type="submit" class="admin-btn admin-btn-secondary admin-btn-small">Apply filters</button>
    <?php if ($search !== '' || $status !== 'all'): ?><a href="customers.php" class="admin-btn admin-btn-ghost admin-btn-small">Reset</a><?php endif; ?>
</form>

<div class="admin-table-card">
    <?php if ($customers === []): ?>
        <div class="admin-empty-state"><i class="bi bi-person-x"></i><h2>No customers found</h2><p>Try a different search or status filter.</p></div>
    <?php else: ?>
        <div class="admin-table-scroll">
            <table class="admin-table admin-customers-table">
                <thead><tr><th>Customer</th><th>Location</th><th>Orders</th><th>Total spent</th><th>Joined</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($customers as $customer): ?>
                    <?php $name = trim((string) $customer['first_name'] . ' ' . (string) $customer['last_name']); ?>
                    <tr data-customer-row data-status="<?php echo adminEsc($customer['status']); ?>">
                        <td><div class="customer-cell"><span class="customer-avatar"><?php echo adminEsc(strtoupper(substr($name, 0, 1))); ?></span><span><strong><?php echo adminEsc($name); ?></strong><small><?php echo adminEsc($customer['email']); ?></small></span></div></td>
                        <td class="cell-muted"><?php echo adminEsc($customer['location']); ?></td>
                        <td class="cell-strong"><?php echo (int) $customer['order_count']; ?></td>
                        <td class="cell-strong">$<?php echo number_format((float) $customer['total_spent'], 2); ?></td>
                        <td class="cell-muted"><?php echo adminEsc(date('M j, Y', strtotime((string) $customer['created_at']))); ?></td>
                        <td><?php echo adminStatusBadge((string) $customer['status']); ?></td>
                        <td><div class="admin-row-actions"><button type="button" class="customer-view-btn" aria-label="View <?php echo adminEsc($name); ?>" data-customer-view><i class="bi bi-arrow-up-right"></i></button></div></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="admin-table-footer"><span class="results-note" data-customer-results>Showing <?php echo count($customers); ?> customers</span><span class="admin-live-pill"><i class="bi bi-database-check"></i> Live data</span></div>
    <?php endif; ?>
</div>
<div class="admin-empty-state" data-customer-empty hidden><i class="bi bi-person-x"></i><h2>No customers found</h2><p>Try a different search or status filter.</p></div>
<?php adminRenderShellEnd(); ?>