<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Products / Catalog
 *
 * Live catalog list from the `products` table (joined to categories).
 * Search, category, status and stock filters run server-side with
 * bound parameters. Archive / activate uses actions/admin-product-status.php
 * via the existing admin.js fetch handler (data-product-toggle).
 */

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Products — SLEEKPICK Admin';

// ---------------------------------------------------------------
// Request input
// ---------------------------------------------------------------
$search       = trim((string) ($_GET['q'] ?? $_GET['search'] ?? ''));
$categoryId   = filter_var($_GET['category'] ?? null, FILTER_VALIDATE_INT) ?: 0;
$statusFilter = strtolower(trim((string) ($_GET['status'] ?? 'all')));
$stockFilter  = strtolower(trim((string) ($_GET['stock'] ?? 'all')));
$sortKey      = strtolower(trim((string) ($_GET['sort'] ?? 'newest')));
$page         = max(1, (int) ($_GET['page'] ?? 1));

if (mb_strlen($search) > 80) {
    $search = mb_substr($search, 0, 80);
}
if (!in_array($statusFilter, ['all', 'active', 'archived'], true)) {
    $statusFilter = 'all';
}
if (!in_array($stockFilter, ['all', 'low', 'out'], true)) {
    $stockFilter = 'all';
}

$sortOptions = [
    'newest'     => ['label' => 'Newest first',     'sql' => 'p.created_at DESC, p.id DESC'],
    'oldest'     => ['label' => 'Oldest first',     'sql' => 'p.created_at ASC, p.id ASC'],
    'name'       => ['label' => 'Name (A–Z)',       'sql' => 'p.name ASC'],
    'price_desc' => ['label' => 'Price (high–low)', 'sql' => 'p.price DESC'],
    'price_asc'  => ['label' => 'Price (low–high)', 'sql' => 'p.price ASC'],
    'stock_asc'  => ['label' => 'Stock (low–high)', 'sql' => 'p.stock ASC'],
];
if (!array_key_exists($sortKey, $sortOptions)) {
    $sortKey = 'newest';
}

$lowStockThreshold = 5;
$perPage = 12;

// ---------------------------------------------------------------
// Categories (for filter dropdown)
// ---------------------------------------------------------------
$categories = dbFetchAll('SELECT id, name FROM categories ORDER BY sort_order, name');
$categoryIds = array_map(static fn(array $row): int => (int) $row['id'], $categories);
if ($categoryId > 0 && !in_array($categoryId, $categoryIds, true)) {
    $categoryId = 0;
}

// ---------------------------------------------------------------
// Filtered query
// ---------------------------------------------------------------
$where  = [];
$params = [];

if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.sku LIKE ? OR p.short_description LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if ($categoryId > 0) {
    $where[] = 'p.category_id = ?';
    $params[] = $categoryId;
}
if ($statusFilter === 'active') {
    $where[] = 'p.is_active = 1';
} elseif ($statusFilter === 'archived') {
    $where[] = 'p.is_active = 0';
}
if ($stockFilter === 'low') {
    $where[] = 'p.stock > 0 AND p.stock <= ?';
    $params[] = $lowStockThreshold;
} elseif ($stockFilter === 'out') {
    $where[] = 'p.stock <= 0';
}

$whereSql = $where === [] ? '' : ' WHERE ' . implode(' AND ', $where);

$totalProducts = (int) dbFetchColumn('SELECT COUNT(*) FROM products p' . $whereSql, $params);
$totalPages    = max(1, (int) ceil($totalProducts / $perPage));
$page          = min($page, $totalPages);
$offset        = ($page - 1) * $perPage;

$products = dbFetchAll(
    'SELECT p.id, p.name, p.slug, p.sku, p.price, p.compare_price, p.stock, p.image,
            p.badge, p.is_active, p.is_featured, p.created_at, p.updated_at,
            c.name AS category_name,
            (SELECT COUNT(*) FROM product_variants v WHERE v.product_id = p.id) AS variant_count,
            (SELECT GROUP_CONCAT(DISTINCT v.size ORDER BY v.size SEPARATOR ", ")
               FROM product_variants v WHERE v.product_id = p.id) AS variant_sizes,
            (SELECT GROUP_CONCAT(DISTINCT v.color ORDER BY v.color SEPARATOR ", ")
               FROM product_variants v WHERE v.product_id = p.id) AS variant_colors
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id'
    . $whereSql
    . ' ORDER BY ' . $sortOptions[$sortKey]['sql']
    . ' LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset,
    $params
);

// Catalog-wide stats (not affected by current filters)
$catalogTotal   = (int) dbFetchColumn('SELECT COUNT(*) FROM products');
$catalogActive  = (int) dbFetchColumn('SELECT COUNT(*) FROM products WHERE is_active = 1');
$catalogLow     = (int) dbFetchColumn('SELECT COUNT(*) FROM products WHERE stock > 0 AND stock <= ?', [$lowStockThreshold]);
$catalogOut     = (int) dbFetchColumn('SELECT COUNT(*) FROM products WHERE stock <= 0');
$inventoryValue = (float) dbFetchColumn('SELECT COALESCE(SUM(price * stock), 0) FROM products WHERE is_active = 1');

$hasFilters = $search !== '' || $categoryId > 0 || $statusFilter !== 'all' || $stockFilter !== 'all' || $sortKey !== 'newest';

/** Keep current filters when building pagination / sort links. */
function productsPageUrl(array $overrides = []): string
{
    $query = array_merge([
        'q'        => (string) ($_GET['q'] ?? $_GET['search'] ?? ''),
        'category' => (string) ($_GET['category'] ?? ''),
        'status'   => (string) ($_GET['status'] ?? ''),
        'stock'    => (string) ($_GET['stock'] ?? ''),
        'sort'     => (string) ($_GET['sort'] ?? ''),
        'page'     => (string) ($_GET['page'] ?? ''),
    ], $overrides);

    $query = array_filter($query, static fn($value): bool => (string) $value !== '' && (string) $value !== 'all' && (string) $value !== 'newest');

    return 'products.php' . ($query === [] ? '' : '?' . http_build_query($query));
}

adminRenderHead($pageTitle);
adminRenderShellStart('products');
?>

<div class="admin-page-header">
    <div>
        <span class="admin-eyebrow">Catalog</span>
        <h1>Products</h1>
        <p>Manage the live SLEEKPICK catalog — every row is read from the database.</p>
    </div>
    <a href="add-product.php" class="admin-btn admin-btn-primary">
        <i class="bi bi-plus-lg" aria-hidden="true"></i> Add Product
    </a>
</div>

<div class="admin-stats-row">
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-secondary"><i class="bi bi-box-seam"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($catalogTotal); ?></div>
        <div class="admin-stat-label">Products in catalog</div>
    </div>
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-accent"><i class="bi bi-broadcast"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($catalogActive); ?></div>
        <div class="admin-stat-label">Published</div>
    </div>
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-primary"><i class="bi bi-exclamation-triangle"></i></span></div>
        <div class="admin-stat-value"><?php echo number_format($catalogLow + $catalogOut); ?></div>
        <div class="admin-stat-label">Low or out of stock</div>
    </div>
    <div class="admin-stat-card">
        <div class="admin-stat-card-top"><span class="admin-stat-icon tone-neutral"><i class="bi bi-cash-stack"></i></span></div>
        <div class="admin-stat-value">$<?php echo number_format($inventoryValue, 2); ?></div>
        <div class="admin-stat-label">Published stock value</div>
    </div>
</div>

<form class="admin-toolbar-card" method="get" action="products.php">
    <div class="admin-filter-search">
        <i class="bi bi-search" aria-hidden="true"></i>
        <label class="sr-only" for="product-search">Search products</label>
        <input type="search" id="product-search" name="q" value="<?php echo adminEsc($search); ?>"
               placeholder="Search name, SKU, or description" data-product-search>
    </div>

    <label class="sr-only" for="product-category-filter">Filter by category</label>
    <select class="admin-select" id="product-category-filter" name="category">
        <option value="">All categories</option>
        <?php foreach ($categories as $category): ?>
            <option value="<?php echo (int) $category['id']; ?>"<?php echo $categoryId === (int) $category['id'] ? ' selected' : ''; ?>>
                <?php echo adminEsc($category['name']); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label class="sr-only" for="product-status-filter">Filter by status</label>
    <select class="admin-select" id="product-status-filter" name="status">
        <option value="all">All statuses</option>
        <option value="active"<?php echo $statusFilter === 'active' ? ' selected' : ''; ?>>Published</option>
        <option value="archived"<?php echo $statusFilter === 'archived' ? ' selected' : ''; ?>>Archived</option>
    </select>

    <label class="sr-only" for="product-stock-filter">Filter by stock</label>
    <select class="admin-select" id="product-stock-filter" name="stock">
        <option value="all">Any stock level</option>
        <option value="low"<?php echo $stockFilter === 'low' ? ' selected' : ''; ?>>Low stock (1–<?php echo $lowStockThreshold; ?>)</option>
        <option value="out"<?php echo $stockFilter === 'out' ? ' selected' : ''; ?>>Out of stock</option>
    </select>

    <label class="sr-only" for="product-sort">Sort products</label>
    <select class="admin-select" id="product-sort" name="sort">
        <?php foreach ($sortOptions as $key => $option): ?>
            <option value="<?php echo adminEsc($key); ?>"<?php echo $sortKey === $key ? ' selected' : ''; ?>>
                <?php echo adminEsc($option['label']); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit" class="admin-btn admin-btn-secondary admin-btn-small">
        <i class="bi bi-funnel"></i> Apply
    </button>
    <?php if ($hasFilters): ?>
        <a href="products.php" class="admin-btn admin-btn-ghost admin-btn-small">
            <i class="bi bi-x-lg"></i> Clear
        </a>
    <?php endif; ?>
</form>

<div class="admin-table-card">
    <?php if ($products === []): ?>
        <div class="admin-empty-state">
            <i class="bi bi-box-seam" aria-hidden="true"></i>
            <?php if ($catalogTotal === 0): ?>
                <h2>No products yet</h2>
                <p>Your catalog is empty. Add the first SLEEKPICK product to get the storefront live.</p>
                <p><a href="add-product.php" class="admin-btn admin-btn-primary"><i class="bi bi-plus-lg"></i> Add Product</a></p>
            <?php else: ?>
                <h2>No products match those filters</h2>
                <p>Try a different search term, category, status, or stock level.</p>
                <p><a href="products.php" class="admin-btn admin-btn-secondary"><i class="bi bi-arrow-counterclockwise"></i> Reset filters</a></p>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="admin-table-scroll">
            <table class="admin-table admin-products-table">
                <thead>
                    <tr>
                        <th scope="col">Product</th>
                        <th scope="col">Category</th>
                        <th scope="col">Price</th>
                        <th scope="col">Stock</th>
                        <th scope="col">Variants</th>
                        <th scope="col">Status</th>
                        <th scope="col">Updated</th>
                        <th scope="col"><span class="sr-only">Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $product):
                    $productId    = (int) $product['id'];
                    $stock        = (int) $product['stock'];
                    $variantCount = (int) $product['variant_count'];
                    $isActive     = (int) $product['is_active'] === 1;
                    $statusLabel  = $isActive ? 'active' : 'archived';
                    $stockClass   = $stock <= 0 ? 'out-of-stock' : ($stock <= $lowStockThreshold ? 'low-stock' : 'in-stock');
                    $nextState    = $isActive ? 0 : 1;
                    $toggleLabel  = $isActive ? 'Archive' : 'Activate';
                    $toggleIcon   = $isActive ? 'bi-archive' : 'bi-arrow-counterclockwise';
                    $imageUrl     = productImageUrl($product['image'] ?? null, (string) $product['name']);
                    $updatedAt    = $product['updated_at'] ?? $product['created_at'] ?? null;
                    $updatedLabel = $updatedAt ? date('M j, Y', strtotime((string) $updatedAt)) : '—';
                    ?>
                    <tr data-product-id="<?php echo $productId; ?>" data-status="<?php echo adminEsc($statusLabel); ?>">
                        <td>
                            <div class="product-cell">
                                <span class="product-thumb">
                                    <img src="<?php echo adminEsc($imageUrl); ?>" alt="" loading="lazy">
                                </span>
                                <span class="product-cell-info">
                                    <strong><?php echo adminEsc($product['name']); ?></strong>
                                    <span>
                                        SKU <?php echo adminEsc($product['sku']); ?>
                                        <?php if ((int) $product['is_featured'] === 1): ?> · Featured<?php endif; ?>
                                    </span>
                                </span>
                            </div>
                        </td>
                        <td class="cell-muted"><?php echo adminEsc($product['category_name'] ?? 'Uncategorised'); ?></td>
                        <td class="cell-strong">
                            $<?php echo number_format((float) $product['price'], 2); ?>
                            <?php if ($product['compare_price'] !== null && (float) $product['compare_price'] > 0): ?>
                                <small class="cell-muted"> was $<?php echo number_format((float) $product['compare_price'], 2); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="stock-indicator <?php echo $stockClass; ?>">
                                <?php echo $stock; ?><?php
                                    echo $stock <= 0 ? ' — out' : ($stock <= $lowStockThreshold ? ' — low' : '');
                                ?>
                            </span>
                        </td>
                        <td class="cell-muted">
                            <?php if ($variantCount === 0): ?>
                                No variants
                            <?php else: ?>
                                <?php echo $variantCount; ?> combo<?php echo $variantCount === 1 ? '' : 's'; ?>
                                <?php if (!empty($product['variant_sizes']) || !empty($product['variant_colors'])): ?>
                                    <small>
                                        <?php echo adminEsc((string) ($product['variant_sizes'] ?? '')); ?>
                                        <?php if (!empty($product['variant_colors'])): ?>
                                            <?php echo !empty($product['variant_sizes']) ? ' · ' : ''; ?>
                                            <?php echo adminEsc((string) $product['variant_colors']); ?>
                                        <?php endif; ?>
                                    </small>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo adminStatusBadge($statusLabel); ?></td>
                        <td class="cell-muted"><?php echo adminEsc($updatedLabel); ?></td>
                        <td>
                            <div class="admin-row-actions">
                                <a href="../public/product.php?slug=<?php echo urlencode((string) $product['slug']); ?>"
                                   target="_blank" rel="noopener"
                                   aria-label="View <?php echo adminEsc($product['name']); ?> on the storefront">
                                    <i class="bi bi-box-arrow-up-right"></i>
                                </a>
                                <a href="edit-product.php?id=<?php echo $productId; ?>"
                                   aria-label="Edit <?php echo adminEsc($product['name']); ?>">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button type="button"
                                        data-product-toggle="<?php echo $productId; ?>"
                                        data-next-state="<?php echo $nextState; ?>"
                                        aria-label="<?php echo adminEsc($toggleLabel . ' ' . $product['name']); ?>">
                                    <i class="bi <?php echo $toggleIcon; ?>"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-table-footer">
            <span class="results-note">
                Showing <?php echo count($products); ?> of <?php echo number_format($totalProducts); ?> product<?php echo $totalProducts === 1 ? '' : 's'; ?>
                <?php echo $hasFilters ? ' (filtered)' : ''; ?>
            </span>
            <span class="admin-live-pill"><i class="bi bi-database-check"></i> Live data</span>
            <?php if ($totalPages > 1): ?>
                <nav class="admin-pagination" aria-label="Products pagination">
                    <?php if ($page > 1): ?>
                        <a href="<?php echo adminEsc(productsPageUrl(['page' => $page - 1])); ?>" aria-label="Previous page">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    <?php endif; ?>
                    <?php for ($number = 1; $number <= $totalPages; $number++): ?>
                        <?php if ($number === $page): ?>
                            <span class="current"><?php echo $number; ?></span>
                        <?php else: ?>
                            <a href="<?php echo adminEsc(productsPageUrl(['page' => $number])); ?>"><?php echo $number; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                        <a href="<?php echo adminEsc(productsPageUrl(['page' => $page + 1])); ?>" aria-label="Next page">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php
adminRenderShellEnd();