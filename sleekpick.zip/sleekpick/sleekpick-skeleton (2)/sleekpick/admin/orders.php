<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin-layout.php';

$pageTitle = 'Orders — SLEEKPICK Admin';
$statusOptions = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];
$status = strtolower(trim((string) ($_GET['status'] ?? 'all')));
$status = in_array($status, $statusOptions, true) ? $status : 'all';
$search = trim((string) ($_GET['search'] ?? ''));

$where = [];
$params = [];
if ($status !== 'all') {
    $where[] = 'o.status = ?';
    $params[] = $status;
}
if ($search !== '') {
    $where[] = '(o.order_number LIKE ? OR o.email LIKE ? OR o.ship_full_name LIKE ? OR CONCAT(u.first_name, " ", u.last_name) LIKE ?)';
    array_push($params, "%{$search}%", "%{$search}%", "%{$search}%", "%{$search}%");
}
$whereSql = $where === [] ? '' : 'WHERE ' . implode(' AND ', $where);

$orders = dbFetchAll(
    "SELECT o.id, o.order_number, o.email, o.ship_full_name, o.placed_at, o.total, o.status,
            COALESCE(CONCAT(u.first_name, ' ', u.last_name), o.ship_full_name, o.email) AS customer,
            COUNT(oi.id) AS item_count
     FROM orders o
     LEFT JOIN users u ON u.id = o.user_id
     LEFT JOIN order_items oi ON oi.order_id = o.id
     {$whereSql}
     GROUP BY o.id
     ORDER BY o.placed_at DESC",
    $params
);
$counts = [];
foreach (dbFetchAll('SELECT status, COUNT(*) AS total FROM orders GROUP BY status') as $row) {
    $counts[(string) $row['status']] = (int) $row['total'];
}
$totalRevenue = (float) (dbFetchColumn("SELECT COALESCE(SUM(total), 0) FROM orders WHERE status NOT IN ('cancelled', 'refunded')") ?? 0);

adminRenderHead($pageTitle);
adminRenderShellStart('orders');
?>
<div class="admin-page-header">
    <div><span class="admin-eyebrow">Fulfilment control</span><h1>Orders</h1><p>Track and manage every order placed on SLEEKPICK.</p></div>
    <button type="button" class="admin-btn admin-btn-primary" data-export-orders><i class="bi bi-download"></i> Export CSV</button>
</div>

<div class="admin-stats-row">
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-neutral"><i class="bi bi-hourglass-split"></i></span></div><div class="admin-stat-value"><?php echo $counts['pending'] ?? 0; ?></div><div class="admin-stat-label">Pending</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-secondary"><i class="bi bi-arrow-repeat"></i></span></div><div class="admin-stat-value"><?php echo $counts['processing'] ?? 0; ?></div><div class="admin-stat-label">Processing</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-accent"><i class="bi bi-truck"></i></span></div><div class="admin-stat-value"><?php echo ($counts['shipped'] ?? 0) + ($counts['delivered'] ?? 0); ?></div><div class="admin-stat-label">Shipped / Delivered</div></div>
    <div class="admin-stat-card"><div class="admin-stat-card-top"><span class="admin-stat-icon tone-primary"><i class="bi bi-cash-stack"></i></span></div><div class="admin-stat-value">$<?php echo number_format($totalRevenue, 2); ?></div><div class="admin-stat-label">Revenue</div></div>
</div>

<form class="admin-toolbar-card" method="get">
    <div class="admin-filter-search"><i class="bi bi-search"></i><input type="search" name="search" value="<?php echo adminEsc($search); ?>" placeholder="Search order, customer, or email" data-order-search></div>
    <select class="admin-select admin-filter-status" name="status" aria-label="Filter orders by status" data-order-status>
             <option value="all">All statuses</option>
        <?php foreach ($statusOptions as $option): ?><option value="<?php echo adminEsc($option); ?>"<?php echo $status === $option ? ' selected' : ''; ?>><?php echo adminEsc(ucfirst($option)); ?></option><?php endforeach; ?>
    </select>
    <button type="submit" class="admin-btn admin-btn-secondary admin-btn-small">Apply filters</button>
    <?php if ($search !== '' || $status !== 'all'): ?><a href="orders.php" class="admin-btn admin-btn-ghost admin-btn-small">Reset</a><?php endif; ?>
</form>

<div class="admin-table-card">
    <?php if ($orders === []): ?>
        <div class="admin-empty-state"><i class="bi bi-bag-x"></i><h2>No orders found</h2><p>Try a different search or status filter.</p></div>
    <?php else: ?>
        <div class="admin-table-scroll">
            <table class="admin-table admin-orders-table">
                <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th>Update</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr data-order-id="<?php echo adminEsc($order['id']); ?>" data-status="<?php echo adminEsc($order['status']); ?>">
                        <td class="cell-strong">#<?php echo adminEsc($order['order_number']); ?></td>
                        <td><div class="customer-cell"><span class="customer-avatar"><?php echo adminEsc(strtoupper(substr((string) $order['customer'], 0, 1))); ?></span><span><strong><?php echo adminEsc($order['customer']); ?></strong><small><?php echo adminEsc($order['email']); ?></small></span></div></td>
                        <td class="cell-muted"><?php echo adminEsc(date('M j, Y', strtotime((string) $order['placed_at']))); ?></td>
                        <td class="cell-muted"><?php echo (int) $order['item_count']; ?></td>
                        <td class="cell-strong">$<?php echo number_format((float) $order['total'], 2); ?></td>
                        <td><?php echo adminStatusBadge((string) $order['status']); ?></td>
                        <td><select class="status-update-select" data-order-status-update="<?php echo adminEsc($order['id']); ?>" aria-label="Update status for <?php echo adminEsc($order['order_number']); ?>"><?php foreach ($statusOptions as $option): ?><option value="<?php echo adminEsc($option); ?>"<?php echo $option === $order['status'] ? ' selected' : ''; ?>><?php echo adminEsc(ucfirst($option)); ?></option><?php endforeach; ?></select></td>
                        <td><div class="admin-row-actions"><a href="order.php?id=<?php echo (int) $order['id']; ?>" aria-label="View order <?php echo adminEsc($order['order_number']); ?>"><i class="bi bi-arrow-up-right"></i></a></div></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="admin-table-footer"><span class="results-note">Showing <?php echo count($orders); ?> database orders</span><span class="admin-live-pill"><i class="bi bi-database-check"></i> Live data</span></div>
    <?php endif; ?>
</div>
<?php adminRenderShellEnd(); ?>