<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Login Page
 *
 * The only admin page that does NOT include includes/admin-layout.php
 * (that file requires a signed-in admin). It bootstraps the session,
 * helpers and auth itself, then posts the credentials to
 * actions/login.php with context=admin, so only users whose role is
 * an admin role can ever get through.
 *
 * Real credential checking, throttling, CSRF and session regeneration
 * all live in includes/auth.php + actions/login.php — this page is
 * presentation plus the CSRF token.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

// Already signed in as staff? Skip the form.
if (isAdmin()) {
    header('Location: dashboard.php');
    exit;
}

$pageTitle = 'Admin Login — SLEEKPICK';

// Flash messages set by actions/login.php on a failed attempt.
$flashes = takeFlashes();

// ?error=unauthorized is added by requireAdmin() when a guest (or a
// customer account) tries to open an admin page directly.
$guardError = ($_GET['error'] ?? '') === 'unauthorized'
    ? 'Sign in with a staff account to open the admin area.'
    : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?php echo htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8'); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

    <div class="admin-login-page">
        <div class="admin-glow-secondary"></div>

        <div class="admin-login-card corner-brackets">
            <span></span><span></span><span></span><span></span>

            <div class="admin-logo">SLEEKPICK</div>
            <p class="admin-login-tag">Admin Panel</p>

            <?php foreach ($flashes as $flash): ?>
                <div class="admin-flash admin-flash-<?php echo $flash['type'] === 'error' ? 'error' : 'success'; ?>">
                    <i class="bi <?php echo $flash['type'] === 'error' ? 'bi-exclamation-triangle' : 'bi-check-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars((string) $flash['message'], ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
            <?php endforeach; ?>

            <?php if ($guardError !== ''): ?>
                <div class="admin-flash admin-flash-error">
                    <i class="bi bi-shield-exclamation"></i>
                    <span><?php echo htmlspecialchars($guardError, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
            <?php endif; ?>

            <form class="admin-login-form" method="post" action="../actions/login.php" novalidate>
                <?php echo csrfField(); ?>
                <input type="hidden" name="context" value="admin">

                <div class="admin-form-group">
                    <label for="admin-email">Email Address</label>
                    <div class="admin-input-wrap">
                        <i class="bi bi-envelope leading-icon"></i>
                        <input type="email" id="admin-email" name="email" class="admin-input" placeholder="you@sleekpick.com" autocomplete="username" required>
                    </div>
                    <p class="admin-field-error"></p>
                </div>

                <div class="admin-form-group">
                    <label for="admin-password">Password</label>
                    <div class="admin-input-wrap">
                        <i class="bi bi-lock leading-icon"></i>
                        <input type="password" id="admin-password" name="password" class="admin-input" placeholder="••••••••" autocomplete="current-password" required style="padding-right: 2.6rem;">
                        <button type="button" class="admin-password-toggle" aria-label="Show password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                    <p class="admin-field-error"></p>
                </div>

                <div class="admin-form-options">
                    <label class="admin-checkbox-group">
                        <input type="checkbox" id="admin-remember" name="remember" value="1">
                        Remember me
                    </label>
                    <a href="#" class="admin-forgot-link">Forgot Password?</a>
                </div>

                <button type="submit" class="admin-btn admin-btn-primary admin-login-submit">
                    <i class="bi bi-box-arrow-in-right"></i> Sign In
                </button>
                <p class="admin-login-message" aria-live="polite"></p>
            </form>

            <p class="admin-security-note">
                <i class="bi bi-shield-lock"></i> Restricted access — staff only
            </p>

            <a href="../public/index.php" class="admin-back-to-store">
                <i class="bi bi-arrow-left"></i> Back to Store
            </a>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>