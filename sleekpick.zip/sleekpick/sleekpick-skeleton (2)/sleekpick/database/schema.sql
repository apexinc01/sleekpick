-- ============================================================
-- SLEEKPICK — Database Schema (MySQL 8 / MariaDB 10.4+, XAMPP)
--
-- Run once:  mysql -u root -p < database/schema.sql
-- Then seed: mysql -u root -p sleekpick < database/seed.sql
--
-- Conventions:
--  * InnoDB + utf8mb4 everywhere (emoji-safe, real foreign keys)
--  * Money stored as DECIMAL(10,2) — never FLOAT
--  * Slugs are unique and used in public URLs
--  * Deleting a product keeps historical order lines intact
--    (order_items stores a snapshot of name/price at purchase time)
-- ============================================================

CREATE DATABASE IF NOT EXISTS `sleekpick`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `sleekpick`;

-- ---------- Users ----------
-- Both customers and staff live here; `role` gates admin access.
CREATE TABLE IF NOT EXISTS `users` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `first_name`    VARCHAR(60)  NOT NULL,
    `last_name`     VARCHAR(60)  NOT NULL,
    `email`         VARCHAR(190) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `phone`         VARCHAR(30)      NULL,
    `role`          ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    `status`        ENUM('active','suspended') NOT NULL DEFAULT 'active',
    `last_login_at` DATETIME         NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_email` (`email`),
    KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Addresses ----------
CREATE TABLE IF NOT EXISTS `addresses` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`       INT UNSIGNED NOT NULL,
    `label`         VARCHAR(40)  NOT NULL DEFAULT 'Home',
    `full_name`     VARCHAR(120) NOT NULL,
    `line1`         VARCHAR(160) NOT NULL,
    `line2`         VARCHAR(160)     NULL,
    `city`          VARCHAR(80)  NOT NULL,
    `state`         VARCHAR(80)      NULL,
    `postal_code`   VARCHAR(20)      NULL,
    `country`       VARCHAR(80)  NOT NULL DEFAULT 'Nigeria',
    `phone`         VARCHAR(30)      NULL,
    `is_default`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_addresses_user` (`user_id`),
    CONSTRAINT `fk_addresses_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Categories ----------
-- `slug` matches the existing shop.php?category=<slug> links.
CREATE TABLE IF NOT EXISTS `categories` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name`        VARCHAR(80)  NOT NULL,
    `slug`        VARCHAR(80)  NOT NULL,
    `description` VARCHAR(255)     NULL,
    `image`       VARCHAR(255)     NULL,
    `sort_order`  SMALLINT     NOT NULL DEFAULT 0,
    `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_categories_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Products ----------
-- `price` is the authoritative price: actions/add-to-cart.php must read
-- it from here rather than trusting the client-supplied value.
CREATE TABLE IF NOT EXISTS `products` (
    `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `category_id`    INT UNSIGNED     NULL,
    `sku`            VARCHAR(40)  NOT NULL,
    `name`           VARCHAR(150) NOT NULL,
    `slug`           VARCHAR(180) NOT NULL,
    `short_description` VARCHAR(255)  NULL,
    `description`    TEXT             NULL,
    `price`          DECIMAL(10,2) NOT NULL,
    `compare_price`  DECIMAL(10,2)    NULL,  -- original price when on sale
    `stock`          INT          NOT NULL DEFAULT 0,
    `image`          VARCHAR(255)     NULL,  -- primary image (uploads/products/...)
    `badge`          VARCHAR(20)      NULL,  -- e.g. 'Sale', 'New'
    `is_featured`    TINYINT(1)   NOT NULL DEFAULT 0,
    `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_products_sku` (`sku`),
    UNIQUE KEY `uq_products_slug` (`slug`),
    KEY `idx_products_category` (`category_id`),
    KEY `idx_products_active_featured` (`is_active`, `is_featured`),
    CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`)
        REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Product images (gallery beyond the primary image) ----------
CREATE TABLE IF NOT EXISTS `product_images` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `product_id` INT UNSIGNED NOT NULL,
    `path`       VARCHAR(255) NOT NULL,
    `alt`        VARCHAR(160)     NULL,
    `sort_order` SMALLINT     NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `idx_product_images_product` (`product_id`),
    CONSTRAINT `fk_product_images_product` FOREIGN KEY (`product_id`)
        REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Product variants ----------
-- The session cart already keys lines by productId:size:color
-- (includes/functions.php::cartItemKey) — this table is its DB counterpart.
CREATE TABLE IF NOT EXISTS `product_variants` (
    `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `product_id`     INT UNSIGNED NOT NULL,
    `size`           VARCHAR(30)  NOT NULL,
    `color`          VARCHAR(30)  NOT NULL,
    `sku_suffix`     VARCHAR(20)      NULL,
    `price_override` DECIMAL(10,2)    NULL,
    `stock`          INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_variant_combo` (`product_id`, `size`, `color`),
    CONSTRAINT `fk_variants_product` FOREIGN KEY (`product_id`)
        REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Persistent cart (logged-in users) ----------
-- Guests keep using $_SESSION['cart']; on login the session cart is
-- merged into this table so it survives across devices.
CREATE TABLE IF NOT EXISTS `cart_items` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`    INT UNSIGNED NOT NULL,
    `product_id` INT UNSIGNED NOT NULL,
    `variant_id` INT UNSIGNED     NULL,
    `size`       VARCHAR(30)  NOT NULL,
    `color`      VARCHAR(30)  NOT NULL,
    `quantity`   SMALLINT     NOT NULL DEFAULT 1,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_cart_line` (`user_id`, `product_id`, `size`, `color`),
    KEY `idx_cart_user` (`user_id`),
    CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`)
        REFERENCES `products` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cart_variant` FOREIGN KEY (`variant_id`)
        REFERENCES `product_variants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Orders ----------
-- Shipping details are copied in (not joined) so an address edit or
-- account deletion never rewrites order history.
CREATE TABLE IF NOT EXISTS `orders` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_number`     VARCHAR(24)  NOT NULL,
    `user_id`          INT UNSIGNED     NULL,  -- NULL = guest checkout
    `email`            VARCHAR(190) NOT NULL,
    `status`           ENUM('pending','processing','shipped','delivered','cancelled','refunded')
                       NOT NULL DEFAULT 'pending',
    `payment_status`   ENUM('unpaid','paid','refunded') NOT NULL DEFAULT 'unpaid',
    `payment_method`   VARCHAR(40)  NOT NULL DEFAULT 'card',
    `subtotal`         DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `shipping_fee`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `tax`              DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `discount`         DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total`            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `ship_full_name`   VARCHAR(120) NOT NULL,
    `ship_line1`       VARCHAR(160) NOT NULL,
    `ship_line2`       VARCHAR(160)     NULL,
    `ship_city`        VARCHAR(80)  NOT NULL,
    `ship_state`       VARCHAR(80)      NULL,
    `ship_postal_code` VARCHAR(20)      NULL,
    `ship_country`     VARCHAR(80)  NOT NULL DEFAULT 'Nigeria',
    `ship_phone`       VARCHAR(30)      NULL,
    `notes`            VARCHAR(500)     NULL,
    `placed_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_orders_number` (`order_number`),
    KEY `idx_orders_user` (`user_id`),
    KEY `idx_orders_status` (`status`),
    CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Order items ----------
CREATE TABLE IF NOT EXISTS `order_items` (
    `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id`     INT UNSIGNED NOT NULL,
    `product_id`   INT UNSIGNED     NULL,  -- kept for reporting; may be deleted later
    `product_name` VARCHAR(150) NOT NULL,  -- snapshot
    `sku`          VARCHAR(40)      NULL,  -- snapshot
    `image`        VARCHAR(255)     NULL,  -- snapshot
    `size`         VARCHAR(30)  NOT NULL,
    `color`        VARCHAR(30)  NOT NULL,
    `unit_price`   DECIMAL(10,2) NOT NULL, -- snapshot
    `quantity`     SMALLINT     NOT NULL DEFAULT 1,
    `line_total`   DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_order_items_order` (`order_id`),
    CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`)
        REFERENCES `orders` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`)
        REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Login attempts (brute-force throttling) ----------
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email`       VARCHAR(190) NOT NULL,
    `ip_address`  VARCHAR(45)  NOT NULL,
    `successful`  TINYINT(1)   NOT NULL DEFAULT 0,
    `attempted_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_attempts_email_time` (`email`, `attempted_at`),
    KEY `idx_attempts_ip_time` (`ip_address`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Newsletter subscribers ----------
CREATE TABLE IF NOT EXISTS `newsletter_subscribers` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email`         VARCHAR(190) NOT NULL,
    `subscribed_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_newsletter_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Store settings (key/value, used by admin/settings.php) ----------
CREATE TABLE IF NOT EXISTS `settings` (
    `setting_key`   VARCHAR(60)  NOT NULL,
    `setting_value` TEXT             NULL,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
