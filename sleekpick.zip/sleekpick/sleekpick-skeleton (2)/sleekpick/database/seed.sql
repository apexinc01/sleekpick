-- ============================================================
-- SLEEKPICK — Seed Data
--
-- Run AFTER database/schema.sql:
--   mysql -u root -p sleekpick < database/seed.sql
--
-- The catalogue below is exactly the 12-product prototype set that
-- public/shop.php currently hard-codes, so the site looks identical
-- once the pages are switched over to database queries.
--
-- Passwords: all seeded accounts use the password  Sleekpick#2026
-- (bcrypt hash below). CHANGE THE ADMIN PASSWORD before deploying.
-- ============================================================

USE `sleekpick`;

-- ---------- Users ----------
INSERT INTO `users` (`first_name`, `last_name`, `email`, `password_hash`, `role`, `phone`) VALUES
('Amara', 'Okoye',  'amara.okoye@sleekpick.com', '$2y$12$xM0Zwl1lPPKvC4c/BUCkAeCEXcSZjfvqzWKn5xLoJH1cA6uh0aQAe', 'admin',    '+234 800 000 0001'),
('Tunde', 'Bello',  'tunde.bello@example.com',   '$2y$12$xM0Zwl1lPPKvC4c/BUCkAeCEXcSZjfvqzWKn5xLoJH1cA6uh0aQAe', 'customer', '+234 800 000 0002'),
('Zainab','Ibrahim','zainab.ibrahim@example.com','$2y$12$xM0Zwl1lPPKvC4c/BUCkAeCEXcSZjfvqzWKn5xLoJH1cA6uh0aQAe', 'customer', '+234 800 000 0003')
ON DUPLICATE KEY UPDATE `email` = VALUES(`email`);

-- ---------- Categories (slugs match existing shop.php?category= links) ----------
INSERT INTO `categories` (`name`, `slug`, `description`, `sort_order`) VALUES
('Outerwear',   'outerwear',   'Shells, coats and layers engineered for the street.', 1),
('Essentials',  'essentials',  'Everyday tees, hoodies and knitwear.',                2),
('Bottoms',     'bottoms',     'Cargos, joggers and denim with a technical edge.',    3),
('Accessories', 'accessories', 'Caps, eyewear and carry.',                            4)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- ---------- Products ----------
INSERT INTO `products`
(`category_id`, `sku`, `name`, `slug`, `short_description`, `description`, `price`, `compare_price`, `stock`, `badge`, `is_featured`) VALUES
((SELECT id FROM categories WHERE slug='outerwear'),   'SP-CHR-JKT', 'Chrome Jacket',         'chrome-jacket',          'Reflective technical shell.',      'A weather-sealed shell with taped seams and a reflective chrome finish that catches every light source.', 128.00, 160.00, 24, 'Sale', 1),
((SELECT id FROM categories WHERE slug='outerwear'),   'SP-DRF-TRC', 'Drift Trench Coat',     'drift-trench-coat',      'Long-line technical trench.',      'Long-line trench cut from water-repellent twill with a storm flap and concealed placket.',                185.00, NULL,   12, NULL,   1),
((SELECT id FROM categories WHERE slug='outerwear'),   'SP-HAL-VST', 'Halo Puffer Vest',      'halo-puffer-vest',       'Lightweight insulated vest.',      'Recycled-fill puffer vest with a high collar and matte ripstop face fabric.',                              112.00, NULL,   18, NULL,   0),
((SELECT id FROM categories WHERE slug='essentials'),  'SP-VLT-TEE', 'Voltage Tee',           'voltage-tee',            'Heavyweight graphic tee.',         'Heavyweight combed cotton tee with a tonal SLEEKPICK circuit graphic.',                                     42.00, NULL,   60, NULL,   1),
((SELECT id FROM categories WHERE slug='essentials'),  'SP-ECH-TRT', 'Echo Turtleneck',       'echo-turtleneck',        'Fine-gauge stretch turtleneck.',   'Fine-gauge stretch knit turtleneck that layers flat under any shell.',                                      68.00, NULL,   30, NULL,   0),
((SELECT id FROM categories WHERE slug='essentials'),  'SP-PLS-HOD', 'Pulse Hoodie',          'pulse-hoodie',           'Boxy brushed-fleece hoodie.',      'Boxy brushed-fleece hoodie with a double-layer hood and rubberised chest mark.',                            74.00, NULL,   45, 'New',  1),
((SELECT id FROM categories WHERE slug='bottoms'),     'SP-NVA-CRG', 'Nova Cargo Pants',      'nova-cargo-pants',       'Utility cargo with tech pockets.', 'Utility cargo in a stretch ripstop with bellows pockets and adjustable hems.',                              96.00, NULL,   28, NULL,   1),
((SELECT id FROM categories WHERE slug='bottoms'),     'SP-FLX-JOG', 'Flux Joggers',          'flux-joggers',           'Tapered fleece joggers.',          'Tapered joggers in mid-weight fleece with a drawcord waist and zip cuffs.',                                 58.00, NULL,   40, NULL,   0),
((SELECT id FROM categories WHERE slug='bottoms'),     'SP-VEC-JNS', 'Vector Straight Jeans', 'vector-straight-jeans',  'Rigid straight-leg denim.',        'Straight-leg denim in rigid 13oz cotton with a coated finish.',                                             89.00, NULL,   22, NULL,   0),
((SELECT id FROM categories WHERE slug='accessories'), 'SP-SIG-CAP', 'Signal Cap',            'signal-cap',             'Six-panel cotton cap.',            'Six-panel cotton cap with a curved brim and embroidered signal mark.',                                      34.00, NULL,   80, NULL,   0),
((SELECT id FROM categories WHERE slug='accessories'), 'SP-GLS-SUN', 'Glass Visor Sunglasses','glass-visor-sunglasses', 'Single-lens visor shades.',        'Single-lens visor sunglasses with UV400 protection and a lightweight alloy frame.',                         46.00, NULL,   35, NULL,   0),
((SELECT id FROM categories WHERE slug='accessories'), 'SP-VEC-BKP', 'Vector Backpack',       'vector-backpack',        '24L technical backpack.',          '24L technical backpack with a padded laptop sleeve and magnetic roll-top closure.',                        120.00, 145.00, 15, 'Sale', 1)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- ---------- Variants (sizes/colors match the prototype arrays) ----------
INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 10
FROM `products` p
JOIN (SELECT 'S' AS size UNION SELECT 'M' UNION SELECT 'L' UNION SELECT 'XL') s
JOIN (SELECT 'Black' AS color) c
WHERE p.slug IN ('chrome-jacket','pulse-hoodie','vector-straight-jeans')
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 10
FROM `products` p
JOIN (SELECT 'M' AS size UNION SELECT 'L' UNION SELECT 'XL') s
JOIN (SELECT 'Teal' AS color) c
WHERE p.slug = 'drift-trench-coat'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 10
FROM `products` p
JOIN (SELECT 'S' AS size UNION SELECT 'M' UNION SELECT 'L') s
JOIN (SELECT 'Gray' AS color) c
WHERE p.slug = 'halo-puffer-vest'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 12
FROM `products` p
JOIN (SELECT 'XS' AS size UNION SELECT 'S' UNION SELECT 'M' UNION SELECT 'L' UNION SELECT 'XL') s
JOIN (SELECT 'Teal' AS color UNION SELECT 'White') c
WHERE p.slug = 'voltage-tee'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 10
FROM `products` p
JOIN (SELECT 'S' AS size UNION SELECT 'M' UNION SELECT 'L') s
JOIN (SELECT 'Black' AS color) c
WHERE p.slug = 'echo-turtleneck'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 8
FROM `products` p
JOIN (SELECT 'S' AS size UNION SELECT 'M' UNION SELECT 'L' UNION SELECT 'XL') s
JOIN (SELECT 'Teal' AS color UNION SELECT 'Black') c
WHERE p.slug = 'nova-cargo-pants'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, s.size, c.color, 10
FROM `products` p
JOIN (SELECT 'XS' AS size UNION SELECT 'S' UNION SELECT 'M' UNION SELECT 'L') s
JOIN (SELECT 'Gray' AS color) c
WHERE p.slug = 'flux-joggers'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, 'One Size', c.color, 20
FROM `products` p
JOIN (SELECT 'Red' AS color) c
WHERE p.slug = 'signal-cap'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, 'One Size', 'Teal', 20 FROM `products` p WHERE p.slug = 'glass-visor-sunglasses'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

INSERT INTO `product_variants` (`product_id`, `size`, `color`, `stock`)
SELECT p.id, 'One Size', 'Black', 15 FROM `products` p WHERE p.slug = 'vector-backpack'
ON DUPLICATE KEY UPDATE `stock` = VALUES(`stock`);

-- ---------- Store settings ----------
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('store_name',            'SLEEKPICK'),
('store_email',           'hello@sleekpick.com'),
('currency_symbol',       '$'),
('free_shipping_minimum', '80'),
('shipping_flat_rate',    '9.99'),
('tax_rate_percent',      '0')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);
