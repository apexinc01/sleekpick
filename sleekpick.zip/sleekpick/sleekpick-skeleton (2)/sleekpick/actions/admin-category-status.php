<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

if (!isAdmin()) {
    jsonResponse(['success' => false, 'message' => 'Admin access required.'], 403);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

$categoryId = filter_var($input['category_id'] ?? null, FILTER_VALIDATE_INT);
$isActive   = filter_var($input['is_active'] ?? null, FILTER_VALIDATE_INT);

if ($categoryId === false || $categoryId === null || $categoryId < 1 || !in_array($isActive, [0, 1], true)) {
    jsonResponse(['success' => false, 'message' => 'Invalid category status request.'], 422);
}

$exists = dbFetchColumn('SELECT 1 FROM categories WHERE id = ? LIMIT 1', [$categoryId]);
if ($exists === null) {
    jsonResponse(['success' => false, 'message' => 'Category was not found.'], 404);
}

dbExecute('UPDATE categories SET is_active = ? WHERE id = ?', [$isActive, $categoryId]);

jsonResponse([
    'success'   => true,
    'message'   => $isActive === 1 ? 'Category is now live.' : 'Category hidden.',
    'is_active' => $isActive,
    'status'    => $isActive === 1 ? 'active' : 'hidden',
]);