<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isAdmin()) {
    header('Location: ../admin/login.php?error=unauthorized');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/categories.php');
    exit;
}

verifyCsrf(false);

$name        = trim((string) ($_POST['name'] ?? ''));
$slugInput   = trim((string) ($_POST['slug'] ?? ''));
$description = trim((string) ($_POST['description'] ?? ''));
$status      = strtolower(trim((string) ($_POST['status'] ?? 'active')));
$isActive    = $status === 'hidden' ? 0 : 1;

if ($name === '') {
    setFlash('error', 'Category name is required.');
    header('Location: ../admin/categories.php');
    exit;
}

if (mb_strlen($name) > 80) {
    $name = mb_substr($name, 0, 80);
}
if (mb_strlen($description) > 255) {
    $description = mb_substr($description, 0, 255);
}

$baseSlug = $slugInput !== '' ? slugify($slugInput) : slugify($name);
if ($baseSlug === '') {
    $baseSlug = 'category';
}

$slug = $baseSlug;
$i = 2;
while (dbFetchColumn('SELECT 1 FROM categories WHERE slug = ? LIMIT 1', [$slug]) !== null) {
    $slug = $baseSlug . '-' . $i;
    $i++;
}

$maxSort = (int) dbFetchColumn('SELECT COALESCE(MAX(sort_order), 0) FROM categories');
$sortOrder = $maxSort + 1;

try {
    dbInsert(
        'INSERT INTO categories (name, slug, description, sort_order, is_active) VALUES (?, ?, ?, ?, ?)',
        [$name, $slug, $description !== '' ? $description : null, $sortOrder, $isActive]
    );
    setFlash('success', 'Category “' . $name . '” created.');
} catch (Throwable $e) {
    setFlash('error', 'Could not create that category. Please try again.');
}

header('Location: ../admin/categories.php');
exit;