<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Update customer profile (account settings)
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: ../public/login.php?redirect=account.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../public/account.php?panel=settings');
    exit;
}

$token = (string) ($_POST['csrf_token'] ?? '');
if (!csrfTokenValid($token)) {
    setFlash('error', 'Invalid or expired security token. Please try again.');
    header('Location: ../public/account.php?panel=settings');
    exit;
}

$userId = currentUserId();
$user = currentUser();
if ($userId === null || $user === null) {
    header('Location: ../public/login.php');
    exit;
}

$firstName = trim((string) ($_POST['first_name'] ?? ''));
$lastName  = trim((string) ($_POST['last_name'] ?? ''));
$email     = strtolower(trim((string) ($_POST['email'] ?? '')));
$phone     = trim((string) ($_POST['phone'] ?? ''));

$currentPassword = (string) ($_POST['current_password'] ?? '');
$newPassword     = (string) ($_POST['new_password'] ?? '');
$confirmPassword = (string) ($_POST['confirm_password'] ?? '');

if ($firstName === '' || $lastName === '') {
    setFlash('error', 'First and last name are required.');
    header('Location: ../public/account.php?panel=settings');
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    setFlash('error', 'A valid email address is required.');
    header('Location: ../public/account.php?panel=settings');
    exit;
}

// Unique email check (excluding self)
$existing = dbFetchColumn(
    'SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1',
    [$email, $userId]
);
if ($existing !== null) {
    setFlash('error', 'That email is already used by another account.');
    header('Location: ../public/account.php?panel=settings');
    exit;
}

$changingPassword = $newPassword !== '' || $confirmPassword !== '' || $currentPassword !== '';

if ($changingPassword) {
    if ($currentPassword === '' || !password_verify($currentPassword, (string) $user['password_hash'])) {
        setFlash('error', 'Current password is incorrect.');
        header('Location: ../public/account.php?panel=settings');
        exit;
    }
    if (mb_strlen($newPassword) < 8) {
        setFlash('error', 'New password must be at least 8 characters.');
        header('Location: ../public/account.php?panel=settings');
        exit;
    }
    if ($newPassword !== $confirmPassword) {
        setFlash('error', 'New password confirmation does not match.');
        header('Location: ../public/account.php?panel=settings');
        exit;
    }
}

try {
    if ($changingPassword) {
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        dbExecute(
            'UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, password_hash = ? WHERE id = ?',
            [$firstName, $lastName, $email, $phone !== '' ? $phone : null, $hash, $userId]
        );
    } else {
        dbExecute(
            'UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ? WHERE id = ?',
            [$firstName, $lastName, $email, $phone !== '' ? $phone : null, $userId]
        );
    }

    // Refresh session display fields if stored
    if (isset($_SESSION['user_email'])) {
        $_SESSION['user_email'] = $email;
    }

    setFlash('success', 'Account settings saved.');
} catch (Throwable $e) {
    error_log('[SLEEKPICK] Profile update failed: ' . $e->getMessage());
    setFlash('error', 'Could not save your settings. Please try again.');
}

header('Location: ../public/account.php?panel=settings');
exit;