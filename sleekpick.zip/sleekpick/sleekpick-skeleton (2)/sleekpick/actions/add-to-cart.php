<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Add to Cart (action endpoint)
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

$errors = [];

$productId = filter_var($input['productId'] ?? null, FILTER_VALIDATE_INT);
if ($productId === false || $productId === null || $productId <= 0) {
    $errors[] = 'A valid productId is required.';
}

$size = trim(strip_tags((string) ($input['size'] ?? '')));
$color = trim(strip_tags((string) ($input['color'] ?? '')));

$quantity = filter_var($input['quantity'] ?? 1, FILTER_VALIDATE_INT);
if ($quantity === false || $quantity === null || $quantity < 1) {
    $quantity = 1;
}
$quantity = min($quantity, 10);

if ($errors !== []) {
    jsonResponse(['success' => false, 'message' => implode(' ', $errors)], 422);
}

$product = dbFetch(
    'SELECT id, name, price, image, stock, is_active FROM products WHERE id = ? LIMIT 1',
    [$productId]
);

if ($product === null || (int) $product['is_active'] !== 1) {
    jsonResponse(['success' => false, 'message' => 'That product is no longer available.'], 404);
}

$hasVariants = (int) dbFetchColumn('SELECT COUNT(*) FROM product_variants WHERE product_id = ?', [$productId]) > 0;

$variant = null;
if ($size !== '' && $color !== '') {
    $variant = dbFetch(
        'SELECT id, size, color, stock, price_override FROM product_variants
         WHERE product_id = ? AND size = ? AND color = ? LIMIT 1',
        [$productId, $size, $color]
    );
}

// Fallback to first available variant (helps shop-page Add to Cart)
if ($hasVariants && $variant === null) {
    $variant = dbFetch(
        'SELECT id, size, color, stock, price_override FROM product_variants
         WHERE product_id = ? AND stock > 0
         ORDER BY id ASC
         LIMIT 1',
        [$productId]
    );
    if ($variant === null) {
        $variant = dbFetch(
            'SELECT id, size, color, stock, price_override FROM product_variants
             WHERE product_id = ?
             ORDER BY id ASC
             LIMIT 1',
            [$productId]
        );
    }
    if ($variant === null) {
        jsonResponse(['success' => false, 'message' => 'That size and colour combination is not available.'], 422);
    }
    $size  = (string) $variant['size'];
    $color = (string) $variant['color'];
}

if ($size === '') {
    $size = 'One Size';
}
if ($color === '') {
    $color = 'Default';
}
if (mb_strlen($size) > 30 || mb_strlen($color) > 30) {
    jsonResponse(['success' => false, 'message' => 'Invalid size or colour.'], 422);
}

$availableStock = $variant !== null ? (int) $variant['stock'] : (int) $product['stock'];
if ($availableStock < 1) {
    jsonResponse(['success' => false, 'message' => 'That option is out of stock.'], 409);
}

$alreadyInCart = getCart()[cartItemKey((int) $product['id'], $size, $color)]['quantity'] ?? 0;
if (($alreadyInCart + $quantity) > $availableStock) {
    $quantity = max(0, $availableStock - (int) $alreadyInCart);
    if ($quantity === 0) {
        jsonResponse([
            'success' => false,
            'message' => 'You already have all remaining stock of that option in your cart.',
        ], 409);
    }
}

$price = (float) ($variant['price_override'] ?? $product['price']);

$cart = addCartItem(
    (int) $product['id'],
    (string) $product['name'],
    $price,
    $size,
    $color,
    $quantity,
    (string) ($product['image'] ?? '')
);

jsonResponse([
    'success'      => true,
    'message'      => e((string) $product['name']) . ' added to cart.',
    'cartCount'    => getCartCount($cart),
    'cartSubtotal' => round(getCartSubtotal($cart), 2),
]);