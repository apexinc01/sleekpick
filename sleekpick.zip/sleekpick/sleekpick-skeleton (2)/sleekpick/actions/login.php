<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Login (action endpoint)
 *
 * Serves both public/login.php and admin/login.php. The optional
 * `context` field ("admin") makes the endpoint require the admin role,
 * so a customer account can never open the admin area.
 *
 * Protections: CSRF token, throttled attempts (includes/auth.php),
 * generic failure message (no account enumeration), session id
 * regeneration on success.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$wantsJson = str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
    || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
    }
    header('Location: ../public/login.php');
    exit;
}

$input = jsonInput();
verifyCsrf($wantsJson);

$isAdminContext = ($input['context'] ?? '') === 'admin';
$loginPage = $isAdminContext ? '../admin/login.php' : '../public/login.php';

$email    = trim((string) ($input['email'] ?? ''));
$password = (string) ($input['password'] ?? '');

if ($email === '' || $password === '') {
    $message = 'Enter both your email and password.';
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => $message], 422);
    }
    setFlash('error', $message);
    header('Location: ' . $loginPage);
    exit;
}

if (loginThrottled($email)) {
    $message = 'Too many failed attempts. Please wait 15 minutes and try again.';
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => $message], 429);
    }
    setFlash('error', $message);
    header('Location: ' . $loginPage);
    exit;
}

$user = attemptLogin($email, $password, $isAdminContext);

if ($user === null) {
    // Same message for every failure mode — no account enumeration.
    $message = 'Those credentials do not match our records.';
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => $message], 401);
    }
    setFlash('error', $message);
    header('Location: ' . $loginPage);
    exit;
}

loginUser($user);

// Only allow redirects back into this site — never to an external URL.
$requested = (string) ($input['redirect'] ?? '');
$isSafeRedirect = $requested !== '' && str_starts_with($requested, '/') && !str_starts_with($requested, '//');

$destination = $isAdminContext
    ? '../admin/dashboard.php'
    : ($isSafeRedirect ? $requested : '../public/account.php');

setFlash('success', 'Signed in as ' . e($user['email']) . '.');

if ($wantsJson) {
    jsonResponse(['success' => true, 'message' => 'Signed in.', 'redirect' => $destination]);
}

header('Location: ' . $destination);
exit;
