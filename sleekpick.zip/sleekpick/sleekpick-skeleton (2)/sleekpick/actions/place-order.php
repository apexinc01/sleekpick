<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Place Order (action endpoint)
 *
 * Handles the public/checkout.php submit. Everything happens inside one
 * database transaction (dbTransaction): the order header, its item
 * snapshots and the stock decrements either all commit or all roll back,
 * so a failure halfway through can never leave a half-written order.
 *
 * Prices, names and images are re-read from the `products` table at this
 * point — the session cart is treated as a list of intents, not as a
 * source of pricing truth.
 *
 * PAYMENT: no payment provider is connected. Orders are stored with
 * payment_status = 'unpaid' and payment_method = 'cash_on_delivery' or
 * 'bank_transfer'. Wiring a real gateway is a separate, explicit step.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

$wantsJson = str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
    || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
    }
    header('Location: ../public/checkout.php');
    exit;
}

$input = jsonInput();
verifyCsrf($wantsJson);

/** Fail consistently for both JSON and form submits. */
function orderFailure(string $message, int $status, bool $wantsJson): never
{
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => $message], $status);
    }
    setFlash('error', $message);
    header('Location: ../public/checkout.php');
    exit;
}

$cart = getCart();
if ($cart === []) {
    orderFailure('Your cart is empty.', 422, $wantsJson);
}

// ---------- Validate shipping details ----------
$fields = [
    'email'       => ['label' => 'Email',        'max' => 190, 'required' => true],
    'full_name'   => ['label' => 'Full name',    'max' => 120, 'required' => true],
    'line1'       => ['label' => 'Address',      'max' => 160, 'required' => true],
    'line2'       => ['label' => 'Address 2',    'max' => 160, 'required' => false],
    'city'        => ['label' => 'City',         'max' => 80,  'required' => true],
    'state'       => ['label' => 'State',        'max' => 80,  'required' => false],
    'postal_code' => ['label' => 'Postal code',  'max' => 20,  'required' => false],
    'country'     => ['label' => 'Country',      'max' => 80,  'required' => true],
    'phone'       => ['label' => 'Phone',        'max' => 30,  'required' => true],
    'notes'       => ['label' => 'Order notes',  'max' => 500, 'required' => false],
];

$data = [];
$errors = [];

foreach ($fields as $name => $rules) {
    $value = trim(strip_tags((string) ($input[$name] ?? '')));

    if ($rules['required'] && $value === '') {
        $errors[] = $rules['label'] . ' is required.';
    }
    if (mb_strlen($value) > $rules['max']) {
        $errors[] = $rules['label'] . ' is too long.';
    }

    $data[$name] = $value;
}

if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid email address is required.';
}

$paymentMethod = (string) ($input['payment_method'] ?? 'cash_on_delivery');
if (!in_array($paymentMethod, ['cash_on_delivery', 'bank_transfer'], true)) {
    $errors[] = 'Choose an available payment method.';
}

if ($errors !== []) {
    orderFailure(implode(' ', $errors), 422, $wantsJson);
}

// ---------- Build the order from authoritative product data ----------
$freeShippingMinimum = (float) settingValue('free_shipping_minimum', '80');
$shippingFlatRate    = (float) settingValue('shipping_flat_rate', '9.99');
$taxRatePercent      = (float) settingValue('tax_rate_percent', '0');

try {
    $orderId = dbTransaction(function (PDO $pdo) use (
        $cart, $data, $paymentMethod, $freeShippingMinimum, $shippingFlatRate, $taxRatePercent
    ): int {
        $lines = [];
        $subtotal = 0.0;

        foreach ($cart as $item) {
            $product = dbFetch(
                'SELECT id, name, sku, price, image, stock, is_active FROM products WHERE id = ? FOR UPDATE',
                [(int) $item['productId']]
            );

            if ($product === null || (int) $product['is_active'] !== 1) {
                throw new RuntimeException('"' . $item['name'] . '" is no longer available. Please remove it from your cart.');
            }

            $variant = dbFetch(
                'SELECT id, stock, price_override FROM product_variants
                 WHERE product_id = ? AND size = ? AND color = ? FOR UPDATE',
                [(int) $product['id'], (string) $item['size'], (string) $item['color']]
            );

            $quantity  = max(1, (int) $item['quantity']);
            $stock     = $variant !== null ? (int) $variant['stock'] : (int) $product['stock'];
            $unitPrice = (float) ($variant['price_override'] ?? $product['price']);

            if ($stock < $quantity) {
                throw new RuntimeException('Only ' . $stock . ' left of "' . $product['name'] . '" in that option.');
            }

            $lineTotal = round($unitPrice * $quantity, 2);
            $subtotal += $lineTotal;

            $lines[] = [
                'product_id'   => (int) $product['id'],
                'product_name' => (string) $product['name'],
                'sku'          => (string) ($product['sku'] ?? ''),
                'image'        => (string) ($product['image'] ?? ''),
                'size'         => (string) $item['size'],
                'color'        => (string) $item['color'],
                'unit_price'   => $unitPrice,
                'quantity'     => $quantity,
                'line_total'   => $lineTotal,
                'variant_id'   => $variant !== null ? (int) $variant['id'] : null,
            ];
        }

        $subtotal    = round($subtotal, 2);
        $shippingFee = $subtotal >= $freeShippingMinimum ? 0.00 : $shippingFlatRate;
        $tax         = round($subtotal * ($taxRatePercent / 100), 2);
        $total       = round($subtotal + $shippingFee + $tax, 2);

        $orderNumber = 'SP-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));

        $orderId = dbInsert(
            'INSERT INTO orders
                (order_number, user_id, email, status, payment_status, payment_method,
                 subtotal, shipping_fee, tax, total,
                 ship_full_name, ship_line1, ship_line2, ship_city, ship_state,
                 ship_postal_code, ship_country, ship_phone, notes)
             VALUES (?, ?, ?, "pending", "unpaid", ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $orderNumber,
                currentUserId(),
                $data['email'],
                $paymentMethod,
                $subtotal, $shippingFee, $tax, $total,
                $data['full_name'], $data['line1'], $data['line2'] ?: null,
                $data['city'], $data['state'] ?: null, $data['postal_code'] ?: null,
                $data['country'], $data['phone'], $data['notes'] ?: null,
            ]
        );

        foreach ($lines as $line) {
            dbInsert(
                'INSERT INTO order_items
                    (order_id, product_id, product_name, sku, image, size, color, unit_price, quantity, line_total)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $orderId, $line['product_id'], $line['product_name'], $line['sku'], $line['image'],
                    $line['size'], $line['color'], $line['unit_price'], $line['quantity'], $line['line_total'],
                ]
            );

            if ($line['variant_id'] !== null) {
                dbExecute('UPDATE product_variants SET stock = stock - ? WHERE id = ?', [$line['quantity'], $line['variant_id']]);
            }
            dbExecute('UPDATE products SET stock = GREATEST(0, stock - ?) WHERE id = ?', [$line['quantity'], $line['product_id']]);
        }

        return $orderId;
    });
} catch (RuntimeException $e) {
    // Business-rule failure (stock/availability): safe to show the shopper.
    orderFailure($e->getMessage(), 409, $wantsJson);
} catch (Throwable $e) {
    error_log('[SLEEKPICK] Order failed: ' . $e->getMessage());
    orderFailure('We could not complete your order. Please try again.', 500, $wantsJson);
}

$order = dbFetch('SELECT order_number, total FROM orders WHERE id = ?', [$orderId]);

// Cart is consumed by the order.
saveCart([]);

setFlash('success', 'Order ' . e((string) $order['order_number']) . ' placed. Thank you!');

$destination = '../public/account.php?order=' . urlencode((string) $order['order_number']);

if ($wantsJson) {
    jsonResponse([
        'success'     => true,
        'message'     => 'Order placed.',
        'orderNumber' => $order['order_number'],
        'total'       => (float) $order['total'],
        'redirect'    => $destination,
    ]);
}

header('Location: ' . $destination);
exit;
