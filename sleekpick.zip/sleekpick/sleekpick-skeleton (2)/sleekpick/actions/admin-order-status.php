<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

$orderId = filter_var($input['order_id'] ?? null, FILTER_VALIDATE_INT);
$status = strtolower(trim((string) ($input['status'] ?? '')));
$allowedStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];

if ($orderId === false || $orderId === null || $orderId < 1 || !in_array($status, $allowedStatuses, true)) {
    jsonResponse(['success' => false, 'message' => 'Invalid order status request.'], 422);
}

$changed = dbExecute('UPDATE orders SET status = ? WHERE id = ?', [$status, $orderId]);

if ($changed < 1) {
    jsonResponse(['success' => false, 'message' => 'Order was not found or already had that status.'], 404);
}

jsonResponse(['success' => true, 'message' => 'Order status updated.', 'status' => $status]);