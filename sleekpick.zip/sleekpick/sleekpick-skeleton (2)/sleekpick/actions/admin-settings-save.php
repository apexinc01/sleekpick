<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isAdmin()) {
    header('Location: ../admin/login.php?error=unauthorized');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/settings.php');
    exit;
}

$token = (string) ($_POST['csrf_token'] ?? '');
if (!csrfTokenValid($token)) {
    setFlash('error', 'Invalid or expired security token. Please refresh and try again.');
    header('Location: ../admin/settings.php');
    exit;
}

$storeName = trim((string) ($_POST['store_name'] ?? ''));
$storeEmail = trim((string) ($_POST['store_email'] ?? ''));
$storeDescription = trim((string) ($_POST['store_description'] ?? ''));
$currency = strtoupper(trim((string) ($_POST['currency'] ?? 'USD')));
$timezone = trim((string) ($_POST['timezone'] ?? 'Africa/Lagos'));
$currencySymbol = trim((string) ($_POST['currency_symbol'] ?? '$'));
$freeShippingMin = trim((string) ($_POST['free_shipping_minimum'] ?? '0'));
$shippingFlat = trim((string) ($_POST['shipping_flat_rate'] ?? '0'));
$taxRate = trim((string) ($_POST['tax_rate_percent'] ?? '0'));

$notifyOrders = isset($_POST['notify_new_orders']) ? '1' : '0';
$notifyLowStock = isset($_POST['notify_low_stock']) ? '1' : '0';
$notifyCustomers = isset($_POST['notify_new_customers']) ? '1' : '0';

$allowedCurrencies = ['USD', 'NGN', 'GBP', 'EUR'];
if (!in_array($currency, $allowedCurrencies, true)) {
    $currency = 'USD';
}

$allowedTimezones = ['Africa/Lagos', 'Europe/London', 'America/New_York', 'UTC'];
if (!in_array($timezone, $allowedTimezones, true)) {
    $timezone = 'Africa/Lagos';
}

if ($storeName === '') {
    setFlash('error', 'Store name is required.');
    header('Location: ../admin/settings.php');
    exit;
}

if (!filter_var($storeEmail, FILTER_VALIDATE_EMAIL)) {
    setFlash('error', 'A valid support email is required.');
    header('Location: ../admin/settings.php');
    exit;
}

if ($currencySymbol === '') {
    $defaults = ['USD' => '$', 'NGN' => '₦', 'GBP' => '£', 'EUR' => '€'];
    $currencySymbol = $defaults[$currency] ?? '$';
}

$freeShippingMin = is_numeric($freeShippingMin) ? (string) max(0, (float) $freeShippingMin) : '0';
$shippingFlat = is_numeric($shippingFlat) ? (string) max(0, (float) $shippingFlat) : '0';
$taxRate = is_numeric($taxRate) ? (string) min(100, max(0, (float) $taxRate)) : '0';

if (mb_strlen($storeName) > 120) {
    $storeName = mb_substr($storeName, 0, 120);
}
if (mb_strlen($storeDescription) > 500) {
    $storeDescription = mb_substr($storeDescription, 0, 500);
}
if (mb_strlen($currencySymbol) > 8) {
    $currencySymbol = mb_substr($currencySymbol, 0, 8);
}

$pairs = [
    'store_name'            => $storeName,
    'store_email'           => $storeEmail,
    'store_description'     => $storeDescription,
    'currency'              => $currency,
    'timezone'              => $timezone,
    'currency_symbol'       => $currencySymbol,
    'free_shipping_minimum' => $freeShippingMin,
    'shipping_flat_rate'    => $shippingFlat,
    'tax_rate_percent'      => $taxRate,
    'notify_new_orders'     => $notifyOrders,
    'notify_low_stock'      => $notifyLowStock,
    'notify_new_customers'  => $notifyCustomers,
];

try {
    foreach ($pairs as $key => $value) {
        dbExecute(
            'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)',
            [$key, $value]
        );
    }
    setFlash('success', 'Settings saved.');
} catch (Throwable $e) {
    error_log('[SLEEKPICK] Settings save failed: ' . $e->getMessage());
    setFlash('error', 'Could not save settings. Please try again.');
}

header('Location: ../admin/settings.php');
exit;