<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Update Cart Quantity (action endpoint)
 *
 * POST JSON endpoint used by the quantity steppers in assets/js/cart.js.
 * Sets an explicit quantity on one cart line; a quantity of 0 removes
 * the line. The same 10-per-line ceiling as add-to-cart.php applies, so
 * a scripted request cannot push a line to an absurd quantity.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

const CART_MAX_QUANTITY_PER_LINE = 10;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

$key = trim((string) ($input['key'] ?? ''));

if ($key === '') {
    $productId = filter_var($input['productId'] ?? null, FILTER_VALIDATE_INT);
    $size      = trim(strip_tags((string) ($input['size'] ?? '')));
    $color     = trim(strip_tags((string) ($input['color'] ?? '')));

    if ($productId === false || $productId === null || $productId <= 0 || $size === '' || $color === '') {
        jsonResponse(['success' => false, 'message' => 'A cart item key (or productId, size and color) is required.'], 422);
    }

    $key = cartItemKey($productId, $size, $color);
}

$quantity = filter_var($input['quantity'] ?? null, FILTER_VALIDATE_INT);
if ($quantity === false || $quantity === null || $quantity < 0) {
    jsonResponse(['success' => false, 'message' => 'A valid quantity is required.'], 422);
}
$quantity = min($quantity, CART_MAX_QUANTITY_PER_LINE);

$cart = getCart();
if (!isset($cart[$key])) {
    jsonResponse(['success' => false, 'message' => 'That item is no longer in your cart.'], 404);
}

$cart = updateCartItemQuantity($key, $quantity, CART_MAX_QUANTITY_PER_LINE);

$lineTotal = isset($cart[$key])
    ? round((float) $cart[$key]['price'] * (int) $cart[$key]['quantity'], 2)
    : 0.0;

jsonResponse([
    'success'      => true,
    'message'      => $quantity === 0 ? 'Item removed from your cart.' : 'Cart updated.',
    'key'          => $key,
    'quantity'     => isset($cart[$key]) ? (int) $cart[$key]['quantity'] : 0,
    'lineTotal'    => $lineTotal,
    'removed'      => !isset($cart[$key]),
    'cartCount'    => getCartCount($cart),
    'cartSubtotal' => round(getCartSubtotal($cart), 2),
    'cartEmpty'    => $cart === [],
]);
