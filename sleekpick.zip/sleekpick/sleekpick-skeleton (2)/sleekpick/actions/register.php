<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Register (action endpoint)
 *
 * Handles the public/register.php form submit. Validates through the
 * shared rules in includes/auth.php (validateRegistration), creates the
 * account with a hashed password, signs the new user in, then redirects
 * back to the site. Supports both a classic form post (redirect) and a
 * fetch() call (JSON), decided by the Accept/X-Requested-With header.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$wantsJson = str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
    || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $wantsJson
        ? jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405)
        : redirectBack('../public/register.php');
}

$input = jsonInput();
verifyCsrf($wantsJson);

$errors = validateRegistration($input);

if ($errors !== []) {
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => implode(' ', $errors), 'errors' => $errors], 422);
    }
    foreach ($errors as $error) {
        setFlash('error', $error);
    }
    $_SESSION['old_input'] = [
        'first_name' => (string) ($input['first_name'] ?? ''),
        'last_name'  => (string) ($input['last_name'] ?? ''),
        'email'      => (string) ($input['email'] ?? ''),
    ];
    header('Location: ../public/register.php');
    exit;
}

$userId = registerUser($input);
$user = dbFetch('SELECT id, first_name, last_name, email, role, status FROM users WHERE id = ?', [$userId]);

if ($user !== null) {
    loginUser($user);
}

setFlash('success', 'Welcome to SLEEKPICK, ' . e((string) $input['first_name']) . '.');

if ($wantsJson) {
    jsonResponse(['success' => true, 'message' => 'Account created.', 'redirect' => '../public/account.php']);
}

header('Location: ../public/account.php');
exit;

/** Fallback redirect used when the endpoint is opened directly. */
function redirectBack(string $path): never
{
    header('Location: ' . $path);
    exit;
}
