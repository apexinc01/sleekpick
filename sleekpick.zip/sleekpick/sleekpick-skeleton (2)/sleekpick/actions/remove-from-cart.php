<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Remove From Cart (action endpoint)
 *
 * POST JSON endpoint used by assets/js/cart.js. Accepts either the
 * composite cart key ("12:m:black") or productId + size + color, so the
 * frontend can call it whichever way is convenient, and returns the
 * refreshed totals for the cart page and header badge.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

$key = trim((string) ($input['key'] ?? ''));

if ($key === '') {
    $productId = filter_var($input['productId'] ?? null, FILTER_VALIDATE_INT);
    $size      = trim(strip_tags((string) ($input['size'] ?? '')));
    $color     = trim(strip_tags((string) ($input['color'] ?? '')));

    if ($productId === false || $productId === null || $productId <= 0 || $size === '' || $color === '') {
        jsonResponse(['success' => false, 'message' => 'A cart item key (or productId, size and color) is required.'], 422);
    }

    $key = cartItemKey($productId, $size, $color);
}

$cart = getCart();

if (!isset($cart[$key])) {
    jsonResponse(['success' => false, 'message' => 'That item is no longer in your cart.'], 404);
}

$removedName = (string) $cart[$key]['name'];
$cart = removeCartItem($key);

jsonResponse([
    'success'      => true,
    'message'      => e($removedName) . ' removed from your cart.',
    'key'          => $key,
    'cartCount'    => getCartCount($cart),
    'cartSubtotal' => round(getCartSubtotal($cart), 2),
    'cartEmpty'    => $cart === [],
]);
