<?php
declare(strict_types=1);

/**
 * SLEEKPICK ADMIN — Toggle Product Active/Archived
 *
 * Mirrors actions/admin-order-status.php's pattern exactly.
 *
 * DESIGN DECISION: products are never hard-deleted from here. The
 * products table has no separate "deleted" state, and order_items
 * keeps a snapshot of product_name/sku/price at time of purchase, so a
 * hard DELETE would silently break past order history for no benefit.
 * "Delete" in the admin UI (.delete-btn) is wired to this endpoint and
 * sets is_active = 0 (archived) — reversible, and safe against the
 * foreign key from order_items. A true hard-delete endpoint can be
 * added later if there's a real need for it, as its own explicit,
 * separately-confirmed action.
 */

require_once __DIR__ . '/../includes/auth.php';

// NOTE: not using requireAdmin() here on purpose — it does an HTML
// redirect() on failure, but this endpoint is called via fetch() and
// must always return JSON, even when rejecting the request.
if (!isAdmin()) {
    jsonResponse(['success' => false, 'message' => 'Admin access required.'], 403);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$input = jsonInput();
verifyCsrf();

$productId = filter_var($input['product_id'] ?? null, FILTER_VALIDATE_INT);
$isActive = filter_var($input['is_active'] ?? null, FILTER_VALIDATE_INT);

if ($productId === false || $productId === null || $productId < 1 || !in_array($isActive, [0, 1], true)) {
    jsonResponse(['success' => false, 'message' => 'Invalid product status request.'], 422);
}

$changed = dbExecute('UPDATE products SET is_active = ? WHERE id = ?', [$isActive, $productId]);

if ($changed < 1) {
    // Not necessarily an error — the row may already have been in that state.
    $exists = dbFetchColumn('SELECT 1 FROM products WHERE id = ? LIMIT 1', [$productId]);
    if ($exists === null) {
        jsonResponse(['success' => false, 'message' => 'Product was not found.'], 404);
    }
}

jsonResponse([
    'success'   => true,
    'message'   => $isActive === 1 ? 'Product activated.' : 'Product archived.',
    'is_active' => $isActive,
]);