<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Logout (action endpoint)
 *
 * Destroys the session (see includes/auth.php::logoutUser) and returns
 * the visitor to the storefront, or to the admin login page when the
 * request came from the admin area.
 *
 * Logout is state-changing, so it requires POST + a CSRF token: a
 * plain <a href> or an <img src> on another site must not be able to
 * sign a user out.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$wantsJson = str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
    || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($wantsJson) {
        jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
    }
    header('Location: ../public/index.php');
    exit;
}

$input = jsonInput();
$isAdminContext = ($input['context'] ?? '') === 'admin';

verifyCsrf($wantsJson);
logoutUser();

$destination = $isAdminContext ? '../admin/login.php' : '../public/index.php';

if ($wantsJson) {
    jsonResponse(['success' => true, 'message' => 'Signed out.', 'redirect' => $destination]);
}

header('Location: ' . $destination);
exit;
