<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Authentication & Session Security
 *
 * The single source of truth for "who is logged in and what may they do".
 * Used by actions/login.php, actions/register.php, actions/logout.php,
 * the customer pages (header state, account page) and every admin page.
 *
 * Design decisions:
 *  - Passwords are hashed with password_hash() (bcrypt/default algo) and
 *    verified with password_verify(); plain text is never stored or logged.
 *  - The session id is regenerated on login and logout to defeat
 *    session fixation.
 *  - Failed logins are recorded in `login_attempts` and throttled, so a
 *    stolen email list cannot be brute-forced.
 *  - Admin access is decided by users.role in the database on every
 *    request, never by a client-controlled value.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';

const AUTH_MAX_ATTEMPTS      = 5;    // failures allowed …
const AUTH_ATTEMPT_WINDOW    = 900;  // … within this many seconds (15 min)
const AUTH_MIN_PASSWORD_LEN  = 8;

// ---------------------------------------------------------------
// Session state
// ---------------------------------------------------------------

/** Is anyone signed in on this session? */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']) && (int) $_SESSION['user_id'] > 0;
}

/** The signed-in user's id, or null. */
function currentUserId(): ?int
{
    return isLoggedIn() ? (int) $_SESSION['user_id'] : null;
}

/**
 * The full signed-in user row (fetched once per request), or null.
 * Re-reading from the database means a suspended or demoted account
 * loses access immediately rather than at next login.
 */
function currentUser(): ?array
{
    static $user = null;
    static $loaded = false;

    if ($loaded) {
        return $user;
    }
    $loaded = true;

    $id = currentUserId();
    if ($id === null) {
        return null;
    }

    $user = dbFetch(
        'SELECT id, first_name, last_name, email, phone, role, status, created_at
         FROM users WHERE id = ? LIMIT 1',
        [$id]
    );

    // Account deleted or suspended since login → drop the session.
    if ($user === null || $user['status'] !== 'active') {
        logoutUser();
        $user = null;
    }

    return $user;
}

/** Convenience: display name for the header / account page. */
function currentUserName(): string
{
    $user = currentUser();
    return $user === null ? '' : trim($user['first_name'] . ' ' . $user['last_name']);
}

function isAdmin(): bool
{
    $user = currentUser();
    return $user !== null && $user['role'] === 'admin';
}

/** Write the session keys that mark a user as signed in. */
function loginUser(array $user): void
{
    session_regenerate_id(true);

    $_SESSION['user_id']    = (int) $user['id'];
    $_SESSION['user_role']  = $user['role'];
    $_SESSION['user_name']  = trim($user['first_name'] . ' ' . $user['last_name']);
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['logged_in_at'] = time();

    dbExecute('UPDATE users SET last_login_at = NOW() WHERE id = ?', [(int) $user['id']]);
}

/** Clear the session completely (keeps nothing, including the cart). */
function logoutUser(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]);
    }

    session_destroy();
}

// ---------------------------------------------------------------
// Guards — call at the very top of a protected page, before output
// ---------------------------------------------------------------

/** Customer-area guard: send guests to the login page. */
function requireLogin(string $redirectTo = 'login.php'): void
{
    if (!isLoggedIn()) {
        $target = $_SERVER['REQUEST_URI'] ?? '';
        header('Location: ' . $redirectTo . '?redirect=' . urlencode($target));
        exit;
    }
}

/** Admin-area guard: anything that is not an active admin is bounced. */
function requireAdmin(string $redirectTo = 'login.php'): void
{
    if (!isAdmin()) {
        header('Location: ' . $redirectTo . '?error=unauthorized');
        exit;
    }
}

// ---------------------------------------------------------------
// Registration & login
// ---------------------------------------------------------------

function emailExists(string $email): bool
{
    return dbFetchColumn('SELECT 1 FROM users WHERE email = ? LIMIT 1', [strtolower($email)]) !== null;
}

/**
 * Validate registration input. Returns a list of human-readable errors
 * (empty array = valid). Shared by actions/register.php and admin user
 * creation so the rules can never drift apart.
 */
function validateRegistration(array $input): array
{
    $errors = [];

    if (trim((string) ($input['first_name'] ?? '')) === '') {
        $errors[] = 'First name is required.';
    }
    if (trim((string) ($input['last_name'] ?? '')) === '') {
        $errors[] = 'Last name is required.';
    }

    $email = trim((string) ($input['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    } elseif (emailExists($email)) {
        $errors[] = 'An account with that email already exists.';
    }

    $password = (string) ($input['password'] ?? '');
    if (strlen($password) < AUTH_MIN_PASSWORD_LEN) {
        $errors[] = 'Password must be at least ' . AUTH_MIN_PASSWORD_LEN . ' characters.';
    }
    if ($password !== (string) ($input['confirm_password'] ?? $password)) {
        $errors[] = 'Passwords do not match.';
    }

    return $errors;
}

/** Create a customer account and return the new user id. */
function registerUser(array $input): int
{
    return dbInsert(
        'INSERT INTO users (first_name, last_name, email, password_hash, phone, role)
         VALUES (?, ?, ?, ?, ?, "customer")',
        [
            trim((string) $input['first_name']),
            trim((string) $input['last_name']),
            strtolower(trim((string) $input['email'])),
            password_hash((string) $input['password'], PASSWORD_DEFAULT),
            trim((string) ($input['phone'] ?? '')) ?: null,
        ]
    );
}

// ---------------------------------------------------------------
// Brute-force throttling
// ---------------------------------------------------------------

function clientIp(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
}

function recordLoginAttempt(string $email, bool $successful): void
{
    dbExecute(
        'INSERT INTO login_attempts (email, ip_address, successful) VALUES (?, ?, ?)',
        [strtolower($email), clientIp(), $successful ? 1 : 0]
    );
}

/** True when this email/IP pair has failed too often recently. */
function loginThrottled(string $email): bool
{
    $failures = (int) dbFetchColumn(
        'SELECT COUNT(*) FROM login_attempts
         WHERE successful = 0
           AND (email = ? OR ip_address = ?)
           AND attempted_at > (NOW() - INTERVAL ? SECOND)',
        [strtolower($email), clientIp(), AUTH_ATTEMPT_WINDOW]
    );

    return $failures >= AUTH_MAX_ATTEMPTS;
}

/** Clear the failure history after a successful sign-in. */
function clearLoginAttempts(string $email): void
{
    dbExecute('DELETE FROM login_attempts WHERE email = ? OR ip_address = ?', [strtolower($email), clientIp()]);
}

/**
 * Verify credentials. Returns the user row on success, null on failure.
 * Deliberately does not distinguish "no such email" from "wrong password"
 * so the endpoint cannot be used to enumerate accounts.
 *
 * $requireAdmin is used by the admin login form so a customer account
 * can never open the admin area even with valid credentials.
 */
function attemptLogin(string $email, string $password, bool $requireAdminRole = false): ?array
{
    $email = strtolower(trim($email));

    $user = dbFetch(
        'SELECT id, first_name, last_name, email, password_hash, role, status
         FROM users WHERE email = ? LIMIT 1',
        [$email]
    );

    if ($user === null || !password_verify($password, $user['password_hash'])) {
        recordLoginAttempt($email, false);
        return null;
    }

    if ($user['status'] !== 'active' || ($requireAdminRole && $user['role'] !== 'admin')) {
        recordLoginAttempt($email, false);
        return null;
    }

    // Transparent upgrade if the hashing cost/algorithm has moved on.
    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        dbExecute(
            'UPDATE users SET password_hash = ? WHERE id = ?',
            [password_hash($password, PASSWORD_DEFAULT), (int) $user['id']]
        );
    }

    recordLoginAttempt($email, true);
    clearLoginAttempts($email);

    unset($user['password_hash']);
    return $user;
}
