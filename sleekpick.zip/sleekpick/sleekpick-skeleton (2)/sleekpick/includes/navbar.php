<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Site header / primary navigation (customer site)
 *
 * Included by includes/header.php. Same markup and classes as the
 * prototype header so assets/css/style.css and assets/js/main.js keep
 * working unchanged — the difference is that the cart badge, the
 * account link and the active nav state are now real:
 *
 *  - cart count comes from the session cart (getCartCount)
 *  - the person icon links to account.php when signed in, login.php otherwise
 *  - $activeNav (set by the page) drives the .active class
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$activeNav  = $activeNav ?? '';
$cartCount  = getCartCount(getCart());
$signedIn   = isLoggedIn();
$accountUrl = $signedIn ? 'account.php' : 'login.php';
$accountLbl = $signedIn ? 'Your account' : 'Sign in';
?>
<header id="site-header">
    <div class="container header-inner">
        <a href="index.php" class="logo">SLEEK<span>PICK</span></a>

        <nav class="main-nav" aria-label="Primary">
            <a href="index.php"<?php echo $activeNav === 'home' ? ' class="active" aria-current="page"' : ''; ?>>Home</a>
            <a href="shop.php"<?php echo $activeNav === 'shop' ? ' class="active" aria-current="page"' : ''; ?>>Shop</a>
            <a href="shop.php?category=new"<?php echo $activeNav === 'new' ? ' class="active" aria-current="page"' : ''; ?>>New Arrivals</a>
            <a href="shop.php?category=accessories"<?php echo $activeNav === 'accessories' ? ' class="active" aria-current="page"' : ''; ?>>Accessories</a>
        </nav>

        <div class="header-actions">
            <button type="button" aria-label="Search" data-search-toggle>
                <i class="bi bi-search"></i>
            </button>

            <a href="<?php echo e($accountUrl); ?>" aria-label="<?php echo e($accountLbl); ?>" title="<?php echo e($accountLbl); ?>">
                <i class="bi <?php echo $signedIn ? 'bi-person-check' : 'bi-person'; ?>"></i>
            </a>

            <a href="account.php#wishlist" aria-label="Wishlist">
                <i class="bi bi-heart"></i>
            </a>

            <a href="cart.php" aria-label="Cart, <?php echo (int) $cartCount; ?> items" class="cart-link">
                <i class="bi bi-bag"></i>
                <span class="cart-count" data-cart-count<?php echo $cartCount === 0 ? ' hidden' : ''; ?>><?php echo (int) $cartCount; ?></span>
            </a>

            <button type="button" class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                <i class="bi bi-list"></i>
            </button>
        </div>
    </div>
</header>
