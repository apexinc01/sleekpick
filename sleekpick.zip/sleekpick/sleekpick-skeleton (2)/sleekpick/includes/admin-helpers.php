<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Admin-only helpers (product image upload + slug uniqueness).
 * Required by admin/add-product.php and admin/edit-product.php.
 */

const ADMIN_IMAGE_MAX_BYTES = 5_242_880; // 5 MB
const ADMIN_IMAGE_ALLOWED = [
    'image/png'  => 'png',
    'image/jpeg' => 'jpg',
    'image/webp' => 'webp',
];

/** Return a slug based on $baseSlug that does not collide with an existing product. */
function ensureUniqueProductSlug(string $baseSlug): string
{
    $base = $baseSlug !== '' ? $baseSlug : 'product';
    $slug = $base;
    $i = 2;
    while (dbFetchColumn('SELECT 1 FROM products WHERE slug = ? LIMIT 1', [$slug]) !== null) {
        $slug = $base . '-' . $i;
        $i++;
    }
    return $slug;
}

/**
 * Validate and store an uploaded product image.
 * Returns ['ok' => bool, 'path' => string|null, 'error' => string|null, 'skipped' => bool].
 * The stored path is relative to APP_ROOT so productImageUrl() resolves it via BASE_URL.
 */
function handleProductImageUpload(string $fieldName): array
{
    if (!isset($_FILES[$fieldName]) || ($_FILES[$fieldName]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'path' => null, 'error' => null, 'skipped' => true];
    }

    $file = $_FILES[$fieldName];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'path' => null, 'error' => 'Upload failed (error code ' . $file['error'] . '). Please try again.'];
    }
    if ($file['size'] > ADMIN_IMAGE_MAX_BYTES) {
        return ['ok' => false, 'path' => null, 'error' => 'Image must be 5 MB or smaller.'];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset(ADMIN_IMAGE_ALLOWED[$mime])) {
        return ['ok' => false, 'path' => null, 'error' => 'Only PNG, JPG and WEBP images are allowed.'];
    }

    $ext       = ADMIN_IMAGE_ALLOWED[$mime];
    $rawName   = pathinfo($file['name'], PATHINFO_FILENAME);
    $safeName  = trim(preg_replace('/[^a-zA-Z0-9_-]+/', '-', $rawName), '-') ?: 'product';
    $filename  = $safeName . '-' . bin2hex(random_bytes(4)) . '.' . $ext;

    if (!is_dir(UPLOADS_DIR)) {
        mkdir(UPLOADS_DIR, 0775, true);
    }

    $destination = UPLOADS_DIR . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return ['ok' => false, 'path' => null, 'error' => 'Could not save the uploaded image.'];
    }

    return ['ok' => true, 'path' => 'uploads/products/' . $filename, 'error' => null, 'skipped' => false];
}