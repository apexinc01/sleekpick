<?php
declare(strict_types=1);

/**
 * SLEEKPICK — App Bootstrap / Config
 *
 * Loaded first by every backend entry point (actions/, api/, and any
 * PHP page that needs sessions). Handles environment setup, session
 * start, and error visibility.
 *
 * XAMPP note: this assumes local development. Before real deployment
 * (Phase 8), APP_ENV should flip to 'production', which must disable
 * display_errors and log to a file instead (see error_log() calls).
 */

// ---------- Environment ----------
// TODO (Phase 8): read this from a real environment variable instead
// of hard-coding it, once deployment config exists.
define('APP_ENV', 'development');

if (APP_ENV === 'development') {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}

date_default_timezone_set('UTC');

// ---------- Session ----------
// Cookie hardening: not marked 'secure' yet since local XAMPP typically
// runs plain HTTP — revisit once HTTPS is in place (Phase 8).
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ---------- Base paths ----------
define('APP_ROOT', dirname(__DIR__));

// ---------- Environment file (.env) ----------
/**
 * Minimal .env reader. Keeps DB credentials out of the codebase so
 * nothing secret is ever committed. Format: KEY=value, one per line,
 * '#' starts a comment. Copy .env.example to .env to get started.
 */
function loadEnvFile(string $path): void
{
    if (!is_readable($path)) {
        return;
    }

    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);

        // Strip optional surrounding quotes.
        if (strlen($value) > 1 && ($value[0] === '"' || $value[0] === "'") && $value[0] === substr($value, -1)) {
            $value = substr($value, 1, -1);
        }

        if ($key !== '' && getenv($key) === false) {
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
}

loadEnvFile(APP_ROOT . '/.env');

/** Read an environment value with a fallback. */
function envValue(string $key, string $default = ''): string
{
    $value = getenv($key);
    if ($value === false || $value === '') {
        $value = $_ENV[$key] ?? '';
    }
    return $value === '' ? $default : (string) $value;
}

// ---------- Database credentials ----------
// Defaults match a stock XAMPP install (root / empty password).
define('DB_HOST',    envValue('DB_HOST', '127.0.0.1'));
define('DB_PORT',    envValue('DB_PORT', '3306'));
define('DB_NAME',    envValue('DB_NAME', 'sleekpick'));
define('DB_USER',    envValue('DB_USER', 'root'));
define('DB_PASS',    envValue('DB_PASS', ''));
define('DB_CHARSET', envValue('DB_CHARSET', 'utf8mb4'));

// ---------- Site paths ----------
// Base URL path of the project as served by Apache, e.g. /sleekpick.
define('BASE_URL', rtrim(envValue('BASE_URL', '/sleekpick'), '/'));
define('UPLOADS_DIR', APP_ROOT . '/uploads/products');
define('UPLOADS_URL', BASE_URL . '/uploads/products');
