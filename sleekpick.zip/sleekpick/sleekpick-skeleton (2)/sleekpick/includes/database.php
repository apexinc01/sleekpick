<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Database Layer (PDO)
 *
 * Single shared PDO connection for the whole application. Credentials
 * come from includes/config.php, which reads them out of the .env file
 * (never hard-coded, never committed).
 *
 * Every query in the project goes through the helpers below so that all
 * user input is bound as a parameter — the app must never concatenate
 * values into SQL.
 *
 * Usage:
 *   require_once __DIR__ . '/database.php';
 *   $product  = dbFetch('SELECT * FROM products WHERE slug = ?', [$slug]);
 *   $products = dbFetchAll('SELECT * FROM products WHERE is_active = 1');
 *   $id       = dbInsert('INSERT INTO categories (name, slug) VALUES (?, ?)', [$n, $s]);
 */

require_once __DIR__ . '/config.php';

/**
 * Get (and lazily create) the shared PDO connection.
 */
function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=%s',
        DB_HOST,
        DB_PORT,
        DB_NAME,
        DB_CHARSET
    );

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            // Throw on error instead of failing silently.
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Real prepared statements — the core SQL-injection defence.
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
        ]);
    } catch (PDOException $e) {
        // Never leak credentials or SQL details to the browser.
        error_log('[SLEEKPICK] Database connection failed: ' . $e->getMessage());

        if (APP_ENV === 'development') {
            http_response_code(500);
            exit(
                'Database connection failed. Check that MySQL is running in XAMPP and that '
                . 'the DB_* values in your .env file are correct. Details were written to the PHP error log.'
            );
        }

        http_response_code(500);
        exit('Service temporarily unavailable.');
    }

    return $pdo;
}

/**
 * Run a prepared statement and return the PDOStatement.
 * $params is always bound — never interpolate values into $sql.
 */
function dbQuery(string $sql, array $params = []): PDOStatement
{
    $statement = db()->prepare($sql);
    $statement->execute($params);
    return $statement;
}

/** Fetch a single row, or null when there is no match. */
function dbFetch(string $sql, array $params = []): ?array
{
    $row = dbQuery($sql, $params)->fetch();
    return $row === false ? null : $row;
}

/** Fetch every matching row. */
function dbFetchAll(string $sql, array $params = []): array
{
    return dbQuery($sql, $params)->fetchAll();
}

/** Fetch a single scalar value (first column of the first row). */
function dbFetchColumn(string $sql, array $params = []): mixed
{
    $value = dbQuery($sql, $params)->fetchColumn();
    return $value === false ? null : $value;
}

/** Run an INSERT and return the new row id. */
function dbInsert(string $sql, array $params = []): int
{
    dbQuery($sql, $params);
    return (int) db()->lastInsertId();
}

/** Run an UPDATE/DELETE and return the number of affected rows. */
function dbExecute(string $sql, array $params = []): int
{
    return dbQuery($sql, $params)->rowCount();
}

/**
 * Run a set of statements inside a transaction. Used by checkout, where
 * the order, its items, and the stock decrements must all succeed or all
 * roll back together.
 */
function dbTransaction(callable $callback): mixed
{
    $pdo = db();
    $pdo->beginTransaction();

    try {
        $result = $callback($pdo);
        $pdo->commit();
        return $result;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/**
 * Read a value from the `settings` table (admin/settings.php),
 * falling back to $default when the key is not set.
 */
function settingValue(string $key, ?string $default = null): ?string
{
    static $cache = null;

    if ($cache === null) {
        $cache = [];
        foreach (dbFetchAll('SELECT setting_key, setting_value FROM settings') as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }

    return $cache[$key] ?? $default;
}
