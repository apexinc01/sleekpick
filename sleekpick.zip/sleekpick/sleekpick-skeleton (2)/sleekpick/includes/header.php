<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Shared page head + preloader (customer site)
 *
 * Replaces the duplicated <head> blocks that each public/*.php page used
 * to carry. Pages set a few variables before including it:
 *
 *   $pageTitle       string  — <title> and og:title
 *   $pageDescription string  — meta description
 *   $activeNav       string  — 'home' | 'shop' | 'new' | 'accessories'
 *   $bodyClass       string  — optional extra body class (e.g. 'auth-page')
 *   $extraStyles     array   — optional extra stylesheet hrefs
 *
 * It then opens <body>, renders the preloader, and includes navbar.php,
 * so a page only has to include header.php then print its <main>.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$pageTitle       = $pageTitle       ?? 'SLEEKPICK — Wear the Future';
$pageDescription = $pageDescription ?? 'SLEEKPICK — futuristic fashion for people who dress like it\'s already tomorrow.';
$activeNav       = $activeNav       ?? '';
$bodyClass       = $bodyClass       ?? '';
$extraStyles     = $extraStyles     ?? [];
$showPreloader   = $showPreloader   ?? true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle); ?></title>
    <meta name="description" content="<?php echo e($pageDescription); ?>">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($pageDescription); ?>">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
<meta name="csrf-token" content="<?php echo e(csrfToken()); ?>">
<meta name="app-base" content="<?php echo e(BASE_URL); ?>">
    <!-- CSRF token for fetch() calls (assets/js/*.js reads this) -->
    <meta name="csrf-token" content="<?php echo e(csrfToken()); ?>">

    <!-- Fonts: Orbitron for display, Poppins for body -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons (exclusive icon system) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <?php foreach ($extraStyles as $href): ?>
    <link rel="stylesheet" href="<?php echo e($href); ?>">
    <?php endforeach; ?>
</head>
<body<?php echo $bodyClass !== '' ? ' class="' . e($bodyClass) . '"' : ''; ?>>

<?php if ($showPreloader): ?>
    <!-- ================= PRELOADER (falling icons handled in main.js) ================= -->
    <div id="preloader" aria-hidden="true">
        <div class="preloader-icons"></div>
        <div class="preloader-content">
            <div class="logo-mark">SLEEK<span>PICK</span></div>
            <div class="preloader-bar"></div>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/navbar.php'; ?>

<?php $__flashes = takeFlashes(); ?>
<?php if ($__flashes !== []): ?>
    <div class="flash-stack" role="status" aria-live="polite">
        <div class="container">
            <?php foreach ($__flashes as $flash): ?>
                <div class="flash flash-<?php echo e($flash['type']); ?>">
                    <i class="bi <?php echo $flash['type'] === 'error' ? 'bi-exclamation-triangle' : 'bi-check-circle'; ?>" aria-hidden="true"></i>
                    <span><?php echo $flash['message']; ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
