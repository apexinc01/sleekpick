<?php
declare(strict_types=1);

/**
 * SLEEKPICK — Site footer + script tags (customer site)
 *
 * Included as the last thing on every public/*.php page. Markup matches
 * the prototype footer so assets/css/style.css needs no changes; the
 * Account column now reflects the signed-in state, and the newsletter
 * form posts with a CSRF token.
 *
 * Pages may set $extraScripts (array of src paths) before including
 * this file, e.g. ['../assets/js/shop.js'].
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$extraScripts = $extraScripts ?? [];
$signedIn = isLoggedIn();
?>
<footer id="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-brand">
                <div class="logo">SLEEK<span style="color: var(--color-secondary);">PICK</span></div>
                <p>Futuristic fashion for people who dress like it's already tomorrow.</p>
                <div class="footer-social">
                    <a href="#" aria-label="SLEEKPICK on Instagram"><i class="bi bi-instagram"></i></a>
                    <a href="#" aria-label="SLEEKPICK on X"><i class="bi bi-twitter-x"></i></a>
                    <a href="#" aria-label="SLEEKPICK on TikTok"><i class="bi bi-tiktok"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4>Shop</h4>
                <ul>
                    <li><a href="shop.php?category=outerwear">Outerwear</a></li>
                    <li><a href="shop.php?category=essentials">Essentials</a></li>
                    <li><a href="shop.php?category=bottoms">Bottoms</a></li>
                    <li><a href="shop.php?category=accessories">Accessories</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Account</h4>
                <ul>
                    <?php if ($signedIn): ?>
                        <li><a href="account.php">Your Account</a></li>
                        <li><a href="account.php#orders">Order History</a></li>
                        <li><a href="cart.php">Cart</a></li>
                        <li><a href="logout.php">Sign Out</a></li>
                    <?php else: ?>
                        <li><a href="login.php">Sign In</a></li>
                        <li><a href="register.php">Create Account</a></li>
                        <li><a href="account.php">Order History</a></li>
                        <li><a href="cart.php">Cart</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Shipping &amp; Returns</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <span>&copy; <?php echo date('Y'); ?> SLEEKPICK. All rights reserved.</span>
            <div>
                <a href="#">Terms</a>
                <a href="#">Privacy</a>
            </div>
        </div>
    </div>
</footer>

<script src="../assets/js/main.js"></script>
<?php foreach ($extraScripts as $src): ?>
<script src="<?php echo e($src); ?>"></script>
<?php endforeach; ?>
</body>
</html>
