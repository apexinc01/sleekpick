/* ============================================================
   SLEEKPICK ADMIN — admin.js
   Admin panel interactions. Starting with the login page;
   dashboard/products/orders behavior gets added here as those
   pages are built.

   NOTE: Client-side validation only. Real authentication (role
   check for admin/editor/support, session creation, password_verify())
   happens server-side in Phase 4 via admin auth logic — never trust
   this layer alone for access control.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Password visibility toggle ---------- */
  document.querySelectorAll('.admin-password-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const wrap = btn.closest('.admin-input-wrap');
      const input = wrap ? wrap.querySelector('input') : null;
      if (!input) return;
      const icon = btn.querySelector('i');
      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');
      if (icon) icon.className = isPassword ? 'bi bi-eye-slash' : 'bi bi-eye';
    });
  });

  /* ---------- Admin login form validation ---------- */
  /* Client-side validation only. On success the browser performs a
     normal POST to the form's action (../actions/login.php). Real
     authentication, session creation and role checks happen server-side. */
  const adminLoginForm = document.querySelector('.admin-login-form');

  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', function (e) {
      let isValid = true;

      adminLoginForm.querySelectorAll('.admin-form-group').forEach(function (group) {
        const input = group.querySelector('input');
        const errorEl = group.querySelector('.admin-field-error');
        if (!input || !errorEl) return;

        let message = '';

        if (!input.value.trim()) {
          message = 'This field is required.';
        } else if (input.type === 'email') {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(input.value.trim())) message = 'Enter a valid email address.';
        }

        errorEl.textContent = message;
        if (message) isValid = false;
      });

      if (!isValid) {
        e.preventDefault();
        return;
      }

      // Valid form: do NOT call preventDefault(). Let the browser
      // submit normally (method=post, action=../actions/login.php).
    });
  }
/* ============================================================
   /* ============================================================
     ADMIN SHELL — sidebar toggle (mobile), shared across every
     interior admin page (dashboard, products, orders, customers).
     ============================================================ */
  const adminSidebar = document.querySelector('.admin-sidebar');
  const adminSidebarToggle = document.querySelector('.admin-sidebar-toggle');
  const adminSidebarBackdrop = document.querySelector('.admin-sidebar-backdrop');

  function closeAdminSidebar() {
    if (adminSidebar) adminSidebar.classList.remove('open');
    if (adminSidebarBackdrop) adminSidebarBackdrop.classList.remove('open');
  }

  if (adminSidebar && adminSidebarToggle) {
    adminSidebarToggle.addEventListener('click', function () {
      const isOpen = adminSidebar.classList.toggle('open');
      if (adminSidebarBackdrop) adminSidebarBackdrop.classList.toggle('open', isOpen);
    });

    // Close sidebar when a nav link is tapped on mobile
    adminSidebar.querySelectorAll('.admin-nav-link').forEach(function (link) {
      link.addEventListener('click', closeAdminSidebar);
    });

    // Close sidebar when the backdrop is tapped
    if (adminSidebarBackdrop) {
      adminSidebarBackdrop.addEventListener('click', closeAdminSidebar);
    }
  }
  /* ============================================================
     ADMIN ORDERS PAGE (admin/orders.php) — only runs if the
     orders table exists on the page.
     ============================================================ */
  const ordersTable = document.querySelector('.admin-orders-table');

  if (ordersTable) {
    /* Inline status update — visual only. Real persistence happens
       server-side in Phase 6 via an admin order-status endpoint. */
    ordersTable.querySelectorAll('.status-update-select').forEach(function (select) {
      select.addEventListener('change', function () {
        const row = select.closest('tr');
        const badge = row ? row.querySelector('.admin-status-badge') : null;
        if (badge) {
          const newStatus = select.value;
          badge.className = 'admin-status-badge admin-status-' + newStatus;
          badge.textContent = newStatus;
        }
      });
    });

    /* Filter bar — visual/client-side only for this static dataset.
       Real filtering becomes a server-side query in Phase 6. */
    const statusFilter = document.querySelector('.admin-filter-status');
    const searchFilter = document.querySelector('.admin-filter-search input');

    function applyOrderFilters() {
      const statusValue = statusFilter ? statusFilter.value : 'all';
      const searchValue = searchFilter ? searchFilter.value.trim().toLowerCase() : '';

      ordersTable.querySelectorAll('tbody tr').forEach(function (row) {
        const rowStatus = row.dataset.status || '';
        const rowText = row.textContent.toLowerCase();

        const matchesStatus = statusValue === 'all' || rowStatus === statusValue;
        const matchesSearch = !searchValue || rowText.indexOf(searchValue) !== -1;

        row.style.display = (matchesStatus && matchesSearch) ? '' : 'none';
      });
    }

    if (statusFilter) statusFilter.addEventListener('change', applyOrderFilters);
    if (searchFilter) searchFilter.addEventListener('input', applyOrderFilters);
  }

  /* NOTE: the old products-page block that used to live here (select-all,
     a window.confirm() "delete", and client-side search/category/status
     filtering of already-rendered rows) has been removed. admin/products.php
     now filters server-side via real GET params (same pattern as the
     orders page above), and archive/activate is wired for real further
     down in this file, in the section that already has the toast()
     helper and calls the actual actions/admin-product-status.php endpoint. */

});

/* ============================================================
   SLEEKPICK ADMIN — shared polish and demo interactions
   These interactions keep the uploaded design prototype usable while
   server-side persistence is connected. No secrets or credentials are
   stored in the browser.
   ============================================================ */
(function () {
  'use strict';

  function toast(message, tone) {
    const region = document.querySelector('[data-admin-toast-region]');
    if (!region) return;
    const item = document.createElement('div');
    item.className = 'admin-toast admin-toast-' + (tone || 'info');
    item.innerHTML = '<i class="bi bi-' + (tone === 'success' ? 'check-circle' : tone === 'danger' ? 'exclamation-triangle' : 'info-circle') + '"></i><span></span><button type="button" aria-label="Dismiss notification"><i class="bi bi-x"></i></button>';
    item.querySelector('span').textContent = message;
    item.querySelector('button').addEventListener('click', function () { item.remove(); });
    region.appendChild(item);
    window.setTimeout(function () { item.classList.add('is-leaving'); window.setTimeout(function () { item.remove(); }, 220); }, 3600);
  }

  function readStorage(key, fallback) {
    try {
      const value = window.localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      toast('Browser demo storage is unavailable.', 'danger');
    }
  }

  function csvDownload(filename, rows) {
    const csv = rows.map(function (row) {
      return row.map(function (cell) {
        return '"' + String(cell ?? '').replace(/"/g, '""') + '"';
      }).join(',');
    }).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(link.href);
  }

  function closePopover(popover) {
    if (!popover) return;
    popover.hidden = true;
    const trigger = popover.previousElementSibling;
    if (trigger) trigger.setAttribute('aria-expanded', 'false');
  }

  function validateForm(form) {
    let valid = true;
    form.querySelectorAll('.admin-form-group').forEach(function (group) {
      const input = group.querySelector('input, select, textarea');
      const error = group.querySelector('.admin-field-error');
      if (!input || !error) return;
      let message = '';
      if (input.required && !String(input.value).trim()) message = 'This field is required.';
      if (!message && input.type === 'number' && Number(input.value) < 0) message = 'Enter a value of zero or more.';
      if (!message && input.type === 'email' && input.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) message = 'Enter a valid email address.';
      error.textContent = message;
      group.classList.toggle('has-error', Boolean(message));
      if (message) valid = false;
    });
    return valid;
  }

  function updateCharacterCount(input) {
    const group = input.closest('.admin-form-group');
    const counter = group ? group.querySelector('[data-character-count]') : null;
    if (counter) counter.textContent = String(input.value.length);
  }

  document.addEventListener('DOMContentLoaded', function () {
    /* ---------- Shared popovers ---------- */
    document.querySelectorAll('[data-admin-profile], [data-admin-notifications]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        const menu = trigger.matches('[data-admin-profile]')
          ? document.querySelector('[data-admin-profile-menu]')
          : document.querySelector('[data-admin-notifications-menu]');
        const other = trigger.matches('[data-admin-profile]')
          ? document.querySelector('[data-admin-notifications-menu]')
          : document.querySelector('[data-admin-profile-menu]');
        closePopover(other);
        if (!menu) return;
        menu.hidden = !menu.hidden;
        trigger.setAttribute('aria-expanded', String(!menu.hidden));
      });
    });

    document.addEventListener('click', function (event) {
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (!target.closest('[data-admin-profile], [data-admin-notifications], [data-admin-profile-menu], [data-admin-notifications-menu]')) {
        closePopover(document.querySelector('[data-admin-profile-menu]'));
        closePopover(document.querySelector('[data-admin-notifications-menu]'));
      }
    });

    document.querySelectorAll('[data-admin-notifications-menu] a').forEach(function (link) {
      link.addEventListener('click', function () { closePopover(link.closest('[data-admin-notifications-menu]')); });
    });

    /* ---------- Global admin search ---------- */
    const globalSearch = document.querySelector('[data-admin-global-search]');
    if (globalSearch) {
      globalSearch.addEventListener('input', function () {
        const value = globalSearch.value.trim();
        const localTarget = document.querySelector('[data-product-search], [data-order-search], [data-customer-search], [data-category-search]');
        if (!localTarget) return;
        localTarget.value = value;
        localTarget.dispatchEvent(new Event('input', { bubbles: true }));
      });
    }

    /* ---------- Modal dialog ---------- */
    function closeModal(modal) {
      if (!modal) return;
      modal.hidden = true;
      document.body.classList.remove('modal-is-open');
    }

    document.querySelectorAll('[data-open-modal]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        const modal = document.querySelector('[data-modal="' + trigger.dataset.openModal + '"]');
        if (!modal) return;
        modal.hidden = false;
        document.body.classList.add('modal-is-open');
        const firstInput = modal.querySelector('input, select, textarea');
        if (firstInput) window.setTimeout(function () { firstInput.focus(); }, 50);
      });
    });
    document.querySelectorAll('[data-close-modal]').forEach(function (trigger) {
      trigger.addEventListener('click', function () { closeModal(trigger.closest('.admin-modal-backdrop')); });
    });
    document.querySelectorAll('.admin-modal-backdrop').forEach(function (backdrop) {
      backdrop.addEventListener('click', function (event) {
        if (event.target === backdrop) closeModal(backdrop);
      });
    });
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      closeModal(document.querySelector('.admin-modal-backdrop:not([hidden])'));
    });

    /* ---------- Character counters and image preview ---------- */
    document.querySelectorAll('[maxlength]').forEach(function (input) {
      if (input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement) {
        updateCharacterCount(input);
        input.addEventListener('input', function () { updateCharacterCount(input); });
      }
    });
    document.querySelectorAll('[data-color-input]').forEach(function (input) {
      const value = input.closest('.admin-color-picker')?.querySelector('[data-color-value]');
      const update = function () { if (value) value.textContent = input.value.toUpperCase(); };
      input.addEventListener('input', update);
      update();
    });
    document.querySelectorAll('[data-image-input]').forEach(function (input) {
      input.addEventListener('change', function () {
        const file = input.files && input.files[0];
        const preview = input.closest('.admin-card')?.querySelector('[data-image-preview]');
        const image = preview?.querySelector('img');
        if (!file || !preview || !image) return;
        if (!/^image\/(png|jpe?g|webp)$/.test(file.type) || file.size > 5 * 1024 * 1024) {
          input.value = '';
          toast('Choose a PNG, JPG, or WebP image under 5MB.', 'danger');
          return;
        }
        image.src = URL.createObjectURL(file);
        preview.hidden = false;
      });
    });
    document.querySelectorAll('[data-clear-image]').forEach(function (button) {
      button.addEventListener('click', function () {
        const card = button.closest('.admin-card');
        const input = card?.querySelector('[data-image-input]');
        const preview = card?.querySelector('[data-image-preview]');
        if (input) input.value = '';
        if (preview) preview.hidden = true;
      });
    });

        /* ---------- Categories (real backend) ---------- */
    const categoryForm = document.querySelector('[data-category-form]');
    categoryForm?.addEventListener('submit', function (event) {
      if (!validateForm(categoryForm)) {
        event.preventDefault();
      }
      // Valid form: no preventDefault — posts to actions/admin-category-save.php
    });

    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    const categoryCsrf = csrfMeta ? csrfMeta.getAttribute('content') : '';

    document.querySelectorAll('[data-category-toggle]').forEach(function (button) {
      button.addEventListener('click', function () {
        const row = button.closest('[data-category-row]');
        const categoryId = button.dataset.categoryToggle || (row ? row.dataset.categoryId : null);
        const nextState = Number(button.dataset.nextState);
        if (!categoryId || !row || (nextState !== 0 && nextState !== 1)) return;

        const nameEl = row.querySelector('h2');
        const label = nameEl ? nameEl.textContent : 'this category';
        const action = nextState === 1 ? 'show' : 'hide';
        if (!window.confirm('Are you sure you want to ' + action + ' "' + label + '"?')) {
          return;
        }

        button.disabled = true;

        fetch('../actions/admin-category-status.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            category_id: Number(categoryId),
            is_active: nextState,
            csrf_token: categoryCsrf,
          }),
        })
          .then(function (response) { return response.json(); })
          .then(function (data) {
            if (!data.success) {
              toast(data.message || 'Could not update that category.', 'danger');
              button.disabled = false;
              return;
            }

            toast(data.message, 'success');

            const newStatus = nextState === 1 ? 'active' : 'hidden';
            row.dataset.status = newStatus;

            const badge = row.querySelector('.admin-status-badge');
            if (badge) {
              badge.className = 'admin-status-badge admin-status-' + newStatus;
              badge.textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
            }

            const icon = button.querySelector('i');
            if (icon) icon.className = nextState === 1 ? 'bi bi-eye-slash' : 'bi bi-eye';
            button.dataset.nextState = nextState === 1 ? '0' : '1';
            button.setAttribute('aria-label', (nextState === 1 ? 'Hide ' : 'Show ') + label);

            const cardIcon = row.querySelector('.admin-category-icon i');
            if (cardIcon) cardIcon.className = 'bi bi-' + (nextState === 1 ? 'layers' : 'archive');

            button.disabled = false;
          })
          .catch(function () {
            toast('Network error — please try again.', 'danger');
            button.disabled = false;
          });
      });
    });

    /* ---------- Customers ---------- */
    const customerSearch = document.querySelector('[data-customer-search]');
    const customerStatus = document.querySelector('[data-customer-status]');
    const customerRows = document.querySelectorAll('[data-customer-row]');
    const customerEmpty = document.querySelector('[data-customer-empty]');
    const customerResults = document.querySelector('[data-customer-results]');
    
    function applyCustomerFilters() {
      if (!customerRows.length) return;
      const search = customerSearch?.value.trim().toLowerCase() || '';
      const status = customerStatus?.value || 'all';
      let visible = 0;
      customerRows.forEach(function (row) {
        const matchesSearch = !search || row.textContent.toLowerCase().includes(search);
        const matchesStatus = status === 'all' || row.dataset.status === status;
        row.hidden = !(matchesSearch && matchesStatus);
        if (!row.hidden) visible += 1;
      });
      if (customerResults) customerResults.textContent = 'Showing ' + visible + ' customer' + (visible === 1 ? '' : 's');
      if (customerEmpty) customerEmpty.hidden = visible !== 0;
    }
    customerSearch?.addEventListener('input', applyCustomerFilters);
    customerStatus?.addEventListener('change', applyCustomerFilters);
    document.querySelectorAll('[data-customer-view]').forEach(function (button) {
      button.addEventListener('click', function () {
        const row = button.closest('tr');
        const name = row?.querySelector('strong')?.textContent || 'Customer';
        toast('Customer profile for ' + name + ' is ready for the detail endpoint.', 'info');
      });
    });
    document.querySelector('[data-export-customers]')?.addEventListener('click', function () {
      const rows = [['Name', 'Email', 'Location', 'Orders', 'Total spent', 'Joined', 'Status']];
      document.querySelectorAll('[data-customer-row]:not([hidden])').forEach(function (row) {
        const cells = row.querySelectorAll('td');
        rows.push([cells[0]?.innerText.replace(/\n/g, ' '), cells[1]?.innerText, cells[2]?.innerText, cells[3]?.innerText, cells[4]?.innerText, cells[5]?.innerText]);
      });
      csvDownload('sleekpick-customers.csv', rows);
      toast('Customer CSV downloaded.', 'success');
    });

    document.querySelector('[data-export-orders]')?.addEventListener('click', function () {
      const rows = [['Order', 'Customer', 'Date', 'Items', 'Total', 'Status']];
      document.querySelectorAll('.admin-orders-table tbody tr:not([hidden])').forEach(function (row) {
        const cells = row.querySelectorAll('td');
        rows.push([cells[0]?.innerText, cells[1]?.innerText.replace(/\n/g, ' '), cells[2]?.innerText, cells[3]?.innerText, cells[4]?.innerText, cells[5]?.innerText]);
      });
      csvDownload('sleekpick-orders.csv', rows);
      toast('Orders CSV downloaded.', 'success');
    });

    /* NOTE: admin/add-product.php and admin/edit-product.php already
       submit as real HTML forms straight to PHP (validation, MySQL
       insert/update, image upload — see includes/admin-helpers.php).
       A JS submit-interceptor used to live here that called
       event.preventDefault() and wrote the product into
       localStorage instead — that was silently swallowing the real
       form submission and faking success. Removed: the form now
       submits normally to the server. Client-side validation still
       runs via validateForm() below so bad input is caught before
       the request is even sent. */
    const productForm = document.querySelector('[data-product-form]');
    productForm?.addEventListener('submit', function (event) {
      if (!validateForm(productForm)) {
        event.preventDefault();
      }
      // No preventDefault() on the success path — let the real POST through.
    });

    /* ---------- Product archive / activate (real backend call) ---------- */
    const productsTable = document.querySelector('.admin-products-table');
    if (productsTable) {
      const csrfMeta = document.querySelector('meta[name="csrf-token"]');
      const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

      productsTable.addEventListener('click', function (event) {
        const target = event.target;
        if (!(target instanceof Element)) return;
        const button = target.closest('[data-product-toggle]');
        if (!button) return;

        const row = button.closest('tr[data-product-id]');
        const productId = button.dataset.productToggle;
        const nextState = Number(button.dataset.nextState);
        const nameEl = row ? row.querySelector('.product-cell-info strong') : null;
        const label = nameEl ? nameEl.textContent : 'this product';
        const action = nextState === 1 ? 'activate' : 'archive';

        if (!window.confirm('Are you sure you want to ' + action + ' "' + label + '"?')) {
          return;
        }

        button.disabled = true;

        fetch('../actions/admin-product-status.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            product_id: productId,
            is_active: nextState,
            csrf_token: csrfToken,
          }),
        })
          .then(function (response) { return response.json(); })
          .then(function (data) {
            if (!data.success) {
              toast(data.message || 'Could not update that product.', 'danger');
              button.disabled = false;
              return;
            }

            toast(data.message, 'success');

            if (row) {
              const badge = row.querySelector('.admin-status-badge');
              if (badge) {
                const newStatus = nextState === 1 ? 'active' : 'archived';
                badge.className = 'admin-status-badge admin-status-' + newStatus;
                badge.textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
                row.dataset.status = newStatus;
              }

              const icon = button.querySelector('i');
              if (icon) icon.className = nextState === 1 ? 'bi bi-arrow-counterclockwise' : 'bi bi-archive';
              button.dataset.nextState = nextState === 1 ? '0' : '1';
              button.setAttribute('aria-label', (nextState === 1 ? 'Archive ' : 'Activate ') + label);
            }

            button.disabled = false;
          })
          .catch(function () {
            toast('Network error — please try again.', 'danger');
            button.disabled = false;
          });
      });
    }

    /* ---------- Settings ---------- */
       /* ---------- Settings ---------- */
    // Tab switching only. Save is a normal form POST to
    // actions/admin-settings-save.php (header button uses form="settings-form").
    document.querySelectorAll('[data-settings-tab]').forEach(function (tab) {
      tab.addEventListener('click', function () {
        const key = tab.dataset.settingsTab;
        document.querySelectorAll('[data-settings-tab]').forEach(function (item) {
          item.classList.toggle('active', item === tab);
        });
        document.querySelectorAll('[data-settings-panel]').forEach(function (panel) {
          const active = panel.dataset.settingsPanel === key;
          panel.hidden = !active;
          panel.classList.toggle('active', active);
        });
      });
    });



  });
}());