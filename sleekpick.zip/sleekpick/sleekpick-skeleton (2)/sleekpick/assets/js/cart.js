/* ============================================================
   SLEEKPICK — cart.js
   Product detail, shop add-to-cart, cart page, checkout.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Gallery: thumbnail swaps main image ---------- */
  const mainImage = document.querySelector('.gallery-main img');
  document.querySelectorAll('.gallery-thumb').forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      const newSrc = thumb.querySelector('img').getAttribute('src');
      if (mainImage && newSrc) {
        mainImage.style.opacity = '0';
        setTimeout(function () {
          mainImage.setAttribute('src', newSrc);
          mainImage.style.opacity = '1';
        }, 150);
      }
      document.querySelectorAll('.gallery-thumb').forEach(function (t) { t.classList.remove('active'); });
      thumb.classList.add('active');
    });
  });

  /* ---------- Size selection ---------- */
  const sizeButtons = document.querySelectorAll('.detail-size-options .size-btn');
  const sizeValueLabel = document.querySelector('[data-selected="size"]');

  sizeButtons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      sizeButtons.forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      if (sizeValueLabel) sizeValueLabel.textContent = btn.textContent.trim();
      const detailBtn = document.querySelector('.product-info-panel .add-to-cart-btn');
      if (detailBtn) detailBtn.setAttribute('data-size', btn.textContent.trim());
    });
  });

  /* ---------- Color selection ---------- */
  const colorSwatches = document.querySelectorAll('.detail-color-options .color-swatch');
  const colorValueLabel = document.querySelector('[data-selected="color"]');

  colorSwatches.forEach(function (swatch) {
    swatch.addEventListener('click', function () {
      colorSwatches.forEach(function (s) { s.classList.remove('active'); });
      swatch.classList.add('active');
      if (colorValueLabel) colorValueLabel.textContent = swatch.dataset.label || '';
      const detailBtn = document.querySelector('.product-info-panel .add-to-cart-btn');
      if (detailBtn) detailBtn.setAttribute('data-color', swatch.dataset.label || '');
    });
  });

  /* ---------- Quantity stepper (product detail) ---------- */
  const qtyInput = document.querySelector('.qty-stepper input');
  const qtyDecrease = document.querySelector('.qty-stepper .qty-decrease');
  const qtyIncrease = document.querySelector('.qty-stepper .qty-increase');
  const MAX_QTY = 10;

  if (qtyInput && qtyDecrease && qtyIncrease) {
    qtyDecrease.addEventListener('click', function () {
      const current = parseInt(qtyInput.value, 10) || 1;
      qtyInput.value = String(Math.max(1, current - 1));
    });

    qtyIncrease.addEventListener('click', function () {
      const current = parseInt(qtyInput.value, 10) || 1;
      qtyInput.value = String(Math.min(MAX_QTY, current + 1));
    });

    qtyInput.addEventListener('change', function () {
      let value = parseInt(qtyInput.value, 10);
      if (isNaN(value) || value < 1) value = 1;
      if (value > MAX_QTY) value = MAX_QTY;
      qtyInput.value = String(value);
    });
  }

  /* ---------- Tabs ---------- */
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      const target = btn.dataset.tab;

      tabButtons.forEach(function (b) { b.classList.remove('active'); });
      tabPanels.forEach(function (p) { p.classList.remove('active'); });

      btn.classList.add('active');
      const panel = document.querySelector('.tab-panel[data-tab="' + target + '"]');
      if (panel) panel.classList.add('active');
    });
  });

  /* ---------- Add to cart (shop + product detail) ---------- */
  const csrfMeta = document.querySelector('meta[name="csrf-token"]');
  const pageCsrf = csrfMeta ? csrfMeta.getAttribute('content') : '';
  const appBaseMeta = document.querySelector('meta[name="app-base"]');
  const appBase = appBaseMeta ? (appBaseMeta.getAttribute('content') || '').replace(/\/$/, '') : '';

  function actionsUrl(file) {
    if (appBase) return appBase + '/actions/' + file;
    const path = window.location.pathname;
    if (path.indexOf('/public/') !== -1) {
      return path.replace(/\/public\/.*$/, '/actions/' + file);
    }
    return '../actions/' + file;
  }

  function updateCartBadges(count) {
    document.querySelectorAll('.cart-count').forEach(function (el) {
      el.textContent = String(count);
      if (count > 0) el.removeAttribute('hidden');
      else el.setAttribute('hidden', 'hidden');
    });
  }

  function resolveSizeColor(button) {
    const activeSize = document.querySelector('.detail-size-options .size-btn.active');
    const activeColor = document.querySelector('.detail-color-options .color-swatch.active');
    const size = (activeSize && activeSize.textContent.trim())
      || button.getAttribute('data-size')
      || 'One Size';
    const color = (activeColor && (activeColor.getAttribute('data-label') || activeColor.getAttribute('aria-label')))
      || button.getAttribute('data-color')
      || 'Default';
    return { size: size, color: color };
  }

  function addToCartFromButton(button) {
    if (button.disabled) return;

    const productId = parseInt(button.getAttribute('data-product-id') || '0', 10);
    if (!productId) {
      window.alert('Product is missing an id.');
      return;
    }

    const variant = resolveSizeColor(button);
    const qtyField = document.querySelector('.product-info-panel .qty-stepper input');
    const quantity = qtyField ? (parseInt(qtyField.value, 10) || 1) : 1;

    const originalText = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<i class="bi bi-hourglass-split"></i> Adding…';

    fetch(actionsUrl('add-to-cart.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Requested-With': 'fetch',
        'X-CSRF-Token': pageCsrf || '',
      },
      body: JSON.stringify({
        productId: productId,
        size: variant.size,
        color: variant.color,
        quantity: quantity,
        csrf_token: pageCsrf,
      }),
    })
      .then(function (response) { return response.json(); })
      .then(function (data) {
        if (!data.success) {
          window.alert(data.message || 'Could not add to cart.');
          button.disabled = false;
          button.innerHTML = originalText;
          return;
        }

        if (typeof data.cartCount === 'number') {
          updateCartBadges(data.cartCount);
        }

        button.innerHTML = '<i class="bi bi-check-lg"></i> Added';
        window.setTimeout(function () {
          button.innerHTML = originalText;
          button.disabled = false;
        }, 1200);
      })
      .catch(function () {
        window.alert('Network error — please try again.');
        button.disabled = false;
        button.innerHTML = originalText;
      });
  }

  const detailAddBtn = document.querySelector('.product-info-panel .add-to-cart-btn');
  if (detailAddBtn) {
    detailAddBtn.addEventListener('click', function () {
      addToCartFromButton(detailAddBtn);
    });
  }

  document.querySelectorAll('.add-to-cart-btn').forEach(function (button) {
    if (detailAddBtn && button === detailAddBtn) return;
    button.addEventListener('click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      addToCartFromButton(button);
    });
  });

  /* ---------- Wishlist toggle on detail page ---------- */
  const detailWishlistBtn = document.querySelector('.detail-wishlist-btn');
  if (detailWishlistBtn) {
    detailWishlistBtn.addEventListener('click', function () {
      const active = detailWishlistBtn.classList.toggle('active');
      const icon = detailWishlistBtn.querySelector('i');
      if (icon) icon.className = active ? 'bi bi-heart-fill' : 'bi bi-heart';
      detailWishlistBtn.setAttribute('aria-pressed', String(active));
    });
  }

  /* ============================================================
     CART PAGE (cart.php)
     ============================================================ */
  const cartItemsWrap = document.querySelector('.cart-items');

  if (cartItemsWrap) {
    const cartSection = document.querySelector('.cart-section');
    const FREE_SHIPPING_THRESHOLD = parseFloat(cartSection?.dataset.freeShipping || '80');
    const SHIPPING_COST = parseFloat(cartSection?.dataset.shippingRate || '9.99');
    const MAX_ITEM_QTY = 10;
    const cartCsrfMeta = document.querySelector('meta[name="csrf-token"]');
    const csrfToken = cartCsrfMeta ? cartCsrfMeta.getAttribute('content') : '';

    function money(n) {
      return '$' + Number(n).toFixed(2);
    }

    function updateHeaderBadge(count) {
      document.querySelectorAll('.cart-count').forEach(function (el) {
        el.textContent = String(count);
        if (count > 0) el.removeAttribute('hidden');
        else el.setAttribute('hidden', 'hidden');
      });
    }

    function applyServerTotals(data, lineItem) {
      if (lineItem && typeof data.lineTotal === 'number') {
        const lineTotalEl = lineItem.querySelector('.line-total');
        if (lineTotalEl) lineTotalEl.textContent = money(data.lineTotal);
      }

      const subtotal = typeof data.cartSubtotal === 'number' ? data.cartSubtotal : null;
      if (subtotal !== null) {
        const shipping = subtotal >= FREE_SHIPPING_THRESHOLD || subtotal === 0 ? 0 : SHIPPING_COST;
        const total = subtotal + shipping;
        const subtotalEl = document.querySelector('.summary-subtotal');
        const shippingEl = document.querySelector('.summary-shipping');
        const totalEl = document.querySelector('.summary-total');
        const hint = document.querySelector('.free-shipping-hint');
        const remaining = document.querySelector('.free-shipping-remaining');

        if (subtotalEl) subtotalEl.textContent = money(subtotal);
        if (shippingEl) shippingEl.textContent = shipping === 0 ? 'Free' : money(shipping);
        if (totalEl) totalEl.textContent = money(total);

        if (hint) {
          const need = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
          if (need > 0 && subtotal > 0) {
            hint.hidden = false;
            if (remaining) remaining.textContent = money(need);
          } else {
            hint.hidden = true;
          }
        }
      }

      if (typeof data.cartCount === 'number') {
        updateHeaderBadge(data.cartCount);
      }

      if (data.cartEmpty || data.removed) {
        const emptyState = document.querySelector('.empty-cart');
        const cartLayout = document.querySelector('.cart-layout');
        const stillHas = cartItemsWrap.querySelectorAll('.cart-item').length > 0;
        if (!stillHas || data.cartEmpty) {
          if (emptyState) emptyState.hidden = false;
          if (cartLayout) cartLayout.hidden = true;
        }
      }
    }

    function postCart(url, body) {
      return fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Requested-With': 'fetch',
          'X-CSRF-Token': csrfToken || '',
        },
        body: JSON.stringify(Object.assign({ csrf_token: csrfToken }, body)),
      }).then(function (response) { return response.json(); });
    }

    function updateQuantity(item, quantity) {
      const key = item.dataset.key;
      if (!key) return;

      postCart(actionsUrl('update-cart.php'), { key: key, quantity: quantity })
        .then(function (data) {
          if (!data.success) {
            window.alert(data.message || 'Could not update cart.');
            return;
          }

          const input = item.querySelector('.qty-stepper input');
          if (data.removed || quantity === 0) {
            item.remove();
            applyServerTotals(data);
            return;
          }

          if (input && typeof data.quantity === 'number') {
            input.value = String(data.quantity);
          }
          applyServerTotals(data, item);
        })
        .catch(function () {
          window.alert('Network error — please try again.');
        });
    }

    function removeItem(item) {
      const key = item.dataset.key;
      if (!key) return;

      postCart(actionsUrl('remove-from-cart.php'), { key: key })
        .then(function (data) {
          if (!data.success) {
            window.alert(data.message || 'Could not remove item.');
            return;
          }
          item.classList.add('removing');
          window.setTimeout(function () {
            item.remove();
            applyServerTotals(Object.assign({}, data, { removed: true }));
          }, 200);
        })
        .catch(function () {
          window.alert('Network error — please try again.');
        });
    }

    cartItemsWrap.querySelectorAll('.cart-item').forEach(function (item) {
      const input = item.querySelector('.qty-stepper input');
      const decreaseBtn = item.querySelector('.qty-decrease');
      const increaseBtn = item.querySelector('.qty-increase');

      if (decreaseBtn && input) {
        decreaseBtn.addEventListener('click', function () {
          const current = parseInt(input.value, 10) || 1;
          const next = Math.max(1, current - 1);
          if (next === current) return;
          updateQuantity(item, next);
        });
      }

      if (increaseBtn && input) {
        increaseBtn.addEventListener('click', function () {
          const current = parseInt(input.value, 10) || 1;
          const next = Math.min(MAX_ITEM_QTY, current + 1);
          if (next === current) return;
          updateQuantity(item, next);
        });
      }

      if (input) {
        input.addEventListener('change', function () {
          let value = parseInt(input.value, 10);
          if (isNaN(value) || value < 1) value = 1;
          if (value > MAX_ITEM_QTY) value = MAX_ITEM_QTY;
          input.value = String(value);
          updateQuantity(item, value);
        });
      }

      const removeBtn = item.querySelector('.remove-item-btn');
      if (removeBtn) {
        removeBtn.addEventListener('click', function () {
          removeItem(item);
        });
      }
    });
  }

  /* ============================================================
     CHECKOUT PAGE (checkout.php)
     ============================================================ */
  const checkoutLayout = document.querySelector('.checkout-layout');

  if (checkoutLayout) {
    const newAddressToggle = document.querySelector('.new-address-toggle');
    const newAddressForm = document.querySelector('.new-address-form');
    const checkoutForm = document.querySelector('.checkout-form');

    if (newAddressToggle && newAddressForm) {
      newAddressToggle.addEventListener('click', function () {
        newAddressForm.classList.toggle('open');
        const isOpen = newAddressForm.classList.contains('open');
        newAddressToggle.innerHTML = isOpen
          ? '<i class="bi bi-dash-circle"></i> Use a saved address'
          : '<i class="bi bi-plus-circle"></i> Use a different address';

        newAddressForm.querySelectorAll('input[name="full_name"], input[name="line1"], input[name="city"], input[name="country"]').forEach(function (input) {
          if (isOpen) input.setAttribute('required', 'required');
          else input.removeAttribute('required');
        });
      });
    }

    document.querySelectorAll('input[name="saved_address_id"]').forEach(function (radio) {
      radio.addEventListener('change', function () {
        if (!radio.checked) return;
        const map = {
          full_name: radio.dataset.fullName || '',
          line1: radio.dataset.line1 || '',
          line2: radio.dataset.line2 || '',
          city: radio.dataset.city || '',
          state: radio.dataset.state || '',
          postal_code: radio.dataset.postal || '',
          country: radio.dataset.country || 'Nigeria',
        };
        Object.keys(map).forEach(function (name) {
          const field = checkoutForm ? checkoutForm.querySelector('[name="' + name + '"]') : null;
          if (field) field.value = map[name];
        });
        if (radio.dataset.phone) {
          const phone = checkoutForm ? checkoutForm.querySelector('[name="phone"]') : null;
          if (phone && !phone.value.trim()) phone.value = radio.dataset.phone;
        }
        if (newAddressForm) newAddressForm.classList.remove('open');
      });
    });

    const checkedSaved = document.querySelector('input[name="saved_address_id"]:checked');
    if (checkedSaved) {
      checkedSaved.dispatchEvent(new Event('change'));
    }

    if (checkoutForm) {
      checkoutForm.addEventListener('submit', function (e) {
        e.preventDefault();

        let isValid = true;
        const usingSaved = document.querySelector('input[name="saved_address_id"]:checked')
          && !(newAddressForm && newAddressForm.classList.contains('open'));

        checkoutForm.querySelectorAll('input[required], textarea[required]').forEach(function (input) {
          if (input.type === 'radio') return;
          if (usingSaved && newAddressForm && newAddressForm.contains(input) && input.name !== 'country') {
            return;
          }
          if (!String(input.value || '').trim()) {
            input.style.borderColor = 'var(--color-primary)';
            isValid = false;
          } else {
            input.style.borderColor = '';
          }
        });

        if (!isValid) {
          window.alert('Please fill in the required fields.');
          return;
        }

        const formData = new FormData(checkoutForm);
        const payload = {};
        formData.forEach(function (value, key) {
          payload[key] = value;
        });

        const saved = document.querySelector('input[name="saved_address_id"]:checked');
        if (saved && !(newAddressForm && newAddressForm.classList.contains('open'))) {
          payload.full_name = saved.dataset.fullName || payload.full_name || '';
          payload.line1 = saved.dataset.line1 || payload.line1 || '';
          payload.line2 = saved.dataset.line2 || payload.line2 || '';
          payload.city = saved.dataset.city || payload.city || '';
          payload.state = saved.dataset.state || payload.state || '';
          payload.postal_code = saved.dataset.postal || payload.postal_code || '';
          payload.country = saved.dataset.country || payload.country || 'Nigeria';
          if (!payload.phone && saved.dataset.phone) payload.phone = saved.dataset.phone;
        }

        const submitBtn = checkoutForm.querySelector('.place-order-btn');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Placing order…';
        }

        fetch(checkoutForm.action || actionsUrl('place-order.php'), {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Requested-With': 'fetch',
            'X-CSRF-Token': pageCsrf || '',
          },
          body: JSON.stringify(payload),
        })
          .then(function (response) { return response.json(); })
          .then(function (data) {
            if (!data.success) {
              window.alert(data.message || 'Could not place the order.');
              if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="bi bi-lock-fill"></i> Place Order';
              }
              return;
            }
            document.querySelectorAll('.cart-count').forEach(function (el) {
              el.textContent = '0';
            });
            window.location.href = data.redirect || ('account.php?order=' + encodeURIComponent(data.orderNumber || ''));
          })
          .catch(function () {
            window.alert('Network error — please try again.');
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = '<i class="bi bi-lock-fill"></i> Place Order';
            }
          });
      });
    }
  }

});