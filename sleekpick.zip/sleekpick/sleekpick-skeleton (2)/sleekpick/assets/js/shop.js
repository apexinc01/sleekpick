/* ============================================================
   SLEEKPICK — shop.js
   Shop/listing page interactions: mobile filter drawer, size/color
   toggles, active-filter chips, AND real client-side filtering +
   sorting of the product grid.

   NOTE: This filters/sorts the DOM nodes already rendered by PHP.
   In Phase 4, once shop.php reads real data from the database, this
   same UI will instead build query params and reload/fetch results
   server-side — but the interaction pattern here stays the same.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  const filterBtn = document.querySelector('.mobile-filter-btn');
  const sidebar = document.querySelector('.filters-sidebar');
  const backdrop = document.querySelector('.filter-drawer-backdrop');
  const closeBtn = document.querySelector('.filter-drawer-close');
  const filterBadge = document.querySelector('.mobile-filter-btn .filter-badge');
  const activeFiltersBar = document.querySelector('.active-filters');
  const clearAllBtn = document.querySelector('.clear-filters');
  const clearAllInlineBtn = document.querySelector('.clear-filters-inline');

  const grid = document.getElementById('shop-product-grid');
  const resultsCount = document.getElementById('shop-results-count');
  const noResultsMsg = document.querySelector('.shop-no-results');
  const sortSelect = document.getElementById('shop-sort-select');
  const priceMinInput = document.getElementById('price-min');
  const priceMaxInput = document.getElementById('price-max');
  const applyPriceBtn = document.querySelector('.apply-price-btn');

  if (!grid) return; // Safety: nothing to filter if the grid isn't on this page.

  const cards = Array.from(grid.querySelectorAll('.product-card'));

  /* ---------- Open/close mobile filter drawer ---------- */
  function openDrawer() {
    if (sidebar) sidebar.classList.add('open');
    if (backdrop) backdrop.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    if (sidebar) sidebar.classList.remove('open');
    if (backdrop) backdrop.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (filterBtn) filterBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (backdrop) backdrop.addEventListener('click', closeDrawer);

  /* ---------- Toggle listeners (each just re-runs the filter pass) ---------- */
  document.querySelectorAll('.size-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      btn.classList.toggle('active');
      applyShopFiltersAndSort();
    });
  });

  document.querySelectorAll('.color-swatch').forEach(function (swatch) {
    swatch.addEventListener('click', function () {
      swatch.classList.toggle('active');
      applyShopFiltersAndSort();
    });
  });

  document.querySelectorAll('.filter-option input[type="checkbox"]').forEach(function (cb) {
    cb.addEventListener('change', applyShopFiltersAndSort);
  });

  if (applyPriceBtn) {
    applyPriceBtn.addEventListener('click', applyShopFiltersAndSort);
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', applyShopFiltersAndSort);
  }

  /* ---------- Read current filter state from the UI ---------- */
  function getActiveFilters() {
    const categories = Array.from(document.querySelectorAll('.filter-option input[type="checkbox"]:checked'))
      .map(function (cb) { return cb.value; });

    const sizes = Array.from(document.querySelectorAll('.size-btn.active'))
      .map(function (btn) { return btn.textContent.trim(); });

    const colors = Array.from(document.querySelectorAll('.color-swatch.active'))
      .map(function (sw) { return sw.dataset.label; });

    const priceMin = priceMinInput && priceMinInput.value ? parseFloat(priceMinInput.value) : null;
    const priceMax = priceMaxInput && priceMaxInput.value ? parseFloat(priceMaxInput.value) : null;

    return { categories, sizes, colors, priceMin, priceMax };
  }

  /* ---------- Does a single card match the current filters? ---------- */
  function cardMatches(card, filters) {
    const cardCategory = card.dataset.category || '';
    const cardPrice = parseFloat(card.dataset.price || '0');
    const cardSizes = (card.dataset.sizes || '').split(',').filter(Boolean);
    const cardColors = (card.dataset.colors || '').split(',').filter(Boolean);

    if (filters.categories.length && filters.categories.indexOf(cardCategory) === -1) return false;

    if (filters.sizes.length && !filters.sizes.some(function (s) { return cardSizes.indexOf(s) !== -1; })) return false;

    if (filters.colors.length && !filters.colors.some(function (c) { return cardColors.indexOf(c) !== -1; })) return false;

    if (filters.priceMin !== null && cardPrice < filters.priceMin) return false;
    if (filters.priceMax !== null && cardPrice > filters.priceMax) return false;

    return true;
  }

  /* ---------- Sort the currently-visible cards ---------- */
  function sortCards(visibleCards) {
    const mode = sortSelect ? sortSelect.value : 'featured';

    const sorted = visibleCards.slice();

    if (mode === 'price-low') {
      sorted.sort(function (a, b) { return parseFloat(a.dataset.price) - parseFloat(b.dataset.price); });
    } else if (mode === 'price-high') {
      sorted.sort(function (a, b) { return parseFloat(b.dataset.price) - parseFloat(a.dataset.price); });
    } else if (mode === 'newest') {
      sorted.sort(function (a, b) { return parseInt(a.dataset.newest, 10) - parseInt(b.dataset.newest, 10); });
    } else {
      // 'featured' = original server-rendered order
      sorted.sort(function (a, b) { return parseInt(a.dataset.order, 10) - parseInt(b.dataset.order, 10); });
    }

    return sorted;
  }

  /* ---------- Main entry point: filter, sort, re-render, update UI ---------- */
  function applyShopFiltersAndSort() {
    const filters = getActiveFilters();

    let visibleCount = 0;
    cards.forEach(function (card) {
      const matches = cardMatches(card, filters);
      card.style.display = matches ? '' : 'none';
      if (matches) visibleCount++;
    });

    const visibleCards = cards.filter(function (card) { return card.style.display !== 'none'; });
    const sortedVisible = sortCards(visibleCards);

    // Re-append in sorted order — appendChild on an existing node moves it,
    // it doesn't duplicate it, so this reorders in place.
    sortedVisible.forEach(function (card) { grid.appendChild(card); });

    if (resultsCount) {
      resultsCount.textContent = visibleCount + (visibleCount === 1 ? ' result' : ' results');
    }

    if (noResultsMsg) {
      noResultsMsg.style.display = visibleCount === 0 ? 'block' : 'none';
    }
    grid.style.display = visibleCount === 0 ? 'none' : '';

    syncFilterChips();
  }

  /* ---------- Active-filter chips + mobile filter count badge ---------- */
  function syncFilterChips() {
    const chips = [];

    document.querySelectorAll('.filter-option input[type="checkbox"]:checked').forEach(function (cb) {
      chips.push({ label: cb.dataset.label || cb.value, clear: function () { cb.checked = false; applyShopFiltersAndSort(); } });
    });

    document.querySelectorAll('.size-btn.active').forEach(function (btn) {
      chips.push({ label: 'Size ' + btn.textContent.trim(), clear: function () { btn.classList.remove('active'); applyShopFiltersAndSort(); } });
    });

    document.querySelectorAll('.color-swatch.active').forEach(function (sw) {
      chips.push({ label: sw.dataset.label || 'Color', clear: function () { sw.classList.remove('active'); applyShopFiltersAndSort(); } });
    });

    if (priceMinInput && priceMinInput.value) {
      chips.push({ label: 'Min $' + priceMinInput.value, clear: function () { priceMinInput.value = ''; applyShopFiltersAndSort(); } });
    }
    if (priceMaxInput && priceMaxInput.value) {
      chips.push({ label: 'Max $' + priceMaxInput.value, clear: function () { priceMaxInput.value = ''; applyShopFiltersAndSort(); } });
    }

    if (activeFiltersBar) {
      activeFiltersBar.innerHTML = '';
      chips.forEach(function (chip) {
        const el = document.createElement('span');
        el.className = 'filter-chip';
        el.innerHTML = chip.label + ' <button type="button" aria-label="Remove filter ' + chip.label + '"><i class="bi bi-x"></i></button>';
        el.querySelector('button').addEventListener('click', chip.clear);
        activeFiltersBar.appendChild(el);
      });
    }

    if (filterBadge) {
      if (chips.length > 0) {
        filterBadge.textContent = String(chips.length);
        filterBadge.style.display = 'flex';
      } else {
        filterBadge.style.display = 'none';
      }
    }
  }

  /* ---------- Clear all filters ---------- */
  function clearAllFilters() {
    document.querySelectorAll('.filter-option input[type="checkbox"]').forEach(function (cb) { cb.checked = false; });
    document.querySelectorAll('.size-btn.active').forEach(function (btn) { btn.classList.remove('active'); });
    document.querySelectorAll('.color-swatch.active').forEach(function (sw) { sw.classList.remove('active'); });
    if (priceMinInput) priceMinInput.value = '';
    if (priceMaxInput) priceMaxInput.value = '';
    applyShopFiltersAndSort();
  }

  if (clearAllBtn) clearAllBtn.addEventListener('click', clearAllFilters);
  if (clearAllInlineBtn) clearAllInlineBtn.addEventListener('click', clearAllFilters);

  // Initial pass on page load (handles the default "Featured" sort order + empty filters)
  applyShopFiltersAndSort();

});